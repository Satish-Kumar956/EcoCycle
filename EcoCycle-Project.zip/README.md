# 🌱 EcoCycle – Smart Organic Waste Management System

> **College Hackathon Project**  
> Modern, responsive web platform connecting urban organic waste generators with Gaushalas, animal owners, biogas plants, and organic fertilizer producers.

---

## 📌 Central Workflow

```
[Waste Providers: Markets/Shops/Households]
                 │
                 ▼ (Submit Pickup Request)
         [Waste Collectors]
                 │
                 ▼ (Collect & Deliver to Facility)
    [Facility Admin: Manual Segregation]
        ├── 🐄 Animal Feed  ──► Gaushalas & Animal Owners
        ├── 🔥 Biogas Waste ──► Biogas Plant Operators
        └── 🌱 Compostable  ──► Fertilizer Producers ──► [Marketplace] ──► Farmers & Nurseries
```

---

## 👥 8 User Roles & Demo Credentials

EcoCycle comes with **pre-seeded accounts** and a floating **1-Click Quick Role Switcher** at the bottom of the screen for instant, frictionless evaluation by judges.

| Role | Demo Email | Password | Organization / Name | Key Action |
|------|------------|----------|---------------------|------------|
| **Admin** | `admin@ecocycle.com` | `admin123` | EcoCycle Facility Admin | Manual Segregation, Allocation & System Controls |
| **Waste Provider** | `provider@greenmarket.com` | `pass123` | Metro Vegetable Market | Submit waste collection requests with photo & date |
| **Waste Collector** | `collector@ecocycle.com` | `pass123` | Rajesh Kumar (Vehicle: Pickup) | Accept pickups, update status & confirm facility delivery |
| **Gaushala** | `gaushala@vrindavan.org` | `pass123` | Shri Vrindavan Gaushala (140 Cows) | Request inspected cattle feed & track deliveries |
| **Animal Owner** | `ramesh@animalowner.com` | `pass123` | Ramesh Patel (18 Cattle) | Request fresh dairy animal feed & track supply |
| **Biogas Operator** | `operator@biogaspowerearth.com` | `pass123` | GreenEnergy Bio-Methane Facility | Request high-energy organic waste for anaerobic digesters |
| **Fertilizer Producer** | `contact@purecompost.com` | `pass123` | BioTerra Organic Compost Ltd | Request compostable waste & sell finished fertilizer |
| **Farmer / Nursery** | `kisan@greenfarms.com` | `pass123` | Anand Green Farms & Nursery | Browse marketplace, check NPK values & order organic compost |

---

## 🛠️ Technology Stack

- **Frontend:** React 19 + Vite 8
- **Styling:** Tailwind CSS v4 (Custom Environmental Green Theme: `#16834A`, `#E8F5E9`, `#F8FAF8`, `#202820`)
- **Icons:** Lucide React
- **Charts:** Recharts (Admin Overview & Waste Analysis)
- **Database & Auth:** Cloud Firestore & Firebase Auth (with automatic reactive local persistence for zero-config offline demo)
- **Routing:** React Router v7
- **Toasts:** React Hot Toast

---

## 🚀 How to Run

1. Navigate to the project directory:
   ```bash
   cd "Hackathon 2.0/ecocycle"
   ```

2. Start the development server:
   ```bash
   npm run dev
   ```

3. Open your browser at:
   ```
   http://localhost:5173
   ```

---

## 📂 Project Structure

```
src/
├── components/
│   ├── admin/
│   │   ├── Overview.jsx             # Key metrics & Recharts segregation charts
│   │   ├── ManualSegregation.jsx    # 4-category classification with strict sum validation
│   │   ├── DistributionManager.jsx  # Waste allocation & status flow engine
│   │   ├── WasteRequests.jsx        # Provider request management & collector dispatch
│   │   ├── WasteCollections.jsx     # Facility arrival & batch creation
│   │   ├── StakeholderDirectory.jsx # Directory of all registered stakeholders
│   │   ├── Reports.jsx              # System statistics & category summaries
│   │   └── AdminSettings.jsx        # Facility profile & parameters
│   ├── marketplace/
│   │   └── Marketplace.jsx          # Organic fertilizer store for farmers & nurseries
│   ├── stakeholder/
│   │   ├── Gaushala.jsx             # Animal feed requests & cattle head records
│   │   ├── AnimalOwner.jsx          # Dairy owner feed requirements
│   │   ├── Biogas.jsx               # Feedstock demand & methane generation tracker
│   │   ├── Fertilizer.jsx           # Raw material intake & marketplace product manager
│   │   └── Farmer.jsx               # Fertilizer catalog, order placement & tracking
│   └── shared/
│       ├── Navbar.jsx               # Responsive eco-themed header
│       ├── Sidebar.jsx              # Collapsible dashboard navigation
│       ├── StatCard.jsx             # Visual statistic metric cards
│       ├── StatusBadge.jsx          # Consistent status indicator pills
│       └── DemoRoleSwitcher.jsx     # 1-click role switcher for hackathon judges
├── pages/
│   ├── LandingPage.jsx              # Hero, 3 categories, how it works & benefits
│   ├── LoginPage.jsx                # Secure authentication with error handling
│   ├── RegisterPage.jsx             # Multi-step role registration (admin excluded)
│   ├── admin/AdminDashboard.jsx     # Master admin dashboard wrapper
│   ├── provider/ProviderDashboard.jsx # Provider request submission & history
│   └── collector/CollectorDashboard.jsx # Assigned pickups & delivery verification
├── firebase/
│   ├── config.js                    # Dual-mode Firebase / Reactive adapter
│   ├── mockData.js                  # Initial rich seed dataset
│   ├── firebaseBridge.js            # Reactive localStorage persistence layer
│   ├── firestore-adapter.js         # Full Firestore API simulator & connector
│   └── auth-adapter.js              # Full Firebase Auth simulator & connector
└── firestore.rules                  # Role-based Cloud Firestore security rules
```

---

## 🔒 Firebase Cloud Security Rules

The repository includes a production-ready `firestore.rules` file enforcing:
- Admin accounts **cannot** be created through public registration.
- Waste Providers can only manage their own collection requests.
- Collectors can only modify pickup statuses assigned to them.
- Allocation quantities cannot exceed available segregated inventory.
- Fertilizer producers can only edit their own product listings.
- Public read access for the finished organic fertilizer marketplace.
