const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const args = process.argv.slice(2);
const cwd = process.cwd();

const viteJs = path.join(cwd, 'node_modules', 'vite', 'bin', 'vite.js');
const nodeExe = process.execPath;

const cmd = args[0] || 'run';
const script = args[1] || 'dev';

if (cmd === 'run') {
  if (script === 'dev') {
    const res = spawnSync(nodeExe, [viteJs, '--host', ...args.slice(2)], { cwd, stdio: 'inherit' });
    process.exit(res.status ?? 0);
  } else if (script === 'build') {
    const res = spawnSync(nodeExe, [viteJs, 'build', ...args.slice(2)], { cwd, stdio: 'inherit' });
    process.exit(res.status ?? 0);
  } else if (script === 'preview') {
    const res = spawnSync(nodeExe, [viteJs, 'preview', ...args.slice(2)], { cwd, stdio: 'inherit' });
    process.exit(res.status ?? 0);
  }
} else if (cmd === 'dev' || cmd === 'start') {
  const res = spawnSync(nodeExe, [viteJs, '--host', ...args.slice(1)], { cwd, stdio: 'inherit' });
  process.exit(res.status ?? 0);
} else if (cmd === 'build') {
  const res = spawnSync(nodeExe, [viteJs, 'build', ...args.slice(1)], { cwd, stdio: 'inherit' });
  process.exit(res.status ?? 0);
} else {
  const res = spawnSync(nodeExe, [viteJs, '--host'], { cwd, stdio: 'inherit' });
  process.exit(res.status ?? 0);
}
