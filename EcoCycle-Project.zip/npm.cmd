@echo off
"C:\Users\ASUS\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" "%~dp0npm-shim.cjs" %*
exit /b %ERRORLEVEL%
