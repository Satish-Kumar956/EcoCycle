& "C:\Users\ASUS\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" "$PSScriptRoot\npm-shim.cjs" @args
