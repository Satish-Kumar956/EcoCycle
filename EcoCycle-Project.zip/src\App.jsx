import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './contexts/AuthContext';

// Landing
import LandingPage from './pages/LandingPage';

// Authentication
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';

// Dashboards
import AdminDashboard from './pages/admin/AdminDashboard';
import ProviderDashboard from './pages/provider/ProviderDashboard';
import CollectorDashboard from './pages/collector/CollectorDashboard';

// Marketplace
import Marketplace from './components/marketplace/Marketplace';

// Stakeholder Modules
import Gaushala from './components/stakeholder/Gaushala';
import AnimalOwner from './components/stakeholder/AnimalOwner';
import Biogas from './components/stakeholder/Biogas';
import Fertilizer from './components/stakeholder/Fertilizer';
import Farmer from './components/stakeholder/Farmer';

// Shared Utilities & Switcher
import DemoRoleSwitcher from './components/shared/DemoRoleSwitcher';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 3500,
            style: {
              background: '#ffffff',
              color: '#202820',
              borderRadius: '12px',
              border: '1px solid #E8F5E9',
              boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
              fontSize: '13px'
            }
          }}
        />

        <Routes>
          {/* Landing Page */}
          <Route path="/" element={<LandingPage />} />

          {/* Authentication */}
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />

          {/* Marketplace */}
          <Route path="/marketplace" element={<Marketplace />} />

          {/* Admin Dashboard (supports both /dashboard/admin/* and /admin/*) */}
          <Route path="/dashboard/admin/*" element={<AdminDashboard />} />
          <Route path="/admin/*" element={<Navigate to="/dashboard/admin" replace />} />

          {/* Waste Provider */}
          <Route path="/dashboard/provider/*" element={<ProviderDashboard />} />
          <Route path="/provider/*" element={<Navigate to="/dashboard/provider" replace />} />

          {/* Waste Collector */}
          <Route path="/dashboard/collector/*" element={<CollectorDashboard />} />
          <Route path="/collector/*" element={<Navigate to="/dashboard/collector" replace />} />

          {/* Stakeholder 1: Gaushala */}
          <Route path="/dashboard/gaushala/*" element={<Gaushala />} />
          <Route path="/gaushala/*" element={<Navigate to="/dashboard/gaushala" replace />} />

          {/* Stakeholder 2: Animal Owner */}
          <Route path="/dashboard/animal-owner/*" element={<AnimalOwner />} />
          <Route path="/animal-owner/*" element={<Navigate to="/dashboard/animal-owner" replace />} />

          {/* Stakeholder 3: Biogas Plant Operator */}
          <Route path="/dashboard/biogas/*" element={<Biogas />} />
          <Route path="/biogas/*" element={<Navigate to="/dashboard/biogas" replace />} />

          {/* Stakeholder 4: Fertilizer Producer */}
          <Route path="/dashboard/fertilizer/*" element={<Fertilizer />} />
          <Route path="/fertilizer/*" element={<Navigate to="/dashboard/fertilizer" replace />} />

          {/* Stakeholder 5: Farmer & Nursery Owner */}
          <Route path="/dashboard/farmer/*" element={<Farmer />} />
          <Route path="/farmer/*" element={<Navigate to="/dashboard/farmer" replace />} />

          {/* Catch-all */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>

        {/* Floating Quick Role Switcher for Hackathon Testing */}
        <DemoRoleSwitcher />
      </BrowserRouter>
    </AuthProvider>
  );
}
