import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../../firebase/config';
import { Settings, User, Shield } from 'lucide-react';
import toast from 'react-hot-toast';

export default function AdminSettings() {
  const { userProfile, currentUser, fetchUserProfile } = useAuth();
  const [form, setForm] = useState({ name: userProfile?.name || '', phone: userProfile?.phone || '', location: userProfile?.location || '' });
  const [saving, setSaving] = useState(false);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await updateDoc(doc(db, 'users', currentUser.uid), form);
      await fetchUserProfile(currentUser.uid);
      toast.success('Profile updated!');
    } catch (err) {
      toast.error('Update failed.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h2 className="text-2xl font-bold text-gray-800">Settings</h2>
        <p className="text-sm text-gray-500">Manage your admin account</p>
      </div>

      {/* Admin Profile */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
          <User size={18} className="text-green-600" />
          Admin Profile
        </h3>
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Full Name</label>
            <input
              value={form.name}
              onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Email</label>
            <input
              value={currentUser?.email || ''}
              disabled
              className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm bg-gray-50 text-gray-400"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Phone</label>
            <input
              value={form.phone}
              onChange={e => setForm(p => ({ ...p, phone: e.target.value }))}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              placeholder="+91 98765 43210"
            />
          </div>
          <button
            type="submit"
            disabled={saving}
            className="px-6 py-2.5 bg-green-700 text-white rounded-xl text-sm font-medium hover:bg-green-800 disabled:opacity-60"
          >
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </form>
      </div>

      {/* Security Note */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
          <Shield size={18} className="text-green-600" />
          Security Information
        </h3>
        <div className="text-sm text-gray-600 space-y-2">
          <p>• Admin accounts are created directly in Firebase Console for security.</p>
          <p>• Password changes must be done through Firebase Authentication.</p>
          <p>• To create new admin accounts, add users with role: "admin" in Firestore.</p>
        </div>
      </div>
    </div>
  );
}
