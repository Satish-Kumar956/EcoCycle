import React, { useEffect, useState } from 'react';
import { db } from '../../firebase/config';
import { collection, getDocs, doc, updateDoc, query, where, orderBy } from 'firebase/firestore';
import { formatDate, formatQuantity } from '../../utils/helpers';
import StatusBadge from '../shared/StatusBadge';
import { Package, Send } from 'lucide-react';
import toast from 'react-hot-toast';

const TABS = [
  { key: 'animalFeed', label: '🐄 Animal Feed', roles: ['gaushala', 'animalOwner'] },
  { key: 'biogas', label: '🔥 Biogas', roles: ['biogasOperator'] },
  { key: 'compost', label: '🌱 Compost', roles: ['fertilizerProducer', 'farmerNursery'] },
];

export default function DistributionManager() {
  const [activeTab, setActiveTab] = useState('animalFeed');
  const [available, setAvailable] = useState([]);
  const [stakeholders, setStakeholders] = useState([]);
  const [distributions, setDistributions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [allocateModal, setAllocateModal] = useState(null); // { distRecord, stakeholder }
  const [allocQty, setAllocQty] = useState('');
  const [saving, setSaving] = useState(false);

  const tab = TABS.find(t => t.key === activeTab);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [distSnap, ...stakeholderSnaps] = await Promise.all([
        getDocs(query(collection(db, 'distributions'), where('category', '==', activeTab), orderBy('createdAt', 'desc'))),
        ...tab.roles.map(role => getDocs(query(collection(db, 'users'), where('role', '==', role))))
      ]);

      const distData = distSnap.docs.map(d => ({ id: d.id, ...d.data() }));
      setAvailable(distData.filter(d => d.status === 'available' && d.availableQuantity > 0));
      setDistributions(distData.filter(d => d.status !== 'available'));

      const sData = stakeholderSnaps.flatMap(s => s.docs.map(d => ({ id: d.id, ...d.data() })));
      setStakeholders(sData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [activeTab]);

  const handleAllocate = async () => {
    const qty = Number(allocQty);
    if (!qty || qty <= 0) { toast.error('Enter a valid quantity'); return; }
    if (qty > allocateModal.dist.availableQuantity) {
      toast.error(`Cannot allocate more than ${allocateModal.dist.availableQuantity} KG available.`);
      return;
    }
    setSaving(true);
    try {
      await updateDoc(doc(db, 'distributions', allocateModal.dist.id), {
        stakeholderId: allocateModal.stakeholder.id,
        stakeholderName: allocateModal.stakeholder.name,
        allocatedQuantity: qty,
        availableQuantity: allocateModal.dist.availableQuantity - qty,
        status: 'approved',
        updatedAt: new Date()
      });
      toast.success(`Allocated ${qty} KG to ${allocateModal.stakeholder.name}!`);
      setAllocateModal(null);
      setAllocQty('');
      fetchData();
    } catch (err) {
      toast.error('Allocation failed.');
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const updateStatus = async (distId, newStatus) => {
    try {
      await updateDoc(doc(db, 'distributions', distId), { status: newStatus, updatedAt: new Date() });
      toast.success(`Status updated to ${newStatus}`);
      fetchData();
    } catch (err) {
      toast.error('Update failed.');
    }
  };

  const NEXT_STATUS = {
    approved: 'assigned',
    assigned: 'dispatched',
    dispatched: 'delivered'
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-2xl font-bold text-gray-800">Waste Distribution</h2>
        <p className="text-sm text-gray-500">Allocate classified waste to stakeholders</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 flex-wrap">
        {TABS.map(t => (
          <button
            key={t.key}
            onClick={() => setActiveTab(t.key)}
            className={`px-4 py-2.5 rounded-xl text-sm font-medium transition-colors ${
              activeTab === t.key ? 'bg-green-700 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:border-green-400'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="text-gray-400 text-sm p-8 text-center">Loading distribution data...</div>
      ) : (
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Available Waste */}
          <div>
            <h3 className="font-semibold text-gray-700 mb-3">Available Waste ({available.length} batches)</h3>
            {available.length === 0 ? (
              <div className="bg-white rounded-xl border border-dashed border-gray-200 p-6 text-center text-gray-400 text-sm">
                No available waste in this category.
              </div>
            ) : available.map(d => (
              <div key={d.id} className="bg-white rounded-xl border border-gray-100 shadow-sm p-4 mb-3">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <p className="font-bold text-gray-800">{d.providerName || 'Unknown Provider'}</p>
                    <p className="text-xs text-gray-400 font-mono">{d.batchId?.slice(0, 8) || d.id.slice(0, 8)}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-bold text-green-700">{d.availableQuantity} KG</p>
                    <p className="text-xs text-gray-400">available</p>
                  </div>
                </div>
                <p className="text-xs text-gray-500 mb-3">Created: {formatDate(d.createdAt)}</p>
                <div className="border-t border-gray-50 pt-3">
                  <p className="text-xs font-medium text-gray-600 mb-2">Allocate to a stakeholder:</p>
                  <div className="grid grid-cols-1 gap-2 max-h-40 overflow-y-auto">
                    {stakeholders.map(s => (
                      <button
                        key={s.id}
                        onClick={() => { setAllocateModal({ dist: d, stakeholder: s }); setAllocQty(''); }}
                        className="flex items-center justify-between p-2 rounded-lg border border-gray-100 hover:border-green-400 hover:bg-green-50 text-left transition-colors"
                      >
                        <div>
                          <p className="text-sm font-medium text-gray-700">{s.name}</p>
                          <p className="text-xs text-gray-400">{s.location || 'N/A'}</p>
                        </div>
                        <Send size={14} className="text-green-600" />
                      </button>
                    ))}
                  </div>
                  {stakeholders.length === 0 && (
                    <p className="text-xs text-amber-600">No stakeholders registered for this category yet.</p>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Distribution Records */}
          <div>
            <h3 className="font-semibold text-gray-700 mb-3">Distribution Records ({distributions.length})</h3>
            {distributions.length === 0 ? (
              <div className="bg-white rounded-xl border border-dashed border-gray-200 p-6 text-center text-gray-400 text-sm">
                No active distributions yet.
              </div>
            ) : (
              <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-gray-50 border-b border-gray-100">
                        <th className="px-3 py-3 text-left text-xs font-medium text-gray-600">Stakeholder</th>
                        <th className="px-3 py-3 text-left text-xs font-medium text-gray-600">Qty</th>
                        <th className="px-3 py-3 text-left text-xs font-medium text-gray-600">Status</th>
                        <th className="px-3 py-3 text-left text-xs font-medium text-gray-600">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                      {distributions.map(d => (
                        <tr key={d.id} className="hover:bg-gray-50">
                          <td className="px-3 py-2.5">
                            <p className="font-medium text-gray-800">{d.stakeholderName || '—'}</p>
                          </td>
                          <td className="px-3 py-2.5 text-gray-600">{d.allocatedQuantity || d.quantity} KG</td>
                          <td className="px-3 py-2.5"><StatusBadge status={d.status} /></td>
                          <td className="px-3 py-2.5">
                            {NEXT_STATUS[d.status] && (
                              <button
                                onClick={() => updateStatus(d.id, NEXT_STATUS[d.status])}
                                className="text-xs bg-green-700 text-white px-2 py-1 rounded-lg hover:bg-green-800"
                              >
                                → {NEXT_STATUS[d.status]}
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Allocate Modal */}
      {allocateModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="font-bold text-lg text-gray-800 mb-1">Allocate Waste</h3>
            <p className="text-sm text-gray-500 mb-4">
              Allocating to <strong>{allocateModal.stakeholder.name}</strong>
              <br />
              Available: <strong>{allocateModal.dist.availableQuantity} KG</strong>
            </p>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Quantity to Allocate (KG)</label>
              <input
                type="number"
                max={allocateModal.dist.availableQuantity}
                min={1}
                value={allocQty}
                onChange={e => setAllocQty(e.target.value)}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                placeholder={`Max ${allocateModal.dist.availableQuantity} KG`}
              />
            </div>
            <div className="flex gap-3">
              <button onClick={() => setAllocateModal(null)} className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-medium hover:bg-gray-50">Cancel</button>
              <button onClick={handleAllocate} disabled={saving} className="flex-1 py-2.5 bg-green-700 text-white rounded-xl text-sm font-medium hover:bg-green-800 disabled:opacity-60">
                {saving ? 'Allocating...' : 'Confirm Allocation'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
