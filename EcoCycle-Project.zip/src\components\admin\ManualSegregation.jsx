import React, { useEffect, useState } from 'react';
import { db } from '../../firebase/config';
import {
  collection, getDocs, doc, addDoc, updateDoc, serverTimestamp, query, orderBy, where
} from 'firebase/firestore';
import { formatDate, formatQuantity } from '../../utils/helpers';
import { AlertCircle, CheckCircle2, Layers } from 'lucide-react';
import StatusBadge from '../shared/StatusBadge';
import toast from 'react-hot-toast';
import { useAuth } from '../../contexts/AuthContext';

export default function ManualSegregation() {
  const { currentUser } = useAuth();
  const [batches, setBatches] = useState([]);
  const [classified, setClassified] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({});

  const fetchData = async () => {
    try {
      const [batchSnap, classSnap] = await Promise.all([
        getDocs(query(collection(db, 'wasteBatches'), orderBy('collectionDate', 'desc'))),
        getDocs(query(collection(db, 'wasteClassifications'), orderBy('classifiedAt', 'desc')))
      ]);
      const allBatches = batchSnap.docs.map(d => ({ id: d.id, ...d.data() }));
      const allClass = classSnap.docs.map(d => ({ id: d.id, ...d.data() }));

      const classifiedBatchIds = new Set(allClass.map(c => c.batchId));
      setBatches(allBatches.filter(b => !classifiedBatchIds.has(b.id) && b.status === 'received'));
      setClassified(allClass.map(c => ({
        ...c,
        batch: allBatches.find(b => b.id === c.batchId)
      })));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const updateForm = (batchId, field, value) => {
    setForm(prev => ({
      ...prev,
      [batchId]: { ...(prev[batchId] || {}), [field]: value }
    }));
  };

  const getFormSum = (batchId) => {
    const f = form[batchId] || {};
    return (Number(f.animalFeed) || 0) + (Number(f.biogas) || 0) +
      (Number(f.compost) || 0) + (Number(f.rejected) || 0);
  };

  const handleClassify = async (batch) => {
    const f = form[batch.id] || {};
    const animalFeed = Number(f.animalFeed) || 0;
    const biogas = Number(f.biogas) || 0;
    const compost = Number(f.compost) || 0;
    const rejected = Number(f.rejected) || 0;
    const total = animalFeed + biogas + compost + rejected;

    if (total !== batch.quantity) {
      toast.error(`Sum (${total} KG) must equal total quantity (${batch.quantity} KG).`);
      return;
    }

    setSaving(true);
    try {
      // Create classification record
      const classRef = await addDoc(collection(db, 'wasteClassifications'), {
        batchId: batch.id,
        animalFeed, biogas, compost, rejected,
        totalQuantity: batch.quantity,
        classifiedAt: serverTimestamp(),
        classifiedBy: currentUser?.uid
      });

      // Update batch status
      await updateDoc(doc(db, 'wasteBatches', batch.id), { status: 'classified' });

      // Create distribution entries for each non-zero category
      const cats = [
        { key: 'animalFeed', qty: animalFeed, label: 'Animal Feed' },
        { key: 'biogas', qty: biogas, label: 'Biogas' },
        { key: 'compost', qty: compost, label: 'Compost' }
      ];

      for (const cat of cats) {
        if (cat.qty > 0) {
          await addDoc(collection(db, 'distributions'), {
            batchId: batch.id,
            classificationId: classRef.id,
            category: cat.key,
            quantity: cat.qty,
            availableQuantity: cat.qty,
            status: 'available',
            createdAt: serverTimestamp(),
            providerName: batch.providerName
          });
        }
      }

      toast.success('Waste classified and distribution entries created!');
      setForm(prev => { const n = { ...prev }; delete n[batch.id]; return n; });
      fetchData();
    } catch (err) {
      toast.error('Classification failed.');
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-800">Manual Waste Segregation</h2>
        <p className="text-sm text-gray-500">Classify received waste batches into utilization categories</p>
      </div>

      {/* Pending Classification */}
      <div>
        <h3 className="font-semibold text-gray-700 mb-3 flex items-center gap-2">
          <Layers size={18} className="text-orange-500" />
          Pending Classification ({batches.length})
        </h3>

        {loading ? (
          <p className="text-gray-400 text-sm">Loading batches...</p>
        ) : batches.length === 0 ? (
          <div className="bg-white rounded-xl border border-dashed border-gray-200 p-8 text-center">
            <Layers size={32} className="mx-auto text-gray-300 mb-2" />
            <p className="text-gray-400">No batches pending classification.</p>
          </div>
        ) : batches.map(batch => {
          const f = form[batch.id] || {};
          const sum = getFormSum(batch.id);
          const isValid = sum === batch.quantity;
          const diff = batch.quantity - sum;

          return (
            <div key={batch.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-4">
              {/* Batch Header */}
              <div className="flex items-start justify-between mb-5">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-mono bg-green-100 text-green-700 px-2 py-0.5 rounded">
                      {batch.batchId || batch.id.slice(0, 8)}
                    </span>
                    <StatusBadge status={batch.status} />
                  </div>
                  <p className="font-bold text-gray-800">{batch.providerName}</p>
                  <p className="text-sm text-gray-500">
                    {batch.wasteType} · Received: {formatDate(batch.collectionDate)}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-green-700">{batch.quantity} KG</p>
                  <p className="text-xs text-gray-400">Total Quantity</p>
                </div>
              </div>

              {/* Classification Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-4">
                {[
                  { key: 'animalFeed', label: 'Animal Feed', color: 'green', icon: '🐄' },
                  { key: 'biogas', label: 'Biogas', color: 'orange', icon: '🔥' },
                  { key: 'compost', label: 'Compost', color: 'blue', icon: '🌱' },
                  { key: 'rejected', label: 'Rejected', color: 'red', icon: '❌' },
                ].map(cat => (
                  <div key={cat.key} className={`p-3 rounded-xl border-2 ${
                    f[cat.key] > 0
                      ? `border-${cat.color}-400 bg-${cat.color}-50`
                      : 'border-gray-200 bg-gray-50'
                  }`}>
                    <div className="text-lg mb-1">{cat.icon}</div>
                    <label className="block text-xs font-medium text-gray-600 mb-1.5">{cat.label} (KG)</label>
                    <input
                      type="number"
                      min="0"
                      max={batch.quantity}
                      value={f[cat.key] || ''}
                      onChange={e => updateForm(batch.id, cat.key, e.target.value)}
                      placeholder="0"
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                    />
                  </div>
                ))}
              </div>

              {/* Validation Bar */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex-1 bg-gray-100 rounded-full h-2 mr-4">
                  <div
                    className={`h-2 rounded-full transition-all ${isValid ? 'bg-green-500' : sum > batch.quantity ? 'bg-red-500' : 'bg-orange-400'}`}
                    style={{ width: `${Math.min(100, (sum / batch.quantity) * 100)}%` }}
                  />
                </div>
                <span className={`text-sm font-medium ${isValid ? 'text-green-700' : 'text-orange-600'}`}>
                  {sum} / {batch.quantity} KG
                </span>
              </div>

              {!isValid && sum > 0 && (
                <div className="flex items-center gap-2 text-sm text-amber-700 bg-amber-50 px-3 py-2 rounded-lg mb-3">
                  <AlertCircle size={15} />
                  {diff > 0 ? `${diff} KG unclassified remaining.` : `${Math.abs(diff)} KG over the total quantity.`}
                </div>
              )}
              {isValid && (
                <div className="flex items-center gap-2 text-sm text-green-700 bg-green-50 px-3 py-2 rounded-lg mb-3">
                  <CheckCircle2 size={15} />
                  All {batch.quantity} KG classified. Ready to submit.
                </div>
              )}

              <button
                onClick={() => handleClassify(batch)}
                disabled={!isValid || saving}
                className="w-full py-3 bg-green-700 text-white rounded-xl font-semibold text-sm hover:bg-green-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {saving ? 'Classifying...' : 'Confirm Classification & Create Distributions'}
              </button>
            </div>
          );
        })}
      </div>

      {/* Classified Batches */}
      {classified.length > 0 && (
        <div>
          <h3 className="font-semibold text-gray-700 mb-3 flex items-center gap-2">
            <CheckCircle2 size={18} className="text-green-600" />
            Classified Batches ({classified.length})
          </h3>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-100">
                    <th className="px-4 py-3 text-left font-medium text-gray-600">Batch</th>
                    <th className="px-4 py-3 text-left font-medium text-gray-600">Provider</th>
                    <th className="px-4 py-3 text-left font-medium text-gray-600">Total</th>
                    <th className="px-4 py-3 text-left font-medium text-gray-600">Animal Feed</th>
                    <th className="px-4 py-3 text-left font-medium text-gray-600">Biogas</th>
                    <th className="px-4 py-3 text-left font-medium text-gray-600">Compost</th>
                    <th className="px-4 py-3 text-left font-medium text-gray-600">Rejected</th>
                    <th className="px-4 py-3 text-left font-medium text-gray-600">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {classified.map(c => (
                    <tr key={c.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3 font-mono text-xs text-gray-600">{c.batch?.batchId || c.batchId.slice(0, 8)}</td>
                      <td className="px-4 py-3 font-medium text-gray-800">{c.batch?.providerName || '—'}</td>
                      <td className="px-4 py-3 text-gray-600">{c.totalQuantity} KG</td>
                      <td className="px-4 py-3 text-green-700">{c.animalFeed} KG</td>
                      <td className="px-4 py-3 text-orange-600">{c.biogas} KG</td>
                      <td className="px-4 py-3 text-blue-600">{c.compost} KG</td>
                      <td className="px-4 py-3 text-red-500">{c.rejected} KG</td>
                      <td className="px-4 py-3 text-gray-400">{formatDate(c.classifiedAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
