import React, { useEffect, useState } from 'react';
import { db } from '../../firebase/config';
import { collection, getDocs, query, orderBy, limit, where } from 'firebase/firestore';
import { Truck, ClipboardList, Layers, Package, TrendingUp, Clock } from 'lucide-react';
import StatCard from '../shared/StatCard';
import StatusBadge from '../shared/StatusBadge';
import { formatDate } from '../../utils/helpers';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const COLORS = ['#16834A', '#f59e0b', '#3b82f6', '#ef4444'];

export default function Overview() {
  const [stats, setStats] = useState({ requests: 0, pending: 0, batches: 0, distributions: 0 });
  const [recent, setRecent] = useState([]);
  const [pieData, setPieData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [reqSnap, batchSnap, distSnap, classSnap] = await Promise.all([
          getDocs(collection(db, 'wasteRequests')),
          getDocs(collection(db, 'wasteBatches')),
          getDocs(collection(db, 'distributions')),
          getDocs(collection(db, 'wasteClassifications')),
        ]);

        const requests = reqSnap.docs.map(d => ({ id: d.id, ...d.data() }));
        const pending = requests.filter(r => r.status === 'pending').length;

        setStats({
          requests: requests.length,
          pending,
          batches: batchSnap.size,
          distributions: distSnap.size,
        });

        setRecent(requests.slice(-5).reverse());

        // Pie data from classifications
        let animalFeed = 0, biogas = 0, compost = 0, rejected = 0;
        classSnap.forEach(d => {
          const c = d.data();
          animalFeed += c.animalFeed || 0;
          biogas += c.biogas || 0;
          compost += c.compost || 0;
          rejected += c.rejected || 0;
        });
        if (animalFeed + biogas + compost + rejected > 0) {
          setPieData([
            { name: 'Animal Feed', value: animalFeed },
            { name: 'Biogas', value: biogas },
            { name: 'Compost', value: compost },
            { name: 'Rejected', value: rejected },
          ]);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) return <LoadingState />;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-800 mb-1">Admin Overview</h2>
        <p className="text-gray-500 text-sm">Real-time system dashboard</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Waste Requests" value={stats.requests} icon={ClipboardList} color="#16834A" bg="#E8F5E9" />
        <StatCard title="Pending Requests" value={stats.pending} icon={Clock} color="#d97706" bg="#FEF3C7" />
        <StatCard title="Waste Batches" value={stats.batches} icon={Layers} color="#2563eb" bg="#EFF6FF" />
        <StatCard title="Distributions" value={stats.distributions} icon={Package} color="#7c3aed" bg="#f3e8ff" />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Recent Requests */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
            <TrendingUp size={18} className="text-green-600" />
            Recent Waste Requests
          </h3>
          {recent.length === 0 ? (
            <p className="text-gray-400 text-sm text-center py-6">No requests yet.</p>
          ) : (
            <div className="space-y-3">
              {recent.map(r => (
                <div key={r.id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                  <div>
                    <p className="text-sm font-medium text-gray-800">{r.providerName || 'Unknown'}</p>
                    <p className="text-xs text-gray-400">{r.wasteType} · {r.estimatedQuantity} KG · {formatDate(r.createdAt)}</p>
                  </div>
                  <StatusBadge status={r.status} />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Distribution Pie */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="font-bold text-gray-800 mb-4">Waste Classification Breakdown</h3>
          {pieData.length === 0 ? (
            <div className="flex items-center justify-center h-48 text-gray-400 text-sm">
              No classification data yet.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                  {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip formatter={(v) => `${v} KG`} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  );
}

function LoadingState() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="h-8 bg-gray-200 rounded w-48" />
      <div className="grid grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => <div key={i} className="h-28 bg-gray-200 rounded-xl" />)}
      </div>
    </div>
  );
}
