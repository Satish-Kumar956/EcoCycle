import React, { useEffect, useState } from 'react';
import { db } from '../../firebase/config';
import { collection, getDocs } from 'firebase/firestore';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';

const COLORS = ['#16834A', '#f59e0b', '#3b82f6', '#ef4444', '#8b5cf6'];

export default function Reports() {
  const [classData, setClassData] = useState([]);
  const [distData, setDistData] = useState([]);
  const [summary, setSummary] = useState({ totalWaste: 0, totalCollections: 0, totalDistributed: 0 });

  useEffect(() => {
    const fetchReports = async () => {
      try {
        const [classSnap, distSnap, batchSnap] = await Promise.all([
          getDocs(collection(db, 'wasteClassifications')),
          getDocs(collection(db, 'distributions')),
          getDocs(collection(db, 'wasteBatches')),
        ]);

        let totalWaste = 0;
        const pie = [
          { name: 'Animal Feed', value: 0 },
          { name: 'Biogas', value: 0 },
          { name: 'Compost', value: 0 },
          { name: 'Rejected', value: 0 }
        ];

        classSnap.forEach(d => {
          const c = d.data();
          totalWaste += c.totalQuantity || 0;
          pie[0].value += c.animalFeed || 0;
          pie[1].value += c.biogas || 0;
          pie[2].value += c.compost || 0;
          pie[3].value += c.rejected || 0;
        });

        setClassData(pie.filter(p => p.value > 0));
        setSummary({
          totalWaste: batchSnap.docs.reduce((acc, d) => acc + (d.data().quantity || 0), 0),
          totalCollections: batchSnap.size,
          totalDistributed: distSnap.docs.filter(d => d.data().status === 'delivered').length
        });

        // Category bar data
        setDistData([
          { category: 'Animal Feed', available: 0, distributed: 0 },
          { category: 'Biogas', available: 0, distributed: 0 },
          { category: 'Compost', available: 0, distributed: 0 },
        ]);

      } catch (err) {
        console.error(err);
      }
    };
    fetchReports();
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-800">Reports & Analytics</h2>
        <p className="text-sm text-gray-500">System-wide waste management statistics</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Total Waste Collected', value: `${summary.totalWaste} KG`, color: '#16834A', bg: '#E8F5E9' },
          { label: 'Total Batches', value: summary.totalCollections, color: '#2563eb', bg: '#EFF6FF' },
          { label: 'Successful Deliveries', value: summary.totalDistributed, color: '#d97706', bg: '#FEF3C7' },
        ].map(c => (
          <div key={c.label} className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
            <p className="text-sm text-gray-500 mb-1">{c.label}</p>
            <p className="text-2xl font-bold" style={{ color: c.color }}>{c.value}</p>
          </div>
        ))}
      </div>

      {/* Pie Chart */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="font-bold text-gray-800 mb-4">Waste Classification Distribution</h3>
        {classData.length === 0 ? (
          <p className="text-gray-400 text-sm text-center py-8">No classification data available yet.</p>
        ) : (
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie
                data={classData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius={100}
                label={({ name, value }) => `${name}: ${value}KG`}
              >
                {classData.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
              </Pie>
              <Tooltip formatter={v => `${v} KG`} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        )}
      </div>

      {/* Info Note */}
      <div className="bg-green-50 border border-green-100 rounded-xl p-4 text-sm text-green-700">
        💡 Reports are based on real Firestore data. As more waste is collected and classified, charts will populate automatically.
      </div>
    </div>
  );
}
