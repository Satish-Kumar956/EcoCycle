import React, { useEffect, useState } from 'react';
import { db } from '../../firebase/config';
import { collection, getDocs, query, where, orderBy } from 'firebase/firestore';
import { Building2, User, Flame, Factory, TreePine, Sprout, MapPin, Phone } from 'lucide-react';

const TABS = [
  { key: 'all', label: 'All' },
  { key: 'gaushala', label: 'Gaushalas', icon: Building2, color: 'green' },
  { key: 'animalOwner', label: 'Animal Owners', icon: User, color: 'purple' },
  { key: 'biogasOperator', label: 'Biogas Plants', icon: Flame, color: 'orange' },
  { key: 'fertilizerProducer', label: 'Fertilizer Producers', icon: Factory, color: 'blue' },
  { key: 'farmerNursery', label: 'Farmers & Nurseries', icon: TreePine, color: 'teal' },
];

const COLOR_MAP = {
  green: { bg: '#E8F5E9', text: '#16834A' },
  purple: { bg: '#f3e8ff', text: '#7c3aed' },
  orange: { bg: '#FEF3C7', text: '#d97706' },
  blue: { bg: '#EFF6FF', text: '#2563eb' },
  teal: { bg: '#f0fdfa', text: '#0d9488' },
};

const ROLE_META = {
  gaushala: { label: 'Gaushala', icon: Building2, color: 'green' },
  animalOwner: { label: 'Animal Owner', icon: User, color: 'purple' },
  biogasOperator: { label: 'Biogas Plant', icon: Flame, color: 'orange' },
  fertilizerProducer: { label: 'Fertilizer Producer', icon: Factory, color: 'blue' },
  farmerNursery: { label: 'Farmer / Nursery', icon: TreePine, color: 'teal' },
};

export default function StakeholderDirectory() {
  const [stakeholders, setStakeholders] = useState([]);
  const [activeTab, setActiveTab] = useState('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStakeholders = async () => {
      try {
        const roles = ['gaushala', 'animalOwner', 'biogasOperator', 'fertilizerProducer', 'farmerNursery'];
        const snaps = await Promise.all(
          roles.map(role => getDocs(query(collection(db, 'users'), where('role', '==', role))))
        );
        const all = snaps.flatMap(snap => snap.docs.map(d => ({ id: d.id, ...d.data() })));
        setStakeholders(all);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchStakeholders();
  }, []);

  const filtered = activeTab === 'all'
    ? stakeholders
    : stakeholders.filter(s => s.role === activeTab);

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-2xl font-bold text-gray-800">Stakeholder Directory</h2>
        <p className="text-sm text-gray-500">All registered stakeholders in the EcoCycle network</p>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2">
        {TABS.map(t => (
          <button
            key={t.key}
            onClick={() => setActiveTab(t.key)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
              activeTab === t.key
                ? 'bg-green-700 text-white'
                : 'bg-white border border-gray-200 text-gray-600 hover:border-green-400 hover:text-green-700'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-36 bg-gray-100 rounded-xl animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-xl border border-dashed border-gray-200 p-10 text-center">
          <p className="text-gray-400">No stakeholders found in this category.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(s => {
            const meta = ROLE_META[s.role] || {};
            const colors = COLOR_MAP[meta.color] || COLOR_MAP.green;
            const Icon = meta.icon || Building2;

            return (
              <div key={s.id} className="bg-white rounded-xl border border-gray-100 shadow-sm p-5 hover:shadow-md transition-shadow">
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: colors.bg }}>
                    <Icon size={18} style={{ color: colors.text }} />
                  </div>
                  <div>
                    <p className="font-bold text-gray-800 leading-tight">{s.name}</p>
                    <p className="text-xs font-medium" style={{ color: colors.text }}>{meta.label}</p>
                  </div>
                </div>

                <div className="space-y-1.5">
                  {s.gaushalaName && <p className="text-sm text-gray-600">🐄 {s.gaushalaName}</p>}
                  {s.plantName && <p className="text-sm text-gray-600">🏭 {s.plantName}</p>}
                  {s.businessName && <p className="text-sm text-gray-600">🏢 {s.businessName}</p>}
                  {s.farmName && <p className="text-sm text-gray-600">🌾 {s.farmName}</p>}
                  {s.animalType && <p className="text-sm text-gray-600">🐾 {s.animalType} ({s.animalCount} animals)</p>}
                  {s.animalCount && !s.animalType && <p className="text-sm text-gray-600">🐄 {s.animalCount} animals</p>}
                  {s.capacity && <p className="text-sm text-gray-600">📦 Capacity: {s.capacity} KG</p>}

                  {s.location && (
                    <div className="flex items-center gap-1.5 text-sm text-gray-500">
                      <MapPin size={13} />
                      {s.location}
                    </div>
                  )}
                  {s.phone && (
                    <div className="flex items-center gap-1.5 text-sm text-gray-500">
                      <Phone size={13} />
                      {s.phone}
                    </div>
                  )}
                  <div className="flex items-center gap-1.5 text-sm text-gray-400">
                    📧 {s.email}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <p className="text-sm text-gray-400">Total: {filtered.length} stakeholder(s)</p>
    </div>
  );
}
