import React, { useEffect, useState } from 'react';
import { db } from '../../firebase/config';
import { collection, getDocs, doc, updateDoc, addDoc, serverTimestamp, query, orderBy } from 'firebase/firestore';
import StatusBadge from '../shared/StatusBadge';
import { formatDate, formatQuantity, generateBatchId } from '../../utils/helpers';
import { CheckCircle, Package } from 'lucide-react';
import toast from 'react-hot-toast';

export default function WasteCollections() {
  const [collections, setCollections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [receiveModal, setReceiveModal] = useState(null);
  const [actualQty, setActualQty] = useState('');
  const [saving, setSaving] = useState(false);

  const fetchData = async () => {
    try {
      const snap = await getDocs(query(collection(db, 'wasteRequests'), orderBy('createdAt', 'desc')));
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setCollections(data.filter(d => ['assigned', 'in_progress', 'collected'].includes(d.status)));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const markReceived = async () => {
    if (!actualQty || Number(actualQty) <= 0) {
      toast.error('Enter a valid quantity');
      return;
    }
    setSaving(true);
    try {
      const batchId = generateBatchId();
      // Update request
      await updateDoc(doc(db, 'wasteRequests', receiveModal.id), {
        status: 'delivered',
        actualQuantity: Number(actualQty)
      });
      // Create waste batch
      await addDoc(collection(db, 'wasteBatches'), {
        batchId,
        requestId: receiveModal.id,
        providerId: receiveModal.providerId,
        providerName: receiveModal.providerName,
        quantity: Number(actualQty),
        wasteType: receiveModal.wasteType,
        collectionDate: serverTimestamp(),
        status: 'received'
      });
      toast.success(`Waste received. Batch ${batchId} created.`);
      setReceiveModal(null);
      setActualQty('');
      fetchData();
    } catch (err) {
      toast.error('Failed to process delivery.');
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-2xl font-bold text-gray-800">Waste Collections</h2>
        <p className="text-sm text-gray-500">Track assigned collections and confirm deliveries to the facility</p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100">
                <th className="px-4 py-3 text-left font-medium text-gray-600">Provider</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600">Collector</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600">Waste Type</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600">Est. Qty</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600">Pickup Date</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600">Status</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {loading ? (
                <tr><td colSpan={7} className="text-center py-8 text-gray-400">Loading...</td></tr>
              ) : collections.length === 0 ? (
                <tr><td colSpan={7} className="text-center py-8 text-gray-400">No active collections.</td></tr>
              ) : collections.map(c => (
                <tr key={c.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <p className="font-medium text-gray-800">{c.providerName}</p>
                    <p className="text-xs text-gray-400">{c.pickupAddress?.slice(0, 30)}...</p>
                  </td>
                  <td className="px-4 py-3 text-gray-600">{c.collectorName || '—'}</td>
                  <td className="px-4 py-3 text-gray-600">{c.wasteType}</td>
                  <td className="px-4 py-3 text-gray-600">{formatQuantity(c.estimatedQuantity)}</td>
                  <td className="px-4 py-3 text-gray-600">{c.pickupDate}</td>
                  <td className="px-4 py-3"><StatusBadge status={c.status} /></td>
                  <td className="px-4 py-3">
                    {c.status === 'collected' && (
                      <button
                        onClick={() => { setReceiveModal(c); setActualQty(String(c.estimatedQuantity || '')); }}
                        className="inline-flex items-center gap-1 bg-green-700 text-white px-3 py-1.5 rounded-lg text-xs font-medium hover:bg-green-800"
                      >
                        <CheckCircle size={14} /> Mark Received
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Receive Modal */}
      {receiveModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-green-100 p-2 rounded-xl">
                <Package size={20} className="text-green-700" />
              </div>
              <h3 className="font-bold text-lg text-gray-800">Confirm Waste Received</h3>
            </div>
            <p className="text-sm text-gray-600 mb-4">
              From: <strong>{receiveModal.providerName}</strong> — {receiveModal.wasteType}
            </p>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1.5">
                Actual Quantity Received (KG)
              </label>
              <input
                type="number"
                value={actualQty}
                onChange={e => setActualQty(e.target.value)}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                placeholder="Enter actual KG received"
              />
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setReceiveModal(null)}
                className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-medium hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={markReceived}
                disabled={saving}
                className="flex-1 py-2.5 bg-green-700 text-white rounded-xl text-sm font-medium hover:bg-green-800 disabled:opacity-60"
              >
                {saving ? 'Saving...' : 'Confirm & Create Batch'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
