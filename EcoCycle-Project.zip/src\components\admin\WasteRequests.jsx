import React, { useEffect, useState } from 'react';
import { db } from '../../firebase/config';
import {
  collection, getDocs, doc, updateDoc, query, orderBy, where, getDocs as getDocsQ
} from 'firebase/firestore';
import { Filter, Search, UserCheck } from 'lucide-react';
import StatusBadge from '../shared/StatusBadge';
import { formatDate, formatQuantity } from '../../utils/helpers';
import toast from 'react-hot-toast';

const ALL_STATUSES = ['all', 'pending', 'assigned', 'in_progress', 'collected', 'delivered'];

export default function WasteRequests() {
  const [requests, setRequests] = useState([]);
  const [collectors, setCollectors] = useState([]);
  const [filterStatus, setFilterStatus] = useState('all');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [assignModal, setAssignModal] = useState(null); // request object
  const [selectedCollector, setSelectedCollector] = useState('');
  const [assigning, setAssigning] = useState(false);

  const fetchData = async () => {
    try {
      const [reqSnap, colSnap] = await Promise.all([
        getDocs(query(collection(db, 'wasteRequests'), orderBy('createdAt', 'desc'))),
        getDocs(query(collection(db, 'users'), where('role', '==', 'collector')))
      ]);
      setRequests(reqSnap.docs.map(d => ({ id: d.id, ...d.data() })));
      setCollectors(colSnap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const filtered = requests.filter(r => {
    const matchStatus = filterStatus === 'all' || r.status === filterStatus;
    const matchSearch = !search ||
      r.providerName?.toLowerCase().includes(search.toLowerCase()) ||
      r.wasteType?.toLowerCase().includes(search.toLowerCase()) ||
      r.pickupAddress?.toLowerCase().includes(search.toLowerCase());
    return matchStatus && matchSearch;
  });

  const handleAssign = async () => {
    if (!selectedCollector) { toast.error('Select a collector'); return; }
    setAssigning(true);
    try {
      const col = collectors.find(c => c.id === selectedCollector);
      await updateDoc(doc(db, 'wasteRequests', assignModal.id), {
        status: 'assigned',
        collectorId: selectedCollector,
        collectorName: col?.name || 'Collector',
        assignedAt: new Date()
      });
      toast.success('Collector assigned successfully!');
      setAssignModal(null);
      setSelectedCollector('');
      fetchData();
    } catch (err) {
      toast.error('Failed to assign collector.');
    } finally {
      setAssigning(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Waste Requests</h2>
          <p className="text-sm text-gray-500">Manage all waste collection requests</p>
        </div>
        <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
          {filtered.length} requests
        </span>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by provider, type, address..."
            className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
          />
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {ALL_STATUSES.map(s => (
            <button
              key={s}
              onClick={() => setFilterStatus(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-colors ${
                filterStatus === s
                  ? 'bg-green-700 text-white'
                  : 'bg-white border border-gray-200 text-gray-600 hover:border-green-400'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100">
                <th className="px-4 py-3 text-left font-medium text-gray-600">Provider</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600">Waste Type</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600">Quantity</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600">Pickup Address</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600">Pickup Date</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600">Status</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600">Collector</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {loading ? (
                <tr><td colSpan={8} className="text-center py-8 text-gray-400">Loading...</td></tr>
              ) : filtered.length === 0 ? (
                <tr><td colSpan={8} className="text-center py-8 text-gray-400">No requests found.</td></tr>
              ) : filtered.map(r => (
                <tr key={r.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3">
                    <p className="font-medium text-gray-800">{r.providerName || '—'}</p>
                    <p className="text-xs text-gray-400">{r.id.slice(0, 8)}...</p>
                  </td>
                  <td className="px-4 py-3 text-gray-600">{r.wasteType}</td>
                  <td className="px-4 py-3 text-gray-600">{formatQuantity(r.estimatedQuantity)}</td>
                  <td className="px-4 py-3 text-gray-600 max-w-xs truncate">{r.pickupAddress}</td>
                  <td className="px-4 py-3 text-gray-600">{r.pickupDate}</td>
                  <td className="px-4 py-3"><StatusBadge status={r.status} /></td>
                  <td className="px-4 py-3 text-gray-600">{r.collectorName || '—'}</td>
                  <td className="px-4 py-3">
                    {r.status === 'pending' && (
                      <button
                        onClick={() => { setAssignModal(r); setSelectedCollector(''); }}
                        className="inline-flex items-center gap-1 bg-green-700 text-white px-3 py-1.5 rounded-lg text-xs font-medium hover:bg-green-800 transition-colors"
                      >
                        <UserCheck size={14} /> Assign
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Assign Modal */}
      {assignModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="font-bold text-lg text-gray-800 mb-1">Assign Collector</h3>
            <p className="text-sm text-gray-500 mb-4">
              Request from <strong>{assignModal.providerName}</strong> — {assignModal.wasteType}, {formatQuantity(assignModal.estimatedQuantity)}
            </p>
            <select
              value={selectedCollector}
              onChange={e => setSelectedCollector(e.target.value)}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500 mb-4"
            >
              <option value="">Select a collector</option>
              {collectors.map(c => (
                <option key={c.id} value={c.id}>{c.name} — {c.location || 'Location N/A'}</option>
              ))}
            </select>
            {collectors.length === 0 && (
              <p className="text-sm text-amber-600 bg-amber-50 px-3 py-2 rounded-lg mb-4">
                No collectors registered yet.
              </p>
            )}
            <div className="flex gap-3">
              <button
                onClick={() => setAssignModal(null)}
                className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-medium hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleAssign}
                disabled={assigning}
                className="flex-1 py-2.5 bg-green-700 text-white rounded-xl text-sm font-medium hover:bg-green-800 disabled:opacity-60"
              >
                {assigning ? 'Assigning...' : 'Assign'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
