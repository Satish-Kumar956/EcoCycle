export { default } from '../../pages/collector/CollectorDashboard';
