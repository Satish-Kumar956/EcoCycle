import React, { useState, useEffect } from 'react';
import { db } from '../../firebase/config';
import { collection, getDocs, addDoc, serverTimestamp, query, orderBy } from 'firebase/firestore';
import { useAuth } from '../../contexts/AuthContext';
import Navbar from '../shared/Navbar';
import {
  Sprout, Search, Filter, ShoppingBag, Phone, MapPin,
  CheckCircle, PlusCircle, Star, ShieldCheck, ArrowRight, X, Sparkles
} from 'lucide-react';
import toast from 'react-hot-toast';

export default function Marketplace() {
  const { currentUser, userProfile } = useAuth();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [orderModal, setOrderModal] = useState(null);
  const [newProductModal, setNewProductModal] = useState(false);

  // Order form state
  const [orderForm, setOrderForm] = useState({
    quantity: 50,
    deliveryAddress: userProfile?.location || '',
    phone: userProfile?.phone || '',
    notes: ''
  });
  const [placingOrder, setPlacingOrder] = useState(false);

  // New product listing state (for fertilizer producers)
  const [newProduct, setNewProduct] = useState({
    title: '',
    pricePerKg: '',
    stockKg: '',
    minOrderKg: 25,
    npk: '1.8 : 0.8 : 1.2',
    description: '',
    badge: '100% Organic Compost'
  });
  const [submittingProduct, setSubmittingProduct] = useState(false);

  const fetchProducts = async () => {
    try {
      const snap = await getDocs(query(collection(db, 'fertilizerProducts'), orderBy('createdAt', 'desc')));
      const list = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setProducts(list);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const filteredProducts = products.filter(p => {
    const q = search.toLowerCase();
    return !search ||
      p.title?.toLowerCase().includes(q) ||
      p.producerName?.toLowerCase().includes(q) ||
      p.description?.toLowerCase().includes(q) ||
      p.location?.toLowerCase().includes(q);
  });

  const handlePlaceOrder = async (e) => {
    e.preventDefault();
    if (!orderModal) return;
    const qty = Number(orderForm.quantity);
    if (!qty || qty <= 0) {
      toast.error('Please enter a valid quantity.');
      return;
    }
    if (orderModal.minOrderKg && qty < orderModal.minOrderKg) {
      toast.error(`Minimum order quantity is ${orderModal.minOrderKg} KG.`);
      return;
    }
    if (qty > orderModal.stockKg) {
      toast.error(`Only ${orderModal.stockKg} KG available in stock.`);
      return;
    }

    setPlacingOrder(true);
    try {
      const orderNum = `ORD-ECO-${Math.floor(1000 + Math.random() * 9000)}`;
      const total = qty * orderModal.pricePerKg;

      await addDoc(collection(db, 'orders'), {
        orderNumber: orderNum,
        buyerId: currentUser?.uid || 'guest_buyer',
        buyerName: userProfile?.name || 'Agri Buyer',
        buyerRole: userProfile?.role || 'farmerNursery',
        productId: orderModal.id,
        productTitle: orderModal.title,
        producerId: orderModal.producerId,
        producerName: orderModal.producerName,
        quantityKg: qty,
        pricePerKg: orderModal.pricePerKg,
        totalAmount: total,
        deliveryAddress: orderForm.deliveryAddress || 'Pickup from Facility',
        phone: orderForm.phone || '+91 98000 00000',
        notes: orderForm.notes,
        status: 'pending',
        orderDate: new Date().toISOString()
      });

      toast.success(`Order #${orderNum} placed successfully! Total: ₹${total}`);
      setOrderModal(null);
      setOrderForm({ quantity: 50, deliveryAddress: '', phone: '', notes: '' });
      fetchProducts();
    } catch (err) {
      toast.error('Failed to submit order.');
      console.error(err);
    } finally {
      setPlacingOrder(false);
    }
  };

  const handleCreateProduct = async (e) => {
    e.preventDefault();
    if (!newProduct.title || !newProduct.pricePerKg || !newProduct.stockKg) {
      toast.error('Please complete all required product fields.');
      return;
    }

    setSubmittingProduct(true);
    try {
      await addDoc(collection(db, 'fertilizerProducts'), {
        title: newProduct.title,
        pricePerKg: Number(newProduct.pricePerKg),
        stockKg: Number(newProduct.stockKg),
        minOrderKg: Number(newProduct.minOrderKg) || 10,
        npk: newProduct.npk || 'Standard NPK',
        description: newProduct.description,
        badge: newProduct.badge || 'Certified Organic',
        producerId: currentUser?.uid || 'user_fertilizer_01',
        producerName: userProfile?.businessName || userProfile?.name || 'Local Fertilizer Producer',
        location: userProfile?.location || 'Agro Zone Industrial Area',
        phone: userProfile?.phone || '+91 98000 00000',
        rating: 4.9,
        reviewsCount: 1,
        createdAt: new Date().toISOString()
      });

      toast.success('Organic fertilizer product listed on Marketplace!');
      setNewProductModal(false);
      setNewProduct({
        title: '',
        pricePerKg: '',
        stockKg: '',
        minOrderKg: 25,
        npk: '1.8 : 0.8 : 1.2',
        description: '',
        badge: '100% Organic Compost'
      });
      fetchProducts();
    } catch (err) {
      toast.error('Failed to add product.');
      console.error(err);
    } finally {
      setSubmittingProduct(false);
    }
  };

  const isFertilizerProducer = userProfile?.role === 'fertilizerProducer' || userProfile?.role === 'admin';

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#F8FAF8', color: '#202820' }}>
      <Navbar />

      {/* Hero Banner */}
      <section className="bg-gradient-to-r from-emerald-800 to-green-700 text-white py-12 px-4 sm:px-6 lg:px-8 shadow-sm">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 bg-emerald-900/50 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-semibold text-emerald-200 mb-3">
              <Sparkles size={13} />
              Closed-Loop Organic Resource Exchange
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
              Organic Fertilizer Marketplace
            </h1>
            <p className="mt-2 text-emerald-100 text-sm sm:text-base leading-relaxed">
              Connect directly with verified organic fertilizer & compost producers. High-quality soil nutrients produced from segregated urban organic waste for farms, orchards & nurseries.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            {isFertilizerProducer && (
              <button
                onClick={() => setNewProductModal(true)}
                className="bg-white text-green-800 hover:bg-emerald-50 px-5 py-3 rounded-xl font-bold text-sm shadow-md flex items-center gap-2 transition hover:-translate-y-0.5"
              >
                <PlusCircle size={18} />
                List Fertilizer Product
              </button>
            )}
          </div>
        </div>
      </section>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search & Statistics Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-8">
          <div className="relative w-full sm:w-96">
            <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search vermicompost, producer, location..."
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600 shadow-sm"
            />
          </div>

          <div className="flex items-center gap-4 text-xs text-gray-500 self-end sm:self-center">
            <span className="flex items-center gap-1 font-medium text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-100">
              <ShieldCheck size={14} /> 100% Certified Lab Verified
            </span>
            <span className="hidden md:inline-block">
              Showing <strong>{filteredProducts.length}</strong> products
            </span>
          </div>
        </div>

        {/* Product Grid */}
        {loading ? (
          <div className="py-20 text-center text-gray-400">Loading marketplace products...</div>
        ) : filteredProducts.length === 0 ? (
          <div className="bg-white rounded-2xl border border-dashed border-gray-200 p-12 text-center">
            <Sprout size={48} className="mx-auto text-emerald-600/40 mb-3" />
            <h3 className="text-lg font-bold text-gray-700">No products found</h3>
            <p className="text-gray-400 text-sm mt-1">Try a different search keyword or list a new batch.</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map(prod => (
              <div
                key={prod.id}
                className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition flex flex-col justify-between overflow-hidden group"
              >
                <div className="p-6">
                  {/* Badge & Rating */}
                  <div className="flex items-center justify-between mb-3">
                    <span className="bg-emerald-50 text-emerald-800 text-xs font-semibold px-2.5 py-1 rounded-full border border-emerald-100">
                      {prod.badge || 'Organic Certified'}
                    </span>
                    <span className="flex items-center gap-1 text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md">
                      <Star size={13} className="fill-amber-400 text-amber-500" /> {prod.rating || 4.8}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-gray-800 group-hover:text-green-700 transition">
                    {prod.title}
                  </h3>

                  <p className="text-xs font-medium text-gray-500 mt-1 flex items-center gap-1">
                    By <span className="text-gray-700 font-semibold">{prod.producerName}</span>
                  </p>

                  <div className="flex items-center gap-1.5 text-xs text-gray-400 mt-1 mb-3">
                    <MapPin size={13} /> {prod.location || 'Agro Zone'}
                  </div>

                  <p className="text-gray-600 text-sm line-clamp-2 leading-relaxed mb-4">
                    {prod.description}
                  </p>

                  {/* NPK Ratio Specification Pill */}
                  <div className="bg-emerald-50/60 rounded-xl p-2.5 mb-4 border border-emerald-100/60 flex items-center justify-between text-xs">
                    <span className="text-emerald-800 font-medium">NPK Nutrient Value:</span>
                    <span className="font-bold text-emerald-900 bg-white px-2 py-0.5 rounded shadow-xs">
                      {prod.npk || 'Standard'}
                    </span>
                  </div>

                  <div className="flex items-baseline justify-between pt-2 border-t border-gray-50">
                    <div>
                      <span className="text-2xl font-black text-emerald-800">₹{prod.pricePerKg}</span>
                      <span className="text-xs text-gray-500 font-medium"> / KG</span>
                    </div>
                    <div className="text-right text-xs text-gray-500">
                      <div>Stock: <strong className="text-gray-800">{prod.stockKg} KG</strong></div>
                      <div>Min: {prod.minOrderKg || 10} KG</div>
                    </div>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="bg-gray-50/70 p-4 border-t border-gray-100 flex items-center gap-2">
                  <a
                    href={`tel:${prod.phone}`}
                    className="p-2.5 bg-white border border-gray-200 hover:border-green-600 rounded-xl text-gray-600 hover:text-green-700 transition shadow-xs"
                    title="Call Producer"
                  >
                    <Phone size={16} />
                  </a>
                  <button
                    onClick={() => {
                      setOrderModal(prod);
                      setOrderForm(prev => ({
                        ...prev,
                        quantity: prod.minOrderKg || 50
                      }));
                    }}
                    className="flex-1 bg-green-700 hover:bg-green-800 text-white font-semibold py-2.5 px-4 rounded-xl text-sm flex items-center justify-center gap-2 shadow-xs transition"
                  >
                    <ShoppingBag size={16} />
                    Place Order
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Place Order Modal */}
      {orderModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl relative border border-gray-100">
            <button
              onClick={() => setOrderModal(null)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
            >
              <X size={20} />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-emerald-100 text-emerald-800 rounded-xl">
                <ShoppingBag size={22} />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-800">Place Fertilizer Order</h3>
                <p className="text-xs text-gray-500">{orderModal.title}</p>
              </div>
            </div>

            <form onSubmit={handlePlaceOrder} className="space-y-4">
              <div className="bg-emerald-50 rounded-xl p-3 border border-emerald-100 text-xs flex justify-between">
                <span>Unit Price: <strong>₹{orderModal.pricePerKg} / KG</strong></span>
                <span>Available: <strong>{orderModal.stockKg} KG</strong></span>
                <span>Minimum: <strong>{orderModal.minOrderKg} KG</strong></span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Quantity Required (KG) *
                </label>
                <input
                  type="number"
                  min={orderModal.minOrderKg || 1}
                  max={orderModal.stockKg}
                  value={orderForm.quantity}
                  onChange={e => setOrderForm({ ...orderForm, quantity: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Delivery Address / Farm Location *
                </label>
                <input
                  type="text"
                  value={orderForm.deliveryAddress}
                  onChange={e => setOrderForm({ ...orderForm, deliveryAddress: e.target.value })}
                  placeholder="Enter village, road, nursery gate number"
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Contact Phone Number *
                </label>
                <input
                  type="text"
                  value={orderForm.phone}
                  onChange={e => setOrderForm({ ...orderForm, phone: e.target.value })}
                  placeholder="+91 98765 43210"
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Special Delivery Instructions
                </label>
                <textarea
                  rows={2}
                  value={orderForm.notes}
                  onChange={e => setOrderForm({ ...orderForm, notes: e.target.value })}
                  placeholder="e.g. Unload at compost storage shed before noon."
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                />
              </div>

              {/* Total Calculation */}
              <div className="bg-gray-50 rounded-xl p-3 border border-gray-200 flex items-center justify-between">
                <span className="text-sm text-gray-600 font-medium">Estimated Order Total:</span>
                <span className="text-xl font-black text-emerald-800">
                  ₹{Number(orderForm.quantity || 0) * orderModal.pricePerKg}
                </span>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setOrderModal(null)}
                  className="px-4 py-2 text-sm text-gray-500 hover:text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={placingOrder}
                  className="bg-green-700 hover:bg-green-800 text-white font-semibold px-6 py-2.5 rounded-xl text-sm shadow-md transition"
                >
                  {placingOrder ? 'Confirming...' : 'Confirm Order'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* New Product Listing Modal (For Fertilizer Producers) */}
      {newProductModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl relative border border-gray-100">
            <button
              onClick={() => setNewProductModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
            >
              <X size={20} />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-emerald-100 text-emerald-800 rounded-xl">
                <PlusCircle size={22} />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-800">List Finished Organic Fertilizer</h3>
                <p className="text-xs text-gray-500">Offer your finished compost to farmers and nurseries</p>
              </div>
            </div>

            <form onSubmit={handleCreateProduct} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Product Title *
                </label>
                <input
                  type="text"
                  value={newProduct.title}
                  onChange={e => setNewProduct({ ...newProduct, title: e.target.value })}
                  placeholder="e.g. BioTerra Enriched Vermicompost"
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Price per KG (₹) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={newProduct.pricePerKg}
                    onChange={e => setNewProduct({ ...newProduct, pricePerKg: e.target.value })}
                    placeholder="15"
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Stock Available (KG) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={newProduct.stockKg}
                    onChange={e => setNewProduct({ ...newProduct, stockKg: e.target.value })}
                    placeholder="1000"
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Min Order Quantity (KG)
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={newProduct.minOrderKg}
                    onChange={e => setNewProduct({ ...newProduct, minOrderKg: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    NPK Ratio
                  </label>
                  <input
                    type="text"
                    value={newProduct.npk}
                    onChange={e => setNewProduct({ ...newProduct, npk: e.target.value })}
                    placeholder="1.8 : 0.8 : 1.2"
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Product Description
                </label>
                <textarea
                  rows={3}
                  value={newProduct.description}
                  onChange={e => setNewProduct({ ...newProduct, description: e.target.value })}
                  placeholder="Describe waste input origins, aging period, moisture content, and recommended crops..."
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setNewProductModal(false)}
                  className="px-4 py-2 text-sm text-gray-500 hover:text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingProduct}
                  className="bg-green-700 hover:bg-green-800 text-white font-semibold px-6 py-2.5 rounded-xl text-sm shadow-md transition"
                >
                  {submittingProduct ? 'Publishing...' : 'Publish Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
