export { default } from '../../pages/provider/ProviderDashboard';
