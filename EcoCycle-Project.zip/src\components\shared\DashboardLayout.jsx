import React from 'react';
import Sidebar from './Sidebar';

export default function DashboardLayout({ children, sidebarItems, title }) {
  return (
    <div className="flex h-screen overflow-hidden" style={{ backgroundColor: '#F8FAF8' }}>
      <Sidebar items={sidebarItems} />
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar */}
        {title && (
          <header className="bg-white border-b border-gray-100 px-6 h-16 flex items-center shadow-sm">
            <h1 className="text-xl font-semibold text-gray-800">{title}</h1>
          </header>
        )}
        {/* Main content */}
        <main className="flex-1 overflow-y-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
