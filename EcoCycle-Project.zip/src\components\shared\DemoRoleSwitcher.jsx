import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate, useLocation } from 'react-router-dom';
import { ROLE_ROUTES, ROLE_LABELS } from '../../utils/helpers';
import { INITIAL_USERS } from '../../firebase/mockData';
import { mockStore } from '../../firebase/firebaseBridge';
import {
  Users, ChevronUp, ChevronDown, RefreshCw, CheckCircle,
  Shield, Truck, Building2, User, Flame, Factory, TreePine, ShoppingBag
} from 'lucide-react';
import toast from 'react-hot-toast';

const ROLE_ICONS = {
  admin: Shield,
  provider: ShoppingBag,
  collector: Truck,
  gaushala: Building2,
  animalOwner: User,
  biogasOperator: Flame,
  fertilizerProducer: Factory,
  farmerNursery: TreePine
};

export default function DemoRoleSwitcher() {
  const [open, setOpen] = useState(false);
  const { currentUser, userProfile, fetchUserProfile } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleSwitch = async (targetUser) => {
    try {
      mockStore.setAuthUser(targetUser);
      if (fetchUserProfile) {
        await fetchUserProfile(targetUser.uid);
      }
      toast.success(`Switched to: ${ROLE_LABELS[targetUser.role] || targetUser.role}`);
      const targetRoute = ROLE_ROUTES[targetUser.role] || '/';
      navigate(targetRoute);
    } catch (e) {
      console.error(e);
      toast.error('Could not switch role');
    }
  };

  const handleResetData = () => {
    if (window.confirm('Reset all demo data back to clean hackathon starting state?')) {
      mockStore.resetStore();
      toast.success('Demo data restored to initial state!');
      window.location.reload();
    }
  };

  const currentRole = userProfile?.role || currentUser?.role || 'admin';

  return (
    <aside
      aria-label="Demo Role Switcher"
      className="fixed bottom-3 right-3 z-50 flex flex-col items-end"
    >
      {/* Panel */}
      {open && (
        <div className="bg-white/95 backdrop-blur-md rounded-2xl shadow-2xl border border-emerald-100 p-4 mb-2 w-80 sm:w-96 text-xs animate-in fade-in slide-in-from-bottom-2 duration-200">
          <div className="flex items-center justify-between pb-2 mb-3 border-b border-gray-100">
            <div className="flex items-center gap-1.5 font-bold text-gray-800 text-sm">
              <Users size={16} className="text-emerald-700" />
              <span>Hackathon Quick Role Switcher</span>
            </div>
            <button
              onClick={handleResetData}
              title="Reset initial demo data"
              className="text-gray-400 hover:text-red-600 flex items-center gap-1 text-[11px] font-medium"
            >
              <RefreshCw size={12} /> Reset Data
            </button>
          </div>

          <p className="text-gray-500 mb-3 text-[11px] leading-tight">
            Click any role to test its dedicated dashboard & permissions instantly without login friction:
          </p>

          <div className="grid grid-cols-2 gap-2 max-h-64 overflow-y-auto pr-1 scrollbar-thin">
            {INITIAL_USERS.map((u) => {
              const isCurrent = currentRole === u.role;
              const Icon = ROLE_ICONS[u.role] || User;
              return (
                <button
                  key={u.id}
                  onClick={() => handleSwitch(u)}
                  className={`flex items-start gap-2 p-2 rounded-xl text-left border transition ${
                    isCurrent
                      ? 'bg-emerald-50 border-emerald-600 text-emerald-950 font-bold shadow-xs'
                      : 'bg-gray-50/70 border-gray-100 hover:bg-emerald-50/40 text-gray-700'
                  }`}
                >
                  <Icon
                    size={16}
                    className={`mt-0.5 shrink-0 ${
                      isCurrent ? 'text-emerald-700' : 'text-gray-400'
                    }`}
                  />
                  <div className="min-w-0">
                    <p className="truncate text-xs font-semibold">
                      {ROLE_LABELS[u.role] || u.role}
                    </p>
                    <p className="text-[10px] text-gray-400 truncate">{u.name}</p>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="mt-3 pt-2 border-t border-gray-100 flex items-center justify-between text-[11px] text-gray-400">
            <span>Current: <strong className="text-emerald-800">{ROLE_LABELS[currentRole] || currentRole}</strong></span>
            <span className="text-emerald-600 font-semibold">● Live Sync</span>
          </div>
        </div>
      )}

      {/* Pill Toggle Button */}
      <button
        onClick={() => setOpen(!open)}
        className="bg-emerald-800 hover:bg-emerald-900 text-white px-4 py-2 rounded-full shadow-lg border border-emerald-700 font-semibold text-xs flex items-center gap-2 transition hover:scale-105"
      >
        <Users size={15} />
        <span>Role: <strong className="font-bold underline">{ROLE_LABELS[currentRole] || 'Admin'}</strong></span>
        {open ? <ChevronDown size={14} /> : <ChevronUp size={14} />}
      </button>
    </aside>
  );
}
