import React from 'react';

export default function StatCard({ title, value, icon: Icon, color = '#16834A', bg = '#E8F5E9', change, suffix = '' }) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 flex items-center gap-4">
      <div
        className="w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0"
        style={{ backgroundColor: bg }}
      >
        <Icon size={24} style={{ color }} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm text-gray-500 truncate">{title}</p>
        <p className="text-2xl font-bold text-gray-800">
          {value ?? '—'}{suffix}
        </p>
        {change !== undefined && (
          <p className={`text-xs mt-0.5 ${change >= 0 ? 'text-green-600' : 'text-red-500'}`}>
            {change >= 0 ? '↑' : '↓'} {Math.abs(change)}% this month
          </p>
        )}
      </div>
    </div>
  );
}
