import React, { useState, useEffect } from 'react';
import { db } from '../../firebase/config';
import { collection, getDocs, addDoc, query, where, orderBy } from 'firebase/firestore';
import { useAuth } from '../../contexts/AuthContext';
import DashboardLayout from '../shared/DashboardLayout';
import StatCard from '../shared/StatCard';
import StatusBadge from '../shared/StatusBadge';
import {
  User, Heart, Package, Clock, PlusCircle, CheckCircle,
  MapPin, Phone, ShieldCheck
} from 'lucide-react';
import toast from 'react-hot-toast';

const sidebarItems = [
  { icon: User, label: 'Owner Profile', path: '/dashboard/animal-owner' },
  { icon: Heart, label: 'Available Feed', path: '/dashboard/animal-owner/feed' },
  { icon: Package, label: 'My Requests', path: '/dashboard/animal-owner/requests' },
];

export default function AnimalOwner() {
  const { currentUser, userProfile, updateUserProfile } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  const [availableFeed, setAvailableFeed] = useState([]);
  const [myRequests, setMyRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  // Profile state
  const [profile, setProfile] = useState({
    name: userProfile?.name || 'Ramesh Patel',
    animalType: userProfile?.animalType || 'Cattle',
    animalCount: userProfile?.animalCount || 15,
    location: userProfile?.location || 'Village Ramnagar, Outer Ring Road',
    phone: userProfile?.phone || '+91 98555 66778'
  });
  const [savingProfile, setSavingProfile] = useState(false);

  // Request state
  const [requestModal, setRequestModal] = useState(false);
  const [requestForm, setRequestForm] = useState({
    requiredQuantity: 30,
    urgency: 'medium',
    notes: 'Green vegetable trimmings and pumpkin peels for dairy cows.'
  });
  const [submittingReq, setSubmittingReq] = useState(false);

  const fetchData = async () => {
    try {
      const feedSnap = await getDocs(
        query(collection(db, 'distributions'), where('category', '==', 'animalFeed'))
      );
      setAvailableFeed(feedSnap.docs.map(d => ({ id: d.id, ...d.data() })));

      const reqSnap = await getDocs(
        query(
          collection(db, 'stakeholderRequirements'),
          where('stakeholderRole', '==', 'animalOwner')
        )
      );
      setMyRequests(reqSnap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSaveProfile = async (e) => {
    e.preventDefault();
    setSavingProfile(true);
    try {
      await updateUserProfile(currentUser?.uid, profile);
      toast.success('Animal owner profile saved!');
    } catch (err) {
      toast.error('Failed to update profile.');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleCreateRequest = async (e) => {
    e.preventDefault();
    if (!requestForm.requiredQuantity || requestForm.requiredQuantity <= 0) {
      toast.error('Enter a valid feed quantity');
      return;
    }
    setSubmittingReq(true);
    try {
      await addDoc(collection(db, 'stakeholderRequirements'), {
        stakeholderId: currentUser?.uid || 'user_animal_01',
        stakeholderName: profile.name,
        stakeholderRole: 'animalOwner',
        category: 'animalFeed',
        animalType: profile.animalType,
        animalCount: profile.animalCount,
        requiredQuantity: Number(requestForm.requiredQuantity),
        urgency: requestForm.urgency,
        notes: requestForm.notes,
        location: profile.location,
        phone: profile.phone,
        status: 'pending',
        createdAt: new Date().toISOString()
      });
      toast.success('Feed request placed with EcoCycle facility!');
      setRequestModal(false);
      setRequestForm({ requiredQuantity: 30, urgency: 'medium', notes: '' });
      fetchData();
    } catch (err) {
      toast.error('Failed to submit feed request.');
    } finally {
      setSubmittingReq(false);
    }
  };

  const totalPoolKg = availableFeed
    .filter(f => f.status === 'available')
    .reduce((acc, f) => acc + (f.availableQuantity || 0), 0);

  return (
    <DashboardLayout sidebarItems={sidebarItems} title="Animal Owner Dashboard">
      <div className="space-y-6 max-w-7xl mx-auto">
        {/* Banner */}
        <div className="bg-gradient-to-r from-emerald-800 to-green-700 text-white rounded-2xl p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3.5 bg-white/10 backdrop-blur rounded-2xl border border-white/20 text-3xl">
              🐄
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-2xl font-black">{profile.name}</h2>
                <span className="bg-emerald-500/30 text-emerald-100 text-xs px-2.5 py-0.5 rounded-full border border-emerald-400/30">
                  Animal Owner
                </span>
              </div>
              <p className="text-emerald-100 text-xs sm:text-sm mt-1 flex flex-wrap items-center gap-4">
                <span className="flex items-center gap-1"><MapPin size={14} /> {profile.location}</span>
                <span className="flex items-center gap-1 font-semibold text-white">
                  🐾 {profile.animalCount} {profile.animalType}s
                </span>
              </p>
            </div>
          </div>

          <button
            onClick={() => setRequestModal(true)}
            className="bg-white text-green-800 hover:bg-emerald-50 font-bold px-5 py-2.5 rounded-xl text-sm shadow flex items-center gap-2 transition hover:-translate-y-0.5"
          >
            <PlusCircle size={18} />
            Request Feed
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Available in Facility"
            value={`${totalPoolKg} KG`}
            icon={Heart}
            color="#16834A"
            bg="#E8F5E9"
          />
          <StatCard
            title="My Registered Animals"
            value={profile.animalCount}
            icon={User}
            color="#2563eb"
            bg="#EFF6FF"
          />
          <StatCard
            title="Animal Type"
            value={profile.animalType}
            icon={ShieldCheck}
            color="#7c3aed"
            bg="#f3e8ff"
          />
          <StatCard
            title="Requests Made"
            value={myRequests.length}
            icon={Package}
            color="#d97706"
            bg="#FEF3C7"
          />
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200 gap-4 text-sm font-semibold">
          <button
            onClick={() => setActiveTab('overview')}
            className={`pb-3 px-2 border-b-2 transition ${
              activeTab === 'overview'
                ? 'border-green-600 text-green-700'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Available Suitable Feed Pool
          </button>
          <button
            onClick={() => setActiveTab('requests')}
            className={`pb-3 px-2 border-b-2 transition ${
              activeTab === 'requests'
                ? 'border-green-600 text-green-700'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            My Feed Requests ({myRequests.length})
          </button>
          <button
            onClick={() => setActiveTab('profile')}
            className={`pb-3 px-2 border-b-2 transition ${
              activeTab === 'profile'
                ? 'border-green-600 text-green-700'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Owner & Animal Profile
          </button>
        </div>

        {/* Tab 1: Available Feed */}
        {activeTab === 'overview' && (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
            <h3 className="font-bold text-gray-800 text-lg mb-4 flex items-center gap-2">
              <Heart size={20} className="text-emerald-600" />
              Available Feed for {profile.animalType}s
            </h3>

            {availableFeed.length === 0 ? (
              <div className="text-center py-10 text-gray-400 border border-dashed border-gray-200 rounded-xl">
                No animal feed currently in available state.
              </div>
            ) : (
              <div className="grid md:grid-cols-2 gap-4">
                {availableFeed.map(feed => (
                  <div key={feed.id} className="p-4 rounded-xl border border-gray-100 bg-emerald-50/20 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded">
                          Batch: {feed.batchId || 'ECO-BATCH'}
                        </span>
                        <StatusBadge status={feed.status} />
                      </div>
                      <p className="font-bold text-gray-800 text-sm mt-2">
                        Organic Vegetable Trimmings & Clean Greens
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        Available Quantity: <strong>{feed.availableQuantity || feed.quantity} KG</strong>
                      </p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-emerald-100/50 flex justify-end">
                      <button
                        onClick={() => {
                          setRequestModal(true);
                          setRequestForm(prev => ({
                            ...prev,
                            requiredQuantity: Math.min(feed.availableQuantity || 20, 30)
                          }));
                        }}
                        className="bg-green-700 hover:bg-green-800 text-white text-xs font-semibold px-4 py-2 rounded-xl transition"
                      >
                        Request from this batch
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Requests History */}
        {activeTab === 'requests' && (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
            <h3 className="font-bold text-gray-800 text-lg mb-4">Feed Request Records</h3>
            {myRequests.length === 0 ? (
              <div className="text-center py-10 text-gray-400 border border-dashed border-gray-200 rounded-xl">
                No requests made yet.
              </div>
            ) : (
              <div className="space-y-3">
                {myRequests.map(r => (
                  <div key={r.id} className="p-4 rounded-xl border border-gray-100 flex items-center justify-between hover:bg-gray-50">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-gray-800">{r.requiredQuantity} KG</span>
                        <StatusBadge status={r.status} />
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        {r.notes || 'Feed requirement'} · Urgency: <strong className="capitalize">{r.urgency}</strong>
                      </p>
                    </div>
                    <span className="text-xs text-gray-400">
                      {new Date(r.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Profile */}
        {activeTab === 'profile' && (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm max-w-2xl">
            <h3 className="font-bold text-gray-800 text-lg mb-4">Animal Details & Contact Information</h3>
            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Your Name</label>
                <input
                  type="text"
                  value={profile.name}
                  onChange={e => setProfile({ ...profile, name: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Animal Type</label>
                  <select
                    value={profile.animalType}
                    onChange={e => setProfile({ ...profile, animalType: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600 bg-white"
                  >
                    <option value="Cattle">Cattle / Cows</option>
                    <option value="Buffalo">Buffalo</option>
                    <option value="Goat">Goat</option>
                    <option value="Sheep">Sheep</option>
                    <option value="Horse">Horse / Equine</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Number of Animals</label>
                  <input
                    type="number"
                    value={profile.animalCount}
                    onChange={e => setProfile({ ...profile, animalCount: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Location / Stable Address</label>
                <input
                  type="text"
                  value={profile.location}
                  onChange={e => setProfile({ ...profile, location: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Phone Number</label>
                <input
                  type="text"
                  value={profile.phone}
                  onChange={e => setProfile({ ...profile, phone: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={savingProfile}
                className="bg-green-700 hover:bg-green-800 text-white font-semibold px-6 py-2.5 rounded-xl text-sm shadow transition"
              >
                {savingProfile ? 'Saving...' : 'Update Details'}
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Modal: Request Feed */}
      {requestModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl relative border border-gray-100">
            <h3 className="text-xl font-bold text-gray-800 mb-1">Request Suitable Animal Feed</h3>
            <p className="text-xs text-gray-500 mb-4">For {profile.animalCount} {profile.animalType}s</p>

            <form onSubmit={handleCreateRequest} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Feed Quantity (KG) *
                </label>
                <input
                  type="number"
                  min="5"
                  value={requestForm.requiredQuantity}
                  onChange={e => setRequestForm({ ...requestForm, requiredQuantity: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Urgency
                </label>
                <select
                  value={requestForm.urgency}
                  onChange={e => setRequestForm({ ...requestForm, urgency: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600 bg-white"
                >
                  <option value="high">High - Immediate requirement</option>
                  <option value="medium">Medium - Within 2-3 days</option>
                  <option value="low">Low - Flexible</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Preferences / Animal Notes
                </label>
                <textarea
                  rows={2}
                  value={requestForm.notes}
                  onChange={e => setRequestForm({ ...requestForm, notes: e.target.value })}
                  placeholder="e.g. Clean leafy greens for calves."
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setRequestModal(false)}
                  className="px-4 py-2 text-sm text-gray-500 hover:text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingReq}
                  className="bg-green-700 hover:bg-green-800 text-white font-semibold px-6 py-2.5 rounded-xl text-sm shadow transition"
                >
                  {submittingReq ? 'Submitting...' : 'Confirm Request'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
