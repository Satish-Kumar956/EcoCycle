import React, { useState, useEffect } from 'react';
import { db } from '../../firebase/config';
import { collection, getDocs, addDoc, query, where, orderBy } from 'firebase/firestore';
import { useAuth } from '../../contexts/AuthContext';
import DashboardLayout from '../shared/DashboardLayout';
import StatCard from '../shared/StatCard';
import StatusBadge from '../shared/StatusBadge';
import {
  Flame, Zap, Package, Clock, PlusCircle, CheckCircle,
  MapPin, Phone, Activity, Gauge, Sparkles
} from 'lucide-react';
import toast from 'react-hot-toast';

const sidebarItems = [
  { icon: Flame, label: 'Plant Overview', path: '/dashboard/biogas' },
  { icon: Zap, label: 'Available Bio-Waste', path: '/dashboard/biogas/feedstock' },
  { icon: Package, label: 'Supply Pipeline', path: '/dashboard/biogas/pipeline' },
];

export default function Biogas() {
  const { currentUser, userProfile, updateUserProfile } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  const [availableWaste, setAvailableWaste] = useState([]);
  const [myRequests, setMyRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  // Plant profile
  const [plant, setPlant] = useState({
    plantName: userProfile?.plantName || userProfile?.name || 'GreenEnergy Bio-Methane Facility',
    capacity: userProfile?.capacity || 2500,
    location: userProfile?.location || 'Industrial Area Phase II, Block E',
    phone: userProfile?.phone || '+91 98666 77889'
  });
  const [savingPlant, setSavingPlant] = useState(false);

  // Request form
  const [requestModal, setRequestModal] = useState(false);
  const [reqForm, setReqForm] = useState({
    requiredQuantity: 200,
    urgency: 'high',
    notes: 'High sugar fruit waste preferred for high methane yield.'
  });
  const [submitting, setSubmitting] = useState(false);

  const fetchData = async () => {
    try {
      const distSnap = await getDocs(
        query(collection(db, 'distributions'), where('category', '==', 'biogas'))
      );
      setAvailableWaste(distSnap.docs.map(d => ({ id: d.id, ...d.data() })));

      const reqSnap = await getDocs(
        query(
          collection(db, 'stakeholderRequirements'),
          where('stakeholderRole', '==', 'biogasOperator')
        )
      );
      setMyRequests(reqSnap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSavePlant = async (e) => {
    e.preventDefault();
    setSavingPlant(true);
    try {
      await updateUserProfile(currentUser?.uid, plant);
      toast.success('Biogas plant parameters updated!');
    } catch (err) {
      toast.error('Failed to update plant info.');
    } finally {
      setSavingPlant(false);
    }
  };

  const handleRequestWaste = async (e) => {
    e.preventDefault();
    const qty = Number(reqForm.requiredQuantity);
    if (!qty || qty <= 0) {
      toast.error('Enter a valid required quantity.');
      return;
    }
    setSubmitting(true);
    try {
      await addDoc(collection(db, 'stakeholderRequirements'), {
        stakeholderId: currentUser?.uid || 'user_biogas_01',
        stakeholderName: plant.plantName,
        stakeholderRole: 'biogasOperator',
        category: 'biogas',
        requiredQuantity: qty,
        urgency: reqForm.urgency,
        notes: reqForm.notes,
        location: plant.location,
        phone: plant.phone,
        status: 'pending',
        createdAt: new Date().toISOString()
      });
      toast.success('Biogas feedstock request submitted to facility!');
      setRequestModal(false);
      setReqForm({ requiredQuantity: 200, urgency: 'high', notes: '' });
      fetchData();
    } catch (err) {
      toast.error('Failed to submit request.');
    } finally {
      setSubmitting(false);
    }
  };

  const totalAvailableKg = availableWaste
    .filter(w => w.status === 'available')
    .reduce((a, b) => a + (b.availableQuantity || 0), 0);

  const totalAllocatedKg = availableWaste
    .filter(w => w.stakeholderId === currentUser?.uid || w.status === 'approved')
    .reduce((a, b) => a + (b.allocatedQuantity || 0), 0);

  // Methane production estimation formula: approx 0.2 m³ biogas per kg organic waste
  const estMethane = Math.round((totalAllocatedKg + 150) * 0.22);

  return (
    <DashboardLayout sidebarItems={sidebarItems} title="Biogas Plant Operator Dashboard">
      <div className="space-y-6 max-w-7xl mx-auto">
        {/* Banner */}
        <div className="bg-gradient-to-r from-amber-700 to-orange-600 text-white rounded-2xl p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3.5 bg-white/10 backdrop-blur rounded-2xl border border-white/20 text-3xl">
              🔥
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-2xl font-black">{plant.plantName}</h2>
                <span className="bg-amber-400/30 text-amber-100 text-xs px-2.5 py-0.5 rounded-full border border-amber-300/30">
                  Clean Energy Plant
                </span>
              </div>
              <p className="text-amber-100 text-xs sm:text-sm mt-1 flex flex-wrap items-center gap-4">
                <span className="flex items-center gap-1"><MapPin size={14} /> {plant.location}</span>
                <span className="flex items-center gap-1"><Gauge size={14} /> Capacity: {plant.capacity} KG / day</span>
                <span className="flex items-center gap-1"><Phone size={14} /> {plant.phone}</span>
              </p>
            </div>
          </div>

          <button
            onClick={() => setRequestModal(true)}
            className="bg-white text-orange-900 hover:bg-orange-50 font-bold px-5 py-2.5 rounded-xl text-sm shadow flex items-center gap-2 transition hover:-translate-y-0.5"
          >
            <PlusCircle size={18} />
            Request Bio-Waste Batch
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Available in Pool"
            value={`${totalAvailableKg} KG`}
            icon={Flame}
            color="#d97706"
            bg="#FEF3C7"
          />
          <StatCard
            title="Est. Biogas Potential"
            value={`${estMethane} m³`}
            icon={Zap}
            color="#2563eb"
            bg="#EFF6FF"
          />
          <StatCard
            title="Daily Digest Capacity"
            value={`${plant.capacity} KG`}
            icon={Activity}
            color="#16834A"
            bg="#E8F5E9"
          />
          <StatCard
            title="Active Requests"
            value={myRequests.length}
            icon={Package}
            color="#7c3aed"
            bg="#f3e8ff"
          />
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200 gap-4 text-sm font-semibold">
          <button
            onClick={() => setActiveTab('overview')}
            className={`pb-3 px-2 border-b-2 transition ${
              activeTab === 'overview'
                ? 'border-orange-600 text-orange-700'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Available Biogas Waste Pool
          </button>
          <button
            onClick={() => setActiveTab('requests')}
            className={`pb-3 px-2 border-b-2 transition ${
              activeTab === 'requests'
                ? 'border-orange-600 text-orange-700'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Feedstock Requests & Supply Pipeline ({myRequests.length})
          </button>
          <button
            onClick={() => setActiveTab('plant')}
            className={`pb-3 px-2 border-b-2 transition ${
              activeTab === 'plant'
                ? 'border-orange-600 text-orange-700'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Plant Specifications
          </button>
        </div>

        {/* Tab 1: Available Waste */}
        {activeTab === 'overview' && (
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-4">
              <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-gray-800 text-lg flex items-center gap-2">
                    <Flame size={20} className="text-orange-600" />
                    High-Calorie Biogas Suitable Waste
                  </h3>
                  <span className="text-xs text-gray-400">Classified by Facility</span>
                </div>

                {availableWaste.length === 0 ? (
                  <div className="text-center py-10 text-gray-400 border border-dashed border-gray-200 rounded-xl">
                    No biogas waste ready for allocation at the moment.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {availableWaste.map(item => (
                      <div
                        key={item.id}
                        className="p-4 rounded-xl border border-gray-100 bg-orange-50/20 hover:bg-orange-50/50 transition flex items-center justify-between"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold uppercase tracking-wider text-orange-800 bg-orange-100 px-2 py-0.5 rounded">
                              Batch: {item.batchId || 'ECO-BATCH'}
                            </span>
                            <StatusBadge status={item.status} />
                          </div>
                          <p className="font-bold text-gray-800 text-sm mt-1">
                            Fruit & Mixed High-Energy Organic Slurry
                          </p>
                          <p className="text-xs text-gray-500 mt-0.5">
                            Available: <strong>{item.availableQuantity || item.quantity} KG</strong> (Batch total: {item.quantity} KG)
                          </p>
                        </div>

                        {item.status === 'available' && (
                          <button
                            onClick={() => {
                              setRequestModal(true);
                              setReqForm(prev => ({
                                ...prev,
                                requiredQuantity: item.availableQuantity || 100
                              }));
                            }}
                            className="bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold px-4 py-2 rounded-xl transition"
                          >
                            Claim Batch
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Sidebar info */}
            <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-6 border border-orange-200/60 text-xs space-y-3">
              <h4 className="font-bold text-orange-950 text-sm flex items-center gap-1.5">
                <Sparkles size={16} /> Bio-Methane Generation
              </h4>
              <p className="text-orange-900 leading-relaxed">
                By routing fermented fruit trimmings, market pulp, and grocery waste to anaerobic digesters, EcoCycle replaces fossil LPG with clean methane and prevents landfill greenhouse gas emissions.
              </p>
              <div className="pt-2 border-t border-orange-200 space-y-1.5 text-orange-950">
                <div className="flex items-center gap-1.5">
                  <CheckCircle size={14} className="text-orange-700" /> Optimal pH & moisture ratio
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle size={14} className="text-orange-700" /> 0% plastic and inorganic contamination
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Requests & Pipeline */}
        {activeTab === 'requests' && (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
            <h3 className="font-bold text-gray-800 text-lg mb-4">Feedstock Requests & Supply Track</h3>
            {myRequests.length === 0 ? (
              <div className="text-center py-10 text-gray-400 border border-dashed border-gray-200 rounded-xl">
                No feedstock requests recorded yet.
              </div>
            ) : (
              <div className="space-y-3">
                {myRequests.map(req => (
                  <div key={req.id} className="p-4 rounded-xl border border-gray-100 flex items-center justify-between hover:bg-gray-50">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-gray-800">{req.requiredQuantity} KG</span>
                        <StatusBadge status={req.status} />
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        {req.notes || 'Feedstock allocation'} · Priority: <strong className="capitalize">{req.urgency}</strong>
                      </p>
                    </div>
                    <span className="text-xs text-gray-400">
                      {new Date(req.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Plant Settings */}
        {activeTab === 'plant' && (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm max-w-2xl">
            <h3 className="font-bold text-gray-800 text-lg mb-4">Biogas Digester Parameters</h3>
            <form onSubmit={handleSavePlant} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Plant Name</label>
                <input
                  type="text"
                  value={plant.plantName}
                  onChange={e => setPlant({ ...plant, plantName: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-600"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Daily Capacity (KG)</label>
                  <input
                    type="number"
                    value={plant.capacity}
                    onChange={e => setPlant({ ...plant, capacity: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-600"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Phone</label>
                  <input
                    type="text"
                    value={plant.phone}
                    onChange={e => setPlant({ ...plant, phone: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-600"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Plant Location</label>
                <input
                  type="text"
                  value={plant.location}
                  onChange={e => setPlant({ ...plant, location: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-600"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={savingPlant}
                className="bg-orange-600 hover:bg-orange-700 text-white font-semibold px-6 py-2.5 rounded-xl text-sm shadow transition"
              >
                {savingPlant ? 'Saving...' : 'Update Plant Data'}
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Modal: Request Bio-Waste */}
      {requestModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl relative border border-gray-100">
            <h3 className="text-xl font-bold text-gray-800 mb-1">Request Biogas Organic Waste</h3>
            <p className="text-xs text-gray-500 mb-4">Request segregated organic feedstock from facility</p>

            <form onSubmit={handleRequestWaste} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Required Waste Tonnage / KG *
                </label>
                <input
                  type="number"
                  min="20"
                  value={reqForm.requiredQuantity}
                  onChange={e => setReqForm({ ...reqForm, requiredQuantity: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-600"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Urgency</label>
                <select
                  value={reqForm.urgency}
                  onChange={e => setReqForm({ ...reqForm, urgency: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-600 bg-white"
                >
                  <option value="high">High - Daily digester replenishment</option>
                  <option value="medium">Medium - Within 48 hours</option>
                  <option value="routine">Routine Pipeline Batch</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Notes / Desired Substrates</label>
                <textarea
                  rows={2}
                  value={reqForm.notes}
                  onChange={e => setReqForm({ ...reqForm, notes: e.target.value })}
                  placeholder="e.g. Citrus / fruit pulp preferred."
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-orange-600"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setRequestModal(false)}
                  className="px-4 py-2 text-sm text-gray-500 hover:text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="bg-orange-600 hover:bg-orange-700 text-white font-semibold px-6 py-2.5 rounded-xl text-sm shadow transition"
                >
                  {submitting ? 'Submitting...' : 'Confirm Request'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
