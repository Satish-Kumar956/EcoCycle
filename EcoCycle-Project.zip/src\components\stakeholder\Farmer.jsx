import React, { useState, useEffect } from 'react';
import { db } from '../../firebase/config';
import { collection, getDocs, addDoc, query, where, orderBy } from 'firebase/firestore';
import { useAuth } from '../../contexts/AuthContext';
import DashboardLayout from '../shared/DashboardLayout';
import StatCard from '../shared/StatCard';
import StatusBadge from '../shared/StatusBadge';
import {
  TreePine, ShoppingBag, Package, Phone, MapPin,
  CheckCircle, PlusCircle, Star, Search, ShieldCheck, ArrowRight
} from 'lucide-react';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';

const sidebarItems = [
  { icon: TreePine, label: 'Farm Overview', path: '/dashboard/farmer' },
  { icon: ShoppingBag, label: 'Fertilizer Catalog', path: '/dashboard/farmer/catalog' },
  { icon: Package, label: 'My Orders', path: '/dashboard/farmer/orders' },
];

export default function Farmer() {
  const { currentUser, userProfile, updateUserProfile } = useAuth();
  const [activeTab, setActiveTab] = useState('overview'); // 'overview' | 'catalog' | 'orders' | 'profile'
  const [products, setProducts] = useState([]);
  const [myOrders, setMyOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  // Order modal state
  const [orderModal, setOrderModal] = useState(null);
  const [orderForm, setOrderForm] = useState({
    quantity: 50,
    deliveryAddress: userProfile?.location || 'Village Khirki, Agri Belt Block B',
    phone: userProfile?.phone || '+91 98888 99001',
    notes: 'Please call before delivery'
  });
  const [ordering, setOrdering] = useState(false);

  // Farm Profile state
  const [farm, setFarm] = useState({
    name: userProfile?.name || 'Anand Green Farms',
    farmName: userProfile?.farmName || 'Anand Organic Orchards & Flora Nursery',
    farmType: userProfile?.farmType || 'Farm',
    location: userProfile?.location || 'Village Khirki, Sector 84 Agri Belt',
    phone: userProfile?.phone || '+91 98888 99001'
  });
  const [savingFarm, setSavingFarm] = useState(false);

  const fetchData = async () => {
    try {
      // 1. Products in marketplace
      const prodSnap = await getDocs(
        query(collection(db, 'fertilizerProducts'), orderBy('createdAt', 'desc'))
      );
      setProducts(prodSnap.docs.map(d => ({ id: d.id, ...d.data() })));

      // 2. Orders placed by this farmer
      const ordSnap = await getDocs(
        query(collection(db, 'orders'), orderBy('orderDate', 'desc'))
      );
      setMyOrders(ordSnap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSaveFarm = async (e) => {
    e.preventDefault();
    setSavingFarm(true);
    try {
      await updateUserProfile(currentUser?.uid, farm);
      toast.success('Farm / Nursery details updated!');
    } catch (err) {
      toast.error('Failed to update details');
    } finally {
      setSavingFarm(false);
    }
  };

  const handlePlaceOrder = async (e) => {
    e.preventDefault();
    if (!orderModal) return;
    const qty = Number(orderForm.quantity);
    if (!qty || qty <= 0) {
      toast.error('Enter valid quantity');
      return;
    }
    if (orderModal.minOrderKg && qty < orderModal.minOrderKg) {
      toast.error(`Minimum order is ${orderModal.minOrderKg} KG`);
      return;
    }

    setOrdering(true);
    try {
      const orderNum = `ORD-ECO-${Math.floor(1000 + Math.random() * 9000)}`;
      const total = qty * orderModal.pricePerKg;

      await addDoc(collection(db, 'orders'), {
        orderNumber: orderNum,
        buyerId: currentUser?.uid || 'user_farmer_01',
        buyerName: farm.farmName,
        buyerRole: 'farmerNursery',
        productId: orderModal.id,
        productTitle: orderModal.title,
        producerId: orderModal.producerId,
        producerName: orderModal.producerName,
        quantityKg: qty,
        pricePerKg: orderModal.pricePerKg,
        totalAmount: total,
        deliveryAddress: orderForm.deliveryAddress,
        phone: orderForm.phone,
        notes: orderForm.notes,
        status: 'pending',
        orderDate: new Date().toISOString()
      });

      toast.success(`Order #${orderNum} placed! Total: ₹${total}`);
      setOrderModal(null);
      fetchData();
    } catch (err) {
      toast.error('Failed to place order');
    } finally {
      setOrdering(false);
    }
  };

  const filtered = products.filter(p => {
    const q = search.toLowerCase();
    return !search ||
      p.title?.toLowerCase().includes(q) ||
      p.producerName?.toLowerCase().includes(q) ||
      p.description?.toLowerCase().includes(q);
  });

  const totalFertilizerReceived = myOrders
    .filter(o => o.status === 'delivered')
    .reduce((a, b) => a + (b.quantityKg || 0), 0);

  return (
    <DashboardLayout sidebarItems={sidebarItems} title="Farmer & Nursery Dashboard">
      <div className="space-y-6 max-w-7xl mx-auto">
        {/* Banner */}
        <div className="bg-gradient-to-r from-emerald-800 to-teal-700 text-white rounded-2xl p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3.5 bg-white/10 backdrop-blur rounded-2xl border border-white/20 text-3xl">
              🌾
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-2xl font-black">{farm.farmName}</h2>
                <span className="bg-emerald-500/30 text-emerald-100 text-xs px-2.5 py-0.5 rounded-full border border-emerald-400/30">
                  {farm.farmType}
                </span>
              </div>
              <p className="text-emerald-100 text-xs sm:text-sm mt-1 flex flex-wrap items-center gap-4">
                <span className="flex items-center gap-1"><MapPin size={14} /> {farm.location}</span>
                <span className="flex items-center gap-1"><Phone size={14} /> {farm.phone}</span>
              </p>
            </div>
          </div>

          <Link
            to="/marketplace"
            className="bg-white text-emerald-800 hover:bg-emerald-50 font-bold px-5 py-2.5 rounded-xl text-sm shadow flex items-center gap-2 transition hover:-translate-y-0.5"
          >
            <ShoppingBag size={18} />
            Explore Marketplace
          </Link>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Available Products"
            value={products.length}
            icon={ShoppingBag}
            color="#16834A"
            bg="#E8F5E9"
          />
          <StatCard
            title="My Orders"
            value={myOrders.length}
            icon={Package}
            color="#2563eb"
            bg="#EFF6FF"
          />
          <StatCard
            title="Organic Applied"
            value={`${totalFertilizerReceived || 150} KG`}
            icon={TreePine}
            color="#0d9488"
            bg="#f0fdfa"
          />
          <StatCard
            title="Chemical Free Ratio"
            value="100%"
            icon={ShieldCheck}
            color="#7c3aed"
            bg="#f3e8ff"
          />
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200 gap-4 text-sm font-semibold">
          <button
            onClick={() => setActiveTab('overview')}
            className={`pb-3 px-2 border-b-2 transition ${
              activeTab === 'overview'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Organic Fertilizer Catalog
          </button>
          <button
            onClick={() => setActiveTab('orders')}
            className={`pb-3 px-2 border-b-2 transition ${
              activeTab === 'orders'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            My Orders & Tracking ({myOrders.length})
          </button>
          <button
            onClick={() => setActiveTab('profile')}
            className={`pb-3 px-2 border-b-2 transition ${
              activeTab === 'profile'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Farm / Nursery Profile
          </button>
        </div>

        {/* Tab 1: Catalog */}
        {activeTab === 'overview' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="relative w-full sm:w-80">
                <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="Search compost by name or NPK..."
                  className="w-full pl-9 pr-4 py-2 border border-gray-200 rounded-xl text-xs sm:text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>
              <span className="text-xs text-gray-400 self-end sm:self-center">
                Prices start from ₹11/KG directly from producers
              </span>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {filtered.map(prod => (
                <div key={prod.id} className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm flex flex-col justify-between hover:shadow-md transition">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs bg-emerald-50 text-emerald-800 px-2.5 py-0.5 rounded-full font-semibold border border-emerald-100">
                        {prod.badge || '100% Organic'}
                      </span>
                      <span className="flex items-center gap-1 text-xs font-bold text-amber-600">
                        <Star size={13} className="fill-amber-400 text-amber-500" /> {prod.rating || 4.9}
                      </span>
                    </div>

                    <h4 className="font-bold text-gray-800 text-base mb-1">{prod.title}</h4>
                    <p className="text-xs text-gray-500 flex items-center gap-1 mb-2">
                      By <strong>{prod.producerName}</strong>
                    </p>
                    <p className="text-xs text-gray-600 line-clamp-2 leading-relaxed mb-3">
                      {prod.description}
                    </p>

                    <div className="bg-emerald-50/60 rounded-xl p-2.5 mb-3 flex items-center justify-between text-xs">
                      <span className="text-emerald-800 font-medium">NPK Value:</span>
                      <strong className="text-emerald-900 bg-white px-2 py-0.5 rounded shadow-xs">
                        {prod.npk || 'Standard'}
                      </strong>
                    </div>

                    <div className="flex items-baseline justify-between pt-1">
                      <div>
                        <span className="text-2xl font-black text-emerald-800">₹{prod.pricePerKg}</span>
                        <span className="text-xs text-gray-500"> / KG</span>
                      </div>
                      <span className="text-xs text-gray-400">Stock: {prod.stockKg} KG</span>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-gray-100 flex items-center gap-2">
                    <a
                      href={`tel:${prod.phone}`}
                      className="p-2 border border-gray-200 rounded-xl text-gray-600 hover:text-green-700"
                      title="Call Producer"
                    >
                      <Phone size={15} />
                    </a>
                    <button
                      onClick={() => {
                        setOrderModal(prod);
                        setOrderForm(prev => ({
                          ...prev,
                          quantity: prod.minOrderKg || 50
                        }));
                      }}
                      className="flex-1 bg-green-700 hover:bg-green-800 text-white font-semibold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow transition"
                    >
                      <ShoppingBag size={14} /> Order Now
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 2: Orders */}
        {activeTab === 'orders' && (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
            <h3 className="font-bold text-gray-800 text-lg mb-4">My Fertilizer Orders & Shipments</h3>
            {myOrders.length === 0 ? (
              <div className="text-center py-10 text-gray-400 border border-dashed border-gray-200 rounded-xl">
                You haven't placed any fertilizer orders yet.
              </div>
            ) : (
              <div className="space-y-3">
                {myOrders.map(ord => (
                  <div key={ord.id} className="p-4 rounded-xl border border-gray-100 bg-gray-50/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-gray-800">{ord.productTitle}</span>
                        <span className="text-xs text-gray-400">#{ord.orderNumber}</span>
                        <StatusBadge status={ord.status} />
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        Supplier: <strong>{ord.producerName}</strong> · Quantity: <strong>{ord.quantityKg} KG</strong> · Total: <strong>₹{ord.totalAmount}</strong>
                      </p>
                      <p className="text-xs text-gray-400 mt-0.5">
                        Deliver to: {ord.deliveryAddress}
                      </p>
                    </div>

                    <div className="text-xs text-gray-400 self-end sm:self-center text-right">
                      <div>Ordered: {new Date(ord.orderDate).toLocaleDateString()}</div>
                      <span className="text-emerald-700 font-semibold uppercase">{ord.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Profile */}
        {activeTab === 'profile' && (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm max-w-2xl">
            <h3 className="font-bold text-gray-800 text-lg mb-4">Farm & Nursery Contact Information</h3>
            <form onSubmit={handleSaveFarm} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Farm / Nursery Name</label>
                <input
                  type="text"
                  value={farm.farmName}
                  onChange={e => setFarm({ ...farm, farmName: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Type</label>
                  <select
                    value={farm.farmType}
                    onChange={e => setFarm({ ...farm, farmType: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 bg-white"
                  >
                    <option value="Farm">Farm / Agriculture</option>
                    <option value="Nursery">Plant Nursery</option>
                    <option value="Orchard">Fruit Orchard</option>
                    <option value="Greenhouse">Commercial Greenhouse</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Phone</label>
                  <input
                    type="text"
                    value={farm.phone}
                    onChange={e => setFarm({ ...farm, phone: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Location / Gate Address</label>
                <input
                  type="text"
                  value={farm.location}
                  onChange={e => setFarm({ ...farm, location: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={savingFarm}
                className="bg-emerald-700 hover:bg-emerald-800 text-white font-semibold px-6 py-2.5 rounded-xl text-sm shadow transition"
              >
                {savingFarm ? 'Saving...' : 'Update Details'}
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Order Modal */}
      {orderModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl relative border border-gray-100">
            <h3 className="text-xl font-bold text-gray-800 mb-1">Place Order for {orderModal.title}</h3>
            <p className="text-xs text-gray-500 mb-4">Direct from {orderModal.producerName}</p>

            <form onSubmit={handlePlaceOrder} className="space-y-4">
              <div className="bg-emerald-50 rounded-xl p-3 border border-emerald-100 text-xs flex justify-between">
                <span>Price: <strong>₹{orderModal.pricePerKg} / KG</strong></span>
                <span>Stock: <strong>{orderModal.stockKg} KG</strong></span>
                <span>Min: <strong>{orderModal.minOrderKg || 10} KG</strong></span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Quantity (KG) *</label>
                <input
                  type="number"
                  min={orderModal.minOrderKg || 1}
                  max={orderModal.stockKg}
                  value={orderForm.quantity}
                  onChange={e => setOrderForm({ ...orderForm, quantity: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Farm Delivery Address *</label>
                <input
                  type="text"
                  value={orderForm.deliveryAddress}
                  onChange={e => setOrderForm({ ...orderForm, deliveryAddress: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Contact Phone *</label>
                <input
                  type="text"
                  value={orderForm.phone}
                  onChange={e => setOrderForm({ ...orderForm, phone: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  required
                />
              </div>

              <div className="bg-gray-50 rounded-xl p-3 flex justify-between items-center text-sm">
                <span className="text-gray-600">Total Price:</span>
                <span className="text-xl font-bold text-emerald-800">
                  ₹{Number(orderForm.quantity || 0) * orderModal.pricePerKg}
                </span>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setOrderModal(null)}
                  className="px-4 py-2 text-sm text-gray-500 hover:text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={ordering}
                  className="bg-emerald-700 hover:bg-emerald-800 text-white font-semibold px-6 py-2.5 rounded-xl text-sm shadow transition"
                >
                  {ordering ? 'Placing Order...' : 'Confirm Order'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
