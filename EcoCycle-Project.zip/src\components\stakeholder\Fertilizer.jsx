import React, { useState, useEffect } from 'react';
import { db } from '../../firebase/config';
import { collection, getDocs, addDoc, updateDoc, doc, query, where, orderBy } from 'firebase/firestore';
import { useAuth } from '../../contexts/AuthContext';
import DashboardLayout from '../shared/DashboardLayout';
import StatCard from '../shared/StatCard';
import StatusBadge from '../shared/StatusBadge';
import {
  Factory, Sprout, Package, ShoppingBag, PlusCircle, CheckCircle,
  MapPin, Phone, Star, ShieldCheck, Tag, Sparkles
} from 'lucide-react';
import toast from 'react-hot-toast';

const sidebarItems = [
  { icon: Factory, label: 'Producer Hub', path: '/dashboard/fertilizer' },
  { icon: Sprout, label: 'Compost Waste Feed', path: '/dashboard/fertilizer/feedstock' },
  { icon: ShoppingBag, label: 'Marketplace Listings', path: '/dashboard/fertilizer/products' },
  { icon: Package, label: 'Customer Orders', path: '/dashboard/fertilizer/orders' },
];

export default function Fertilizer() {
  const { currentUser, userProfile, updateUserProfile } = useAuth();
  const [activeTab, setActiveTab] = useState('overview'); // 'overview' | 'compostWaste' | 'products' | 'orders' | 'profile'
  const [compostWaste, setCompostWaste] = useState([]);
  const [myRequests, setMyRequests] = useState([]);
  const [myProducts, setMyProducts] = useState([]);
  const [customerOrders, setCustomerOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  // Business Profile
  const [business, setBusiness] = useState({
    businessName: userProfile?.businessName || userProfile?.name || 'BioTerra Organic Compost Co.',
    capacity: userProfile?.capacity || 6000,
    location: userProfile?.location || 'Agro Industrial Park, Plot 42',
    phone: userProfile?.phone || '+91 98777 88990'
  });
  const [savingBusiness, setSavingBusiness] = useState(false);

  // Raw Waste Request Form
  const [wasteReqModal, setWasteReqModal] = useState(false);
  const [wasteReqForm, setWasteReqForm] = useState({
    requiredQuantity: 300,
    urgency: 'high',
    notes: 'Vegetable and fruit trimmings for batch windrow composting.'
  });
  const [submittingWasteReq, setSubmittingWasteReq] = useState(false);

  // Marketplace Listing Form
  const [prodModal, setProdModal] = useState(false);
  const [prodForm, setProdForm] = useState({
    title: '',
    pricePerKg: 15,
    stockKg: 1000,
    minOrderKg: 20,
    npk: '1.8 : 0.8 : 1.2',
    description: '',
    badge: '100% Organic Vermicompost'
  });
  const [submittingProd, setSubmittingProd] = useState(false);

  const fetchData = async () => {
    try {
      // 1. Available compostable waste
      const wasteSnap = await getDocs(
        query(collection(db, 'distributions'), where('category', '==', 'compost'))
      );
      setCompostWaste(wasteSnap.docs.map(d => ({ id: d.id, ...d.data() })));

      // 2. Producer's raw waste requests
      const reqSnap = await getDocs(
        query(
          collection(db, 'stakeholderRequirements'),
          where('stakeholderRole', '==', 'fertilizerProducer')
        )
      );
      setMyRequests(reqSnap.docs.map(d => ({ id: d.id, ...d.data() })));

      // 3. Products listed
      const prodSnap = await getDocs(
        query(collection(db, 'fertilizerProducts'), orderBy('createdAt', 'desc'))
      );
      setMyProducts(prodSnap.docs.map(d => ({ id: d.id, ...d.data() })));

      // 4. Customer orders
      const orderSnap = await getDocs(
        query(collection(db, 'orders'), orderBy('orderDate', 'desc'))
      );
      setCustomerOrders(orderSnap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSaveBusiness = async (e) => {
    e.preventDefault();
    setSavingBusiness(true);
    try {
      await updateUserProfile(currentUser?.uid, business);
      toast.success('Business parameters saved!');
    } catch (err) {
      toast.error('Failed to update business details.');
    } finally {
      setSavingBusiness(false);
    }
  };

  const handleRequestCompostWaste = async (e) => {
    e.preventDefault();
    const qty = Number(wasteReqForm.requiredQuantity);
    if (!qty || qty <= 0) {
      toast.error('Please enter a valid required quantity.');
      return;
    }
    setSubmittingWasteReq(true);
    try {
      await addDoc(collection(db, 'stakeholderRequirements'), {
        stakeholderId: currentUser?.uid || 'user_fertilizer_01',
        stakeholderName: business.businessName,
        stakeholderRole: 'fertilizerProducer',
        category: 'compost',
        requiredQuantity: qty,
        urgency: wasteReqForm.urgency,
        notes: wasteReqForm.notes,
        location: business.location,
        phone: business.phone,
        status: 'pending',
        createdAt: new Date().toISOString()
      });
      toast.success('Compostable waste requirement logged with facility!');
      setWasteReqModal(false);
      setWasteReqForm({ requiredQuantity: 300, urgency: 'high', notes: '' });
      fetchData();
    } catch (err) {
      toast.error('Failed to submit request.');
    } finally {
      setSubmittingWasteReq(false);
    }
  };

  const handleCreateProduct = async (e) => {
    e.preventDefault();
    if (!prodForm.title || !prodForm.pricePerKg || !prodForm.stockKg) {
      toast.error('Fill in all required product fields');
      return;
    }
    setSubmittingProd(true);
    try {
      await addDoc(collection(db, 'fertilizerProducts'), {
        title: prodForm.title,
        pricePerKg: Number(prodForm.pricePerKg),
        stockKg: Number(prodForm.stockKg),
        minOrderKg: Number(prodForm.minOrderKg) || 10,
        npk: prodForm.npk,
        description: prodForm.description,
        badge: prodForm.badge,
        producerId: currentUser?.uid || 'user_fertilizer_01',
        producerName: business.businessName,
        location: business.location,
        phone: business.phone,
        rating: 5.0,
        reviewsCount: 1,
        createdAt: new Date().toISOString()
      });
      toast.success('Product published to marketplace!');
      setProdModal(false);
      setProdForm({
        title: '',
        pricePerKg: 15,
        stockKg: 1000,
        minOrderKg: 20,
        npk: '1.8 : 0.8 : 1.2',
        description: '',
        badge: '100% Organic Vermicompost'
      });
      fetchData();
    } catch (err) {
      toast.error('Failed to create product listing.');
    } finally {
      setSubmittingProd(false);
    }
  };

  const handleUpdateOrderStatus = async (orderId, newStatus) => {
    try {
      await updateDoc(doc(db, 'orders', orderId), { status: newStatus });
      toast.success(`Order updated to: ${newStatus}`);
      fetchData();
    } catch (err) {
      toast.error('Failed to update order status');
    }
  };

  const totalCompostAvailable = compostWaste
    .filter(w => w.status === 'available')
    .reduce((a, b) => a + (b.availableQuantity || 0), 0);

  const totalRevenue = customerOrders
    .filter(o => o.status === 'delivered' || o.status === 'shipped')
    .reduce((a, b) => a + (b.totalAmount || 0), 0);

  return (
    <DashboardLayout sidebarItems={sidebarItems} title="Fertilizer Producer Dashboard">
      <div className="space-y-6 max-w-7xl mx-auto">
        {/* Banner */}
        <div className="bg-gradient-to-r from-teal-800 to-emerald-700 text-white rounded-2xl p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3.5 bg-white/10 backdrop-blur rounded-2xl border border-white/20 text-3xl">
              🌱
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-2xl font-black">{business.businessName}</h2>
                <span className="bg-teal-500/30 text-teal-100 text-xs px-2.5 py-0.5 rounded-full border border-teal-400/30">
                  Fertilizer Producer
                </span>
              </div>
              <p className="text-teal-100 text-xs sm:text-sm mt-1 flex flex-wrap items-center gap-4">
                <span className="flex items-center gap-1"><MapPin size={14} /> {business.location}</span>
                <span className="flex items-center gap-1">Monthly Capacity: {business.capacity} KG</span>
                <span className="flex items-center gap-1"><Phone size={14} /> {business.phone}</span>
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setWasteReqModal(true)}
              className="bg-white/10 hover:bg-white/20 text-white border border-white/30 font-semibold px-4 py-2.5 rounded-xl text-sm transition"
            >
              Request Raw Waste
            </button>
            <button
              onClick={() => setProdModal(true)}
              className="bg-white text-emerald-800 hover:bg-emerald-50 font-bold px-5 py-2.5 rounded-xl text-sm shadow flex items-center gap-2 transition hover:-translate-y-0.5"
            >
              <PlusCircle size={18} />
              List Finished Fertilizer
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Available Raw Compost"
            value={`${totalCompostAvailable} KG`}
            icon={Sprout}
            color="#0d9488"
            bg="#f0fdfa"
          />
          <StatCard
            title="Marketplace Listings"
            value={myProducts.length}
            icon={ShoppingBag}
            color="#2563eb"
            bg="#EFF6FF"
          />
          <StatCard
            title="Customer Orders"
            value={customerOrders.length}
            icon={Package}
            color="#d97706"
            bg="#FEF3C7"
          />
          <StatCard
            title="Fulfilled Revenue"
            value={`₹${totalRevenue || 2400}`}
            icon={CheckCircle}
            color="#16834A"
            bg="#E8F5E9"
          />
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200 gap-4 text-sm font-semibold">
          <button
            onClick={() => setActiveTab('overview')}
            className={`pb-3 px-2 border-b-2 transition ${
              activeTab === 'overview'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Raw Waste Supply Pool
          </button>
          <button
            onClick={() => setActiveTab('products')}
            className={`pb-3 px-2 border-b-2 transition ${
              activeTab === 'products'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            My Marketplace Products ({myProducts.length})
          </button>
          <button
            onClick={() => setActiveTab('orders')}
            className={`pb-3 px-2 border-b-2 transition ${
              activeTab === 'orders'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Farmer & Nursery Orders ({customerOrders.length})
          </button>
          <button
            onClick={() => setActiveTab('profile')}
            className={`pb-3 px-2 border-b-2 transition ${
              activeTab === 'profile'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Business Parameters
          </button>
        </div>

        {/* Tab 1: Raw Waste Supply */}
        {activeTab === 'overview' && (
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-4">
              <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-gray-800 text-lg flex items-center gap-2">
                    <Sprout size={20} className="text-teal-600" />
                    Available Compostable Organic Waste
                  </h3>
                  <span className="text-xs text-gray-400">Classified by EcoCycle Facility</span>
                </div>

                {compostWaste.length === 0 ? (
                  <div className="text-center py-10 text-gray-400 border border-dashed border-gray-200 rounded-xl">
                    No segregated compostable batches ready in pool.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {compostWaste.map(item => (
                      <div
                        key={item.id}
                        className="p-4 rounded-xl border border-gray-100 bg-teal-50/20 hover:bg-teal-50/50 transition flex items-center justify-between"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold uppercase tracking-wider text-teal-800 bg-teal-100 px-2 py-0.5 rounded">
                              Batch: {item.batchId || 'ECO-BATCH'}
                            </span>
                            <StatusBadge status={item.status} />
                          </div>
                          <p className="font-bold text-gray-800 text-sm mt-1">
                            Market Vegetable Peelings & Organic Decompostable Matter
                          </p>
                          <p className="text-xs text-gray-500 mt-0.5">
                            Available: <strong>{item.availableQuantity || item.quantity} KG</strong> (Batch total: {item.quantity} KG)
                          </p>
                        </div>

                        {item.status === 'available' && (
                          <button
                            onClick={() => {
                              setWasteReqModal(true);
                              setWasteReqForm(prev => ({
                                ...prev,
                                requiredQuantity: item.availableQuantity || 100
                              }));
                            }}
                            className="bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold px-4 py-2 rounded-xl transition"
                          >
                            Claim Batch
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="bg-gradient-to-br from-teal-50 to-emerald-50 rounded-2xl p-6 border border-teal-200/60 text-xs space-y-3">
              <h4 className="font-bold text-teal-950 text-sm flex items-center gap-1.5">
                <Sparkles size={16} /> Organic Fertilizer Production
              </h4>
              <p className="text-teal-900 leading-relaxed">
                By taking segregated compostable waste from EcoCycle, you convert urban waste into nutrient-dense vermicompost and microbial fertilizer, providing local farmers an affordable alternative to chemical inputs.
              </p>
              <div className="pt-2 border-t border-teal-200 space-y-1.5 text-teal-950">
                <div className="flex items-center gap-1.5">
                  <CheckCircle size={14} className="text-teal-700" /> High C:N balance for ideal composting
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle size={14} className="text-teal-700" /> Zero non-biodegradables
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Products */}
        {activeTab === 'products' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-gray-800 text-lg">My Listed Fertilizer Products</h3>
              <button
                onClick={() => setProdModal(true)}
                className="bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 shadow transition"
              >
                <PlusCircle size={16} /> Add Product Listing
              </button>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {myProducts.map(prod => (
                <div key={prod.id} className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs bg-emerald-50 text-emerald-800 px-2.5 py-0.5 rounded-full font-semibold border border-emerald-100">
                        {prod.badge || 'Organic'}
                      </span>
                      <span className="text-xs font-bold text-emerald-800">
                        ₹{prod.pricePerKg} / KG
                      </span>
                    </div>

                    <h4 className="font-bold text-gray-800 text-base mb-1">{prod.title}</h4>
                    <p className="text-xs text-gray-500 line-clamp-2 mb-3">{prod.description}</p>

                    <div className="bg-gray-50 rounded-xl p-2.5 text-xs text-gray-600 space-y-1">
                      <div className="flex justify-between">
                        <span>Stock Available:</span>
                        <strong className="text-gray-800">{prod.stockKg} KG</strong>
                      </div>
                      <div className="flex justify-between">
                        <span>NPK Ratio:</span>
                        <strong className="text-gray-800">{prod.npk || 'Standard'}</strong>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between text-xs text-gray-400">
                    <span>Min Order: {prod.minOrderKg || 10} KG</span>
                    <span className="text-emerald-700 font-semibold">Active in Market</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: Customer Orders */}
        {activeTab === 'orders' && (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
            <h3 className="font-bold text-gray-800 text-lg mb-4">Incoming Farmer & Nursery Orders</h3>
            {customerOrders.length === 0 ? (
              <div className="text-center py-10 text-gray-400 border border-dashed border-gray-200 rounded-xl">
                No orders received yet.
              </div>
            ) : (
              <div className="space-y-4">
                {customerOrders.map(order => (
                  <div key={order.id} className="p-4 rounded-xl border border-gray-100 bg-gray-50/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-gray-800">{order.productTitle}</span>
                        <span className="text-xs text-gray-400">#{order.orderNumber}</span>
                        <StatusBadge status={order.status} />
                      </div>
                      <p className="text-xs text-gray-600 mt-1">
                        Buyer: <strong>{order.buyerName}</strong> ({order.phone}) · Quantity: <strong>{order.quantityKg} KG</strong> · Amount: <strong>₹{order.totalAmount}</strong>
                      </p>
                      <p className="text-xs text-gray-400 mt-0.5">
                        Address: {order.deliveryAddress}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-center">
                      {order.status === 'pending' && (
                        <button
                          onClick={() => handleUpdateOrderStatus(order.id, 'shipped')}
                          className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition"
                        >
                          Mark Shipped
                        </button>
                      )}
                      {order.status === 'shipped' && (
                        <button
                          onClick={() => handleUpdateOrderStatus(order.id, 'delivered')}
                          className="bg-green-700 hover:bg-green-800 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition"
                        >
                          Mark Delivered
                        </button>
                      )}
                      {order.status === 'delivered' && (
                        <span className="text-xs text-green-700 font-semibold flex items-center gap-1">
                          <CheckCircle size={14} /> Completed
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 4: Profile */}
        {activeTab === 'profile' && (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm max-w-2xl">
            <h3 className="font-bold text-gray-800 text-lg mb-4">Fertilizer Business Parameters</h3>
            <form onSubmit={handleSaveBusiness} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Business Name</label>
                <input
                  type="text"
                  value={business.businessName}
                  onChange={e => setBusiness({ ...business, businessName: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-600"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Monthly Capacity (KG)</label>
                  <input
                    type="number"
                    value={business.capacity}
                    onChange={e => setBusiness({ ...business, capacity: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-600"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Phone</label>
                  <input
                    type="text"
                    value={business.phone}
                    onChange={e => setBusiness({ ...business, phone: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-600"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Facility Address</label>
                <input
                  type="text"
                  value={business.location}
                  onChange={e => setBusiness({ ...business, location: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-600"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={savingBusiness}
                className="bg-teal-700 hover:bg-teal-800 text-white font-semibold px-6 py-2.5 rounded-xl text-sm shadow transition"
              >
                {savingBusiness ? 'Saving...' : 'Update Business Profile'}
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Modal: Request Compostable Raw Waste */}
      {wasteReqModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl relative border border-gray-100">
            <h3 className="text-xl font-bold text-gray-800 mb-1">Request Compostable Waste</h3>
            <p className="text-xs text-gray-500 mb-4">Request raw segregated organic material for composting</p>

            <form onSubmit={handleRequestCompostWaste} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Quantity (KG) *</label>
                <input
                  type="number"
                  min="20"
                  value={wasteReqForm.requiredQuantity}
                  onChange={e => setWasteReqForm({ ...wasteReqForm, requiredQuantity: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-600"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Urgency</label>
                <select
                  value={wasteReqForm.urgency}
                  onChange={e => setWasteReqForm({ ...wasteReqForm, urgency: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-600 bg-white"
                >
                  <option value="high">High - Immediate batch bed setup</option>
                  <option value="medium">Medium - Within 3 days</option>
                  <option value="routine">Routine weekly supply</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Notes / Preferences</label>
                <textarea
                  rows={2}
                  value={wasteReqForm.notes}
                  onChange={e => setWasteReqForm({ ...wasteReqForm, notes: e.target.value })}
                  placeholder="e.g. Fibrous vegetable matter, cabbage trimmings."
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-600"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setWasteReqModal(false)}
                  className="px-4 py-2 text-sm text-gray-500 hover:text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingWasteReq}
                  className="bg-teal-700 hover:bg-teal-800 text-white font-semibold px-6 py-2.5 rounded-xl text-sm shadow transition"
                >
                  {submittingWasteReq ? 'Submitting...' : 'Confirm Request'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: List Finished Product */}
      {prodModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl relative border border-gray-100">
            <h3 className="text-xl font-bold text-gray-800 mb-1">List Finished Fertilizer Product</h3>
            <p className="text-xs text-gray-500 mb-4">Publish your finished organic compost to marketplace</p>

            <form onSubmit={handleCreateProduct} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Product Title *</label>
                <input
                  type="text"
                  value={prodForm.title}
                  onChange={e => setProdForm({ ...prodForm, title: e.target.value })}
                  placeholder="e.g. BioTerra Pure Earthworm Cast"
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Price per KG (₹) *</label>
                  <input
                    type="number"
                    min="1"
                    value={prodForm.pricePerKg}
                    onChange={e => setProdForm({ ...prodForm, pricePerKg: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Stock (KG) *</label>
                  <input
                    type="number"
                    min="1"
                    value={prodForm.stockKg}
                    onChange={e => setProdForm({ ...prodForm, stockKg: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Min Order (KG)</label>
                  <input
                    type="number"
                    min="1"
                    value={prodForm.minOrderKg}
                    onChange={e => setProdForm({ ...prodForm, minOrderKg: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">NPK Value</label>
                  <input
                    type="text"
                    value={prodForm.npk}
                    onChange={e => setProdForm({ ...prodForm, npk: e.target.value })}
                    placeholder="1.8 : 0.8 : 1.2"
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Description</label>
                <textarea
                  rows={2}
                  value={prodForm.description}
                  onChange={e => setProdForm({ ...prodForm, description: e.target.value })}
                  placeholder="Detail curing time, moisture level, weed-free certifications..."
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setProdModal(false)}
                  className="px-4 py-2 text-sm text-gray-500 hover:text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingProd}
                  className="bg-emerald-700 hover:bg-emerald-800 text-white font-semibold px-6 py-2.5 rounded-xl text-sm shadow transition"
                >
                  {submittingProd ? 'Publishing...' : 'List in Marketplace'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
