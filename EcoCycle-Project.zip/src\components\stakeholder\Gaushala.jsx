import React, { useState, useEffect } from 'react';
import { db } from '../../firebase/config';
import { collection, getDocs, addDoc, query, where, orderBy, doc, updateDoc } from 'firebase/firestore';
import { useAuth } from '../../contexts/AuthContext';
import DashboardLayout from '../shared/DashboardLayout';
import StatCard from '../shared/StatCard';
import StatusBadge from '../shared/StatusBadge';
import {
  Building2, Heart, Package, Clock, PlusCircle, CheckCircle,
  MapPin, Phone, AlertCircle, Info, Sparkles
} from 'lucide-react';
import toast from 'react-hot-toast';

const sidebarItems = [
  { icon: Building2, label: 'Gaushala Hub', path: '/dashboard/gaushala' },
  { icon: Heart, label: 'Available Feed', path: '/dashboard/gaushala/available' },
  { icon: Package, label: 'My Feed Requests', path: '/dashboard/gaushala/requests' },
];

export default function Gaushala() {
  const { currentUser, userProfile, updateUserProfile } = useAuth();
  const [activeTab, setActiveTab] = useState('overview'); // 'overview' | 'available' | 'requests'
  const [availableFeed, setAvailableFeed] = useState([]);
  const [myRequests, setMyRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  // Profile edit state
  const [profileForm, setProfileForm] = useState({
    gaushalaName: userProfile?.gaushalaName || userProfile?.name || 'Vrindavan Gaushala',
    animalCount: userProfile?.animalCount || 120,
    location: userProfile?.location || 'NH-48 Bypass, Green Belt Road',
    phone: userProfile?.phone || '+91 98444 55667'
  });
  const [savingProfile, setSavingProfile] = useState(false);

  // Request feed state
  const [requestModal, setRequestModal] = useState(false);
  const [requestForm, setRequestForm] = useState({
    requiredQuantity: 50,
    urgency: 'high',
    notes: 'Clean fresh greens preferred for nursing cows.'
  });
  const [submittingReq, setSubmittingReq] = useState(false);

  const fetchData = async () => {
    try {
      // 1. Fetch available animal feed from distributions
      const feedSnap = await getDocs(
        query(collection(db, 'distributions'), where('category', '==', 'animalFeed'))
      );
      const feedList = feedSnap.docs.map(d => ({ id: d.id, ...d.data() }));
      setAvailableFeed(feedList);

      // 2. Fetch gaushala's specific requirements/allocations
      const reqSnap = await getDocs(
        query(
          collection(db, 'stakeholderRequirements'),
          where('stakeholderRole', '==', 'gaushala')
        )
      );
      setMyRequests(reqSnap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    setSavingProfile(true);
    try {
      await updateUserProfile(currentUser?.uid, profileForm);
      toast.success('Gaushala information updated!');
    } catch (err) {
      toast.error('Failed to update profile.');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleCreateRequest = async (e) => {
    e.preventDefault();
    if (!requestForm.requiredQuantity || requestForm.requiredQuantity <= 0) {
      toast.error('Please enter a valid feed quantity.');
      return;
    }
    setSubmittingReq(true);
    try {
      await addDoc(collection(db, 'stakeholderRequirements'), {
        stakeholderId: currentUser?.uid || 'user_gaushala_01',
        stakeholderName: profileForm.gaushalaName,
        stakeholderRole: 'gaushala',
        category: 'animalFeed',
        requiredQuantity: Number(requestForm.requiredQuantity),
        urgency: requestForm.urgency,
        notes: requestForm.notes,
        location: profileForm.location,
        phone: profileForm.phone,
        status: 'pending',
        createdAt: new Date().toISOString()
      });

      toast.success('Animal feed request registered with facility admin!');
      setRequestModal(false);
      setRequestForm({ requiredQuantity: 50, urgency: 'high', notes: '' });
      fetchData();
    } catch (err) {
      toast.error('Failed to submit feed request.');
    } finally {
      setSubmittingReq(false);
    }
  };

  const totalAvailableKg = availableFeed
    .filter(f => f.status === 'available')
    .reduce((acc, f) => acc + (f.availableQuantity || 0), 0);

  const totalReceivedKg = availableFeed
    .filter(f => f.stakeholderId === currentUser?.uid && f.status === 'delivered')
    .reduce((acc, f) => acc + (f.allocatedQuantity || f.quantity || 0), 0);

  return (
    <DashboardLayout sidebarItems={sidebarItems} title="Gaushala Dashboard">
      <div className="space-y-6 max-w-7xl mx-auto">
        {/* Banner with Profile summary */}
        <div className="bg-gradient-to-r from-emerald-800 to-green-700 text-white rounded-2xl p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3.5 bg-white/10 backdrop-blur rounded-2xl border border-white/20 text-3xl">
              🐄
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-2xl font-black">{profileForm.gaushalaName}</h2>
                <span className="bg-emerald-500/30 text-emerald-100 text-xs px-2.5 py-0.5 rounded-full border border-emerald-400/30">
                  Verified Gaushala
                </span>
              </div>
              <p className="text-emerald-100 text-xs sm:text-sm mt-1 flex flex-wrap items-center gap-4">
                <span className="flex items-center gap-1"><MapPin size={14} /> {profileForm.location}</span>
                <span className="flex items-center gap-1"><Phone size={14} /> {profileForm.phone}</span>
                <span className="flex items-center gap-1 font-semibold text-white">🐮 {profileForm.animalCount} Registered Animals</span>
              </p>
            </div>
          </div>

          <button
            onClick={() => setRequestModal(true)}
            className="bg-white text-green-800 hover:bg-emerald-50 font-bold px-5 py-2.5 rounded-xl text-sm shadow flex items-center gap-2 transition hover:-translate-y-0.5"
          >
            <PlusCircle size={18} />
            Request Animal Feed
          </button>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Available in Pool"
            value={`${totalAvailableKg} KG`}
            icon={Heart}
            color="#16834A"
            bg="#E8F5E9"
          />
          <StatCard
            title="Active Requests"
            value={myRequests.filter(r => r.status === 'pending').length}
            icon={Clock}
            color="#d97706"
            bg="#FEF3C7"
          />
          <StatCard
            title="Cows & Cattle"
            value={profileForm.animalCount}
            icon={Building2}
            color="#2563eb"
            bg="#EFF6FF"
          />
          <StatCard
            title="Allocated Feed"
            value={`${totalReceivedKg || 25} KG`}
            icon={CheckCircle}
            color="#7c3aed"
            bg="#f3e8ff"
          />
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200 gap-4 text-sm font-semibold">
          <button
            onClick={() => setActiveTab('overview')}
            className={`pb-3 px-2 border-b-2 transition ${
              activeTab === 'overview'
                ? 'border-green-600 text-green-700'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Gaushala Overview & Feed Pool
          </button>
          <button
            onClick={() => setActiveTab('requests')}
            className={`pb-3 px-2 border-b-2 transition ${
              activeTab === 'requests'
                ? 'border-green-600 text-green-700'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            My Feed Requests & Allocations ({myRequests.length})
          </button>
          <button
            onClick={() => setActiveTab('profile')}
            className={`pb-3 px-2 border-b-2 transition ${
              activeTab === 'profile'
                ? 'border-green-600 text-green-700'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            Update Gaushala Info
          </button>
        </div>

        {/* Tab 1: Overview & Available Feed */}
        {activeTab === 'overview' && (
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-4">
              <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-gray-800 text-lg flex items-center gap-2">
                    <Heart size={20} className="text-emerald-600" />
                    Available Classified Animal Feed
                  </h3>
                  <span className="text-xs text-gray-400">Inspected & Approved by Facility</span>
                </div>

                {availableFeed.length === 0 ? (
                  <div className="text-center py-8 text-gray-400 border border-dashed border-gray-200 rounded-xl">
                    No segregated animal feed currently waiting for allocation.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {availableFeed.map(feed => (
                      <div
                        key={feed.id}
                        className="p-4 rounded-xl border border-gray-100 bg-gray-50/50 hover:bg-emerald-50/30 transition flex items-center justify-between"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                              Batch: {feed.batchId || 'ECO-BATCH'}
                            </span>
                            <StatusBadge status={feed.status} />
                          </div>
                          <p className="text-sm font-semibold text-gray-800 mt-1">
                            Fresh Organic Greens & Vegetable Trimmings
                          </p>
                          <p className="text-xs text-gray-500 mt-0.5">
                            Available: <strong>{feed.availableQuantity || feed.quantity} KG</strong> (Total batch: {feed.quantity} KG)
                          </p>
                        </div>

                        {feed.status === 'available' && (
                          <button
                            onClick={() => {
                              setRequestModal(true);
                              setRequestForm(prev => ({
                                ...prev,
                                requiredQuantity: feed.availableQuantity || 40
                              }));
                            }}
                            className="bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold px-4 py-2 rounded-xl transition"
                          >
                            Claim Feed
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Side guidelines */}
            <div className="space-y-4">
              <div className="bg-emerald-50/60 rounded-2xl p-6 border border-emerald-100 text-xs space-y-3">
                <h4 className="font-bold text-emerald-900 text-sm flex items-center gap-1.5">
                  <Sparkles size={16} /> Animal Feed Quality Standards
                </h4>
                <p className="text-emerald-800 leading-relaxed">
                  Every batch delivered to Gaushalas is <strong>manually inspected by the facility admin</strong> to ensure it consists only of fresh, non-spoiled vegetable greens, gourds, carrots and cabbage leaves.
                </p>
                <div className="pt-2 border-t border-emerald-200/60 space-y-1.5 text-emerald-900">
                  <div className="flex items-center gap-1.5">
                    <CheckCircle size={14} className="text-emerald-700" /> Segregated from fruit pits & citrus rinds
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle size={14} className="text-emerald-700" /> Free of plastics & chemical contaminants
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle size={14} className="text-emerald-700" /> Dispatched directly within 12 hours of collection
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Requests & Allocations */}
        {activeTab === 'requests' && (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
            <h3 className="font-bold text-gray-800 text-lg mb-4">Gaushala Feed Request History</h3>
            {myRequests.length === 0 ? (
              <div className="text-center py-12 text-gray-400 border border-dashed border-gray-200 rounded-xl">
                No active feed requests submitted yet.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-gray-50 text-gray-500 font-semibold text-xs border-b border-gray-100">
                    <tr>
                      <th className="py-3 px-4">Date</th>
                      <th className="py-3 px-4">Quantity</th>
                      <th className="py-3 px-4">Urgency</th>
                      <th className="py-3 px-4">Notes</th>
                      <th className="py-3 px-4">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {myRequests.map(req => (
                      <tr key={req.id} className="hover:bg-gray-50">
                        <td className="py-3 px-4 text-xs text-gray-500">
                          {new Date(req.createdAt).toLocaleDateString()}
                        </td>
                        <td className="py-3 px-4 font-bold text-gray-800">
                          {req.requiredQuantity} KG
                        </td>
                        <td className="py-3 px-4">
                          <span className={`text-xs px-2 py-0.5 rounded font-semibold ${
                            req.urgency === 'high' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'
                          }`}>
                            {req.urgency}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-xs text-gray-600 max-w-xs truncate">
                          {req.notes || 'Routine cow feed'}
                        </td>
                        <td className="py-3 px-4">
                          <StatusBadge status={req.status} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Profile Form */}
        {activeTab === 'profile' && (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm max-w-2xl">
            <h3 className="font-bold text-gray-800 text-lg mb-4">Gaushala Contact & Animal Details</h3>
            <form onSubmit={handleUpdateProfile} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Gaushala Name</label>
                <input
                  type="text"
                  value={profileForm.gaushalaName}
                  onChange={e => setProfileForm({ ...profileForm, gaushalaName: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Number of Animals</label>
                  <input
                    type="number"
                    value={profileForm.animalCount}
                    onChange={e => setProfileForm({ ...profileForm, animalCount: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Phone Number</label>
                  <input
                    type="text"
                    value={profileForm.phone}
                    onChange={e => setProfileForm({ ...profileForm, phone: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Location & Address</label>
                <input
                  type="text"
                  value={profileForm.location}
                  onChange={e => setProfileForm({ ...profileForm, location: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={savingProfile}
                className="bg-green-700 hover:bg-green-800 text-white font-semibold px-6 py-2.5 rounded-xl text-sm shadow transition"
              >
                {savingProfile ? 'Saving...' : 'Save Gaushala Details'}
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Modal: Request Animal Feed */}
      {requestModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl relative border border-gray-100">
            <h3 className="text-xl font-bold text-gray-800 mb-1">Request Animal Feed</h3>
            <p className="text-xs text-gray-500 mb-4">Submit your gaushala requirement for facility allocation</p>

            <form onSubmit={handleCreateRequest} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Feed Quantity (KG) *
                </label>
                <input
                  type="number"
                  min="5"
                  value={requestForm.requiredQuantity}
                  onChange={e => setRequestForm({ ...requestForm, requiredQuantity: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Urgency Level
                </label>
                <select
                  value={requestForm.urgency}
                  onChange={e => setRequestForm({ ...requestForm, urgency: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600 bg-white"
                >
                  <option value="high">High - Needed within 24 hours</option>
                  <option value="medium">Medium - Within 2-3 days</option>
                  <option value="routine">Routine Weekly Supply</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Special Requirements / Preferred Greens
                </label>
                <textarea
                  rows={2}
                  value={requestForm.notes}
                  onChange={e => setRequestForm({ ...requestForm, notes: e.target.value })}
                  placeholder="e.g. Cabbage, spinach, gourd trimmings preferred."
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-600"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setRequestModal(false)}
                  className="px-4 py-2 text-sm text-gray-500 hover:text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingReq}
                  className="bg-green-700 hover:bg-green-800 text-white font-semibold px-6 py-2.5 rounded-xl text-sm shadow transition"
                >
                  {submittingReq ? 'Submitting...' : 'Submit Request'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
