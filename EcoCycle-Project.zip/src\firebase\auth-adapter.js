import { mockStore } from './firebaseBridge';

export function getAuth(app) {
  return {
    _isMockAuth: true,
    get currentUser() {
      return mockStore.currentAuthUser;
    }
  };
}

export async function signInWithEmailAndPassword(auth, email, password) {
  return mockStore.signInWithEmailAndPassword(email, password);
}

export async function createUserWithEmailAndPassword(auth, email, password) {
  return mockStore.createUserWithEmailAndPassword(email, password);
}

export async function signOut(auth) {
  return mockStore.signOut();
}

export function onAuthStateChanged(auth, callback) {
  return mockStore.onAuthStateChanged(callback);
}

export async function updateProfile(user, data) {
  if (!user) return;
  const current = mockStore.currentAuthUser || user;
  const updated = { ...current, ...data };
  mockStore.setAuthUser(updated);
  return updated;
}
