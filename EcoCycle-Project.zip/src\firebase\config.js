// Firebase configuration for EcoCycle Smart Organic Waste Management System
// Uses environment variables if configured, with built-in resilient fallback for college hackathon showcase

import { getAuth } from './auth-adapter';
import { getFirestore } from './firestore-adapter';
import { getStorage } from './storage-adapter';

// In case the user adds their real Firebase keys in .env
export const firebaseConfig = {
  apiKey: import.meta.env?.VITE_FIREBASE_API_KEY || "AIzaSyDemoEcoCycleKey2026Hackathon",
  authDomain: import.meta.env?.VITE_FIREBASE_AUTH_DOMAIN || "ecocycle-organic-waste.firebaseapp.com",
  projectId: import.meta.env?.VITE_FIREBASE_PROJECT_ID || "ecocycle-organic-waste",
  storageBucket: import.meta.env?.VITE_FIREBASE_STORAGE_BUCKET || "ecocycle-organic-waste.appspot.com",
  messagingSenderId: import.meta.env?.VITE_FIREBASE_MESSAGING_SENDER_ID || "1029384756",
  appId: import.meta.env?.VITE_FIREBASE_APP_ID || "1:1029384756:web:abcdef123456"
};

const app = { name: '[EcoCycle-App]' };

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

export default app;
