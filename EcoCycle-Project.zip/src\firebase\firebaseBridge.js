// High-Fidelity Firebase Bridge & Dual Reactive Adapter for EcoCycle
// Seamlessly operates against real Cloud Firestore / Auth, or local reactive store with full browser persistence

import {
  INITIAL_USERS,
  INITIAL_WASTE_REQUESTS,
  INITIAL_WASTE_BATCHES,
  INITIAL_CLASSIFICATIONS,
  INITIAL_DISTRIBUTIONS,
  INITIAL_REQUIREMENTS,
  INITIAL_FERTILIZER_PRODUCTS,
  INITIAL_ORDERS
} from './mockData';

const STORAGE_KEY = 'ecocycle_firestore_v2';
const AUTH_KEY = 'ecocycle_auth_current_user_v2';

class MockDataStore {
  constructor() {
    this.listeners = new Set();
    this.data = this.loadInitial();
    this.currentAuthUser = this.loadAuthUser();
    this.authListeners = new Set();
  }

  loadInitial() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.warn('Could not read from localStorage, using initial mock data', e);
    }

    const initial = {
      users: [...INITIAL_USERS],
      wasteRequests: [...INITIAL_WASTE_REQUESTS],
      wasteCollections: [],
      wasteBatches: [...INITIAL_WASTE_BATCHES],
      wasteClassifications: [...INITIAL_CLASSIFICATIONS],
      stakeholderRequirements: [...INITIAL_REQUIREMENTS],
      distributions: [...INITIAL_DISTRIBUTIONS],
      fertilizerProducts: [...INITIAL_FERTILIZER_PRODUCTS],
      orders: [...INITIAL_ORDERS],
      notifications: []
    };
    this.persist(initial);
    return initial;
  }

  persist(data = this.data) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (e) {
      console.warn('Failed to save store to localStorage', e);
    }
  }

  resetStore() {
    localStorage.removeItem(STORAGE_KEY);
    this.data = {
      users: [...INITIAL_USERS],
      wasteRequests: [...INITIAL_WASTE_REQUESTS],
      wasteCollections: [],
      wasteBatches: [...INITIAL_WASTE_BATCHES],
      wasteClassifications: [...INITIAL_CLASSIFICATIONS],
      stakeholderRequirements: [...INITIAL_REQUIREMENTS],
      distributions: [...INITIAL_DISTRIBUTIONS],
      fertilizerProducts: [...INITIAL_FERTILIZER_PRODUCTS],
      orders: [...INITIAL_ORDERS],
      notifications: []
    };
    this.persist();
    this.notify();
    return this.data;
  }

  notify() {
    this.persist();
    this.listeners.forEach(cb => {
      try { cb(); } catch (err) { console.error('Store listener error', err); }
    });
  }

  subscribe(cb) {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  }

  // Auth management
  loadAuthUser() {
    try {
      const stored = localStorage.getItem(AUTH_KEY);
      if (stored) return JSON.parse(stored);
    } catch (e) {}
    // Default to admin user for hackathon showcase ease
    return INITIAL_USERS[0];
  }

  setAuthUser(user) {
    this.currentAuthUser = user;
    try {
      if (user) {
        localStorage.setItem(AUTH_KEY, JSON.stringify(user));
      } else {
        localStorage.removeItem(AUTH_KEY);
      }
    } catch (e) {}
    this.authListeners.forEach(cb => cb(user));
  }

  onAuthStateChanged(callback) {
    this.authListeners.add(callback);
    // Asynchronous call matching Firebase behavior
    setTimeout(() => callback(this.currentAuthUser), 10);
    return () => this.authListeners.delete(callback);
  }

  async signInWithEmailAndPassword(email, password) {
    const user = this.data.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (!user) {
      const err = new Error('User not found with this email.');
      err.code = 'auth/user-not-found';
      throw err;
    }
    // Accept demo passwords or matching user id
    this.setAuthUser(user);
    return { user };
  }

  async createUserWithEmailAndPassword(email, password) {
    const existing = this.data.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      const err = new Error('Email is already registered.');
      err.code = 'auth/email-already-in-use';
      throw err;
    }
    const uid = 'usr_' + Date.now().toString(36) + Math.random().toString(36).substr(2, 4);
    const newUser = {
      uid,
      id: uid,
      email,
      name: email.split('@')[0],
      createdAt: new Date().toISOString()
    };
    this.setAuthUser(newUser);
    return { user: newUser };
  }

  async signOut() {
    this.setAuthUser(null);
  }

  // Firestore Mock Operations
  getCollection(name) {
    if (!this.data[name]) {
      this.data[name] = [];
    }
    return this.data[name];
  }

  getDoc(colName, id) {
    const col = this.getCollection(colName);
    const item = col.find(d => String(d.id) === String(id) || String(d.uid) === String(id));
    return item ? { ...item } : null;
  }

  setDoc(colName, id, data, options = {}) {
    const col = this.getCollection(colName);
    const index = col.findIndex(d => String(d.id) === String(id) || String(d.uid) === String(id));
    const cleanData = this.sanitize(data);
    if (index >= 0) {
      col[index] = options.merge ? { ...col[index], ...cleanData, id } : { ...cleanData, id };
    } else {
      col.push({ ...cleanData, id, uid: id });
    }
    this.notify();
    return Promise.resolve();
  }

  addDoc(colName, data) {
    const col = this.getCollection(colName);
    const id = colName.slice(0, 4) + '_' + Date.now().toString(36) + Math.random().toString(36).substr(2, 4);
    const cleanData = this.sanitize(data);
    const doc = { ...cleanData, id };
    col.push(doc);
    this.notify();
    return Promise.resolve({ id, ...doc });
  }

  updateDoc(colName, id, data) {
    const col = this.getCollection(colName);
    const index = col.findIndex(d => String(d.id) === String(id) || String(d.uid) === String(id));
    if (index === -1) {
      // Create if missing for robustness
      const cleanData = this.sanitize(data);
      col.push({ ...cleanData, id });
      this.notify();
      return Promise.resolve();
    }
    const cleanData = this.sanitize(data);
    col[index] = { ...col[index], ...cleanData };
    this.notify();
    return Promise.resolve();
  }

  deleteDoc(colName, id) {
    const col = this.getCollection(colName);
    const index = col.findIndex(d => String(d.id) === String(id) || String(d.uid) === String(id));
    if (index !== -1) {
      col.splice(index, 1);
      this.notify();
    }
    return Promise.resolve();
  }

  sanitize(obj) {
    if (!obj || typeof obj !== 'object') return obj;
    const res = Array.isArray(obj) ? [] : {};
    for (const [k, v] of Object.entries(obj)) {
      if (v && typeof v === 'object' && v._methodName === 'serverTimestamp') {
        res[k] = new Date().toISOString();
      } else if (v instanceof Date) {
        res[k] = v.toISOString();
      } else {
        res[k] = v;
      }
    }
    return res;
  }
}

export const mockStore = new MockDataStore();
