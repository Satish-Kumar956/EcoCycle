import { mockStore } from './firebaseBridge';

export function getFirestore(app) {
  return { _isMockFirestore: true };
}

export function collection(db, collectionName) {
  return {
    type: 'collection',
    name: collectionName,
    path: collectionName
  };
}

export function doc(first, second, third) {
  let colName = '';
  let docId = '';

  if (third !== undefined) {
    // doc(db, 'collectionName', 'id')
    colName = second;
    docId = third;
  } else if (typeof first === 'object' && first?.type === 'collection') {
    // doc(collectionRef, 'id')
    colName = first.name;
    docId = second;
  } else if (typeof second === 'string') {
    // doc(db, 'collection/id')
    const parts = second.split('/');
    if (parts.length >= 2) {
      colName = parts[0];
      docId = parts[1];
    } else {
      colName = second;
      docId = 'temp_' + Date.now();
    }
  }

  return {
    type: 'doc',
    col: colName,
    id: String(docId),
    path: `${colName}/${docId}`
  };
}

export function where(field, op, val) {
  return { type: 'where', field, op, val };
}

export function orderBy(field, direction = 'asc') {
  return { type: 'orderBy', field, direction };
}

export function limit(count) {
  return { type: 'limit', count };
}

export function query(target, ...constraints) {
  const colName = target.type === 'collection' ? target.name : target.colName || 'default';
  const existingConstraints = target.constraints || [];
  return {
    type: 'query',
    colName,
    constraints: [...existingConstraints, ...constraints]
  };
}

export async function getDocs(queryOrCol) {
  const colName = queryOrCol.type === 'collection' ? queryOrCol.name : queryOrCol.colName;
  const constraints = queryOrCol.constraints || [];
  let items = [...mockStore.getCollection(colName)];

  for (const c of constraints) {
    if (c.type === 'where') {
      items = items.filter(item => {
        const val = item[c.field];
        switch (c.op) {
          case '==': return val === c.val;
          case '!=': return val !== c.val;
          case '>': return val > c.val;
          case '>=': return val >= c.val;
          case '<': return val < c.val;
          case '<=': return val <= c.val;
          case 'in': return Array.isArray(c.val) && c.val.includes(val);
          case 'array-contains': return Array.isArray(val) && val.includes(c.val);
          default: return true;
        }
      });
    } else if (c.type === 'orderBy') {
      items.sort((a, b) => {
        const aVal = a[c.field];
        const bVal = b[c.field];
        if (aVal === bVal) return 0;
        if (aVal === undefined || aVal === null) return 1;
        if (bVal === undefined || bVal === null) return -1;
        if (c.direction === 'desc') {
          return aVal > bVal ? -1 : 1;
        }
        return aVal > bVal ? 1 : -1;
      });
    } else if (c.type === 'limit') {
      items = items.slice(0, c.count);
    }
  }

  const docs = items.map(item => ({
    id: item.id || item.uid,
    data: () => ({ ...item }),
    exists: () => true,
    ...item
  }));

  return {
    docs,
    size: docs.length,
    empty: docs.length === 0,
    forEach: (cb) => docs.forEach(cb)
  };
}

export async function getDoc(docRef) {
  const item = mockStore.getDoc(docRef.col, docRef.id);
  return {
    id: docRef.id,
    exists: () => Boolean(item),
    data: () => (item ? { ...item } : undefined)
  };
}

export async function setDoc(docRef, data, options = {}) {
  await mockStore.setDoc(docRef.col, docRef.id, data, options);
}

export async function addDoc(colRef, data) {
  const res = await mockStore.addDoc(colRef.name, data);
  return {
    id: res.id,
    path: `${colRef.name}/${res.id}`
  };
}

export async function updateDoc(docRef, data) {
  await mockStore.updateDoc(docRef.col, docRef.id, data);
}

export async function deleteDoc(docRef) {
  await mockStore.deleteDoc(docRef.col, docRef.id);
}

export function serverTimestamp() {
  return {
    _methodName: 'serverTimestamp',
    toDate: () => new Date(),
    toString: () => new Date().toISOString()
  };
}

export function onSnapshot(target, callback) {
  const run = async () => {
    try {
      if (target.type === 'doc') {
        const snap = await getDoc(target);
        callback(snap);
      } else {
        const snap = await getDocs(target);
        callback(snap);
      }
    } catch (e) {
      console.error('onSnapshot err', e);
    }
  };
  run();
  return mockStore.subscribe(run);
}
