// Pre-seeded initial data for EcoCycle Smart Organic Waste Management System
// Reflects realistic college hackathon scenario with 8 distinct user roles and complete end-to-end workflow

export const INITIAL_USERS = [
  {
    id: 'user_admin_01',
    uid: 'user_admin_01',
    email: 'admin@ecocycle.com',
    name: 'EcoCycle Admin Facility',
    role: 'admin',
    phone: '+91 98000 11000',
    location: 'Central EcoCycle Facility, Sector 12',
    createdAt: '2026-10-25T10:00:00.000Z'
  },
  {
    id: 'user_provider_01',
    uid: 'user_provider_01',
    email: 'provider@greenmarket.com',
    name: 'Metro Wholesale Vegetable Market',
    role: 'provider',
    businessType: 'Vegetable Market',
    phone: '+91 98111 22334',
    location: 'APMC Yard, Gate 3, Sector 19',
    createdAt: '2026-10-26T08:30:00.000Z'
  },
  {
    id: 'user_provider_02',
    uid: 'user_provider_02',
    email: 'freshjuice@cityfruits.com',
    name: 'FreshJuice & Fruit Express',
    role: 'provider',
    businessType: 'Fruit Shop',
    phone: '+91 98222 33445',
    location: 'Shop 42, Civil Lines Market',
    createdAt: '2026-10-26T09:15:00.000Z'
  },
  {
    id: 'user_collector_01',
    uid: 'user_collector_01',
    email: 'collector@ecocycle.com',
    name: 'Rajesh Kumar (Collector)',
    role: 'collector',
    vehicleType: 'Pickup Truck',
    phone: '+91 98333 44556',
    location: 'North Zone Hub, Vehicle #DL-1L-4412',
    createdAt: '2026-10-26T10:00:00.000Z'
  },
  {
    id: 'user_gaushala_01',
    uid: 'user_gaushala_01',
    email: 'gaushala@vrindavan.org',
    name: 'Shri Vrindavan Gaushala Trust',
    role: 'gaushala',
    gaushalaName: 'Shri Vrindavan Gaushala Trust',
    animalCount: 140,
    phone: '+91 98444 55667',
    location: 'NH-48 Bypass, Green Belt Road',
    createdAt: '2026-10-27T11:00:00.000Z'
  },
  {
    id: 'user_animal_01',
    uid: 'user_animal_01',
    email: 'ramesh@animalowner.com',
    name: 'Ramesh Patel (Dairy Owner)',
    role: 'animalOwner',
    animalType: 'Cattle',
    animalCount: 18,
    phone: '+91 98555 66778',
    location: 'Village Ramnagar, Outer Ring Road',
    createdAt: '2026-10-27T12:30:00.000Z'
  },
  {
    id: 'user_biogas_01',
    uid: 'user_biogas_01',
    email: 'operator@biogaspowerearth.com',
    name: 'GreenEnergy Bio-Methane Facility',
    role: 'biogasOperator',
    plantName: 'District Bio-Methane Facility #2',
    capacity: 2500,
    phone: '+91 98666 77889',
    location: 'Industrial Area Phase II, Block E',
    createdAt: '2026-10-27T14:00:00.000Z'
  },
  {
    id: 'user_fertilizer_01',
    uid: 'user_fertilizer_01',
    email: 'contact@purecompost.com',
    name: 'BioTerra Organic Compost Co.',
    role: 'fertilizerProducer',
    businessName: 'BioTerra Organics Ltd.',
    capacity: 6000,
    phone: '+91 98777 88990',
    location: 'Agro Industrial Park, Plot 42',
    createdAt: '2026-10-28T09:00:00.000Z'
  },
  {
    id: 'user_farmer_01',
    uid: 'user_farmer_01',
    email: 'kisan@greenfarms.com',
    name: 'Anand Green Farms & Nursery',
    role: 'farmerNursery',
    farmName: 'Anand Organic Orchards & Flora Nursery',
    farmType: 'Farm',
    phone: '+91 98888 99001',
    location: 'Village Khirki, Sector 84 Agri Belt',
    createdAt: '2026-10-28T10:30:00.000Z'
  }
];

export const INITIAL_WASTE_REQUESTS = [
  {
    id: 'req_01',
    providerId: 'user_provider_01',
    providerName: 'Metro Wholesale Vegetable Market',
    wasteType: 'Vegetables',
    estimatedQuantity: 120,
    actualQuantity: 115,
    pickupAddress: 'APMC Yard, Gate 3, Sector 19',
    pickupDate: '2026-10-29',
    notes: 'Fresh cabbage leaves, cauliflower greens and carrot discards. Clean segregated.',
    status: 'delivered',
    collectorId: 'user_collector_01',
    collectorName: 'Rajesh Kumar (Collector)',
    createdAt: '2026-10-29T08:00:00.000Z',
    deliveredAt: '2026-10-29T11:30:00.000Z'
  },
  {
    id: 'req_02',
    providerId: 'user_provider_02',
    providerName: 'FreshJuice & Fruit Express',
    wasteType: 'Fruits',
    estimatedQuantity: 80,
    actualQuantity: 85,
    pickupAddress: 'Shop 42, Civil Lines Market',
    pickupDate: '2026-10-29',
    notes: 'Sweet lime, orange rinds and watermelon peels. Kept dry in crates.',
    status: 'delivered',
    collectorId: 'user_collector_01',
    collectorName: 'Rajesh Kumar (Collector)',
    createdAt: '2026-10-29T09:00:00.000Z',
    deliveredAt: '2026-10-29T12:45:00.000Z'
  },
  {
    id: 'req_03',
    providerId: 'user_provider_01',
    providerName: 'Metro Wholesale Vegetable Market',
    wasteType: 'Vegetables',
    estimatedQuantity: 140,
    actualQuantity: 135,
    pickupAddress: 'APMC Yard, Block B, Sector 19',
    pickupDate: '2026-10-30',
    notes: 'Palak, methi, tomato trimmings. Suitable for direct cattle feed or composting.',
    status: 'collected',
    collectorId: 'user_collector_01',
    collectorName: 'Rajesh Kumar (Collector)',
    createdAt: '2026-10-30T07:30:00.000Z'
  },
  {
    id: 'req_04',
    providerId: 'user_provider_02',
    providerName: 'FreshJuice & Fruit Express',
    wasteType: 'Mixed Organic Waste',
    estimatedQuantity: 70,
    pickupAddress: 'Shop 42, Civil Lines Market',
    pickupDate: '2026-10-30',
    notes: 'Fruit pulp and peel mix, high moisture.',
    status: 'in_progress',
    collectorId: 'user_collector_01',
    collectorName: 'Rajesh Kumar (Collector)',
    createdAt: '2026-10-30T08:30:00.000Z'
  },
  {
    id: 'req_05',
    providerId: 'user_provider_01',
    providerName: 'Metro Wholesale Vegetable Market',
    wasteType: 'Vegetables',
    estimatedQuantity: 90,
    pickupAddress: 'APMC Shed 6, Sector 19',
    pickupDate: '2026-10-30',
    notes: 'Fresh morning surplus pumpkins and leafy greens.',
    status: 'assigned',
    collectorId: 'user_collector_01',
    collectorName: 'Rajesh Kumar (Collector)',
    createdAt: '2026-10-30T09:00:00.000Z'
  },
  {
    id: 'req_06',
    providerId: 'user_provider_02',
    providerName: 'FreshJuice & Fruit Express',
    wasteType: 'Fruits',
    estimatedQuantity: 50,
    pickupAddress: 'Shop 42, Civil Lines Market',
    pickupDate: '2026-10-31',
    notes: 'Pineapple and citrus peels.',
    status: 'pending',
    createdAt: '2026-10-30T10:00:00.000Z'
  }
];

export const INITIAL_WASTE_BATCHES = [
  {
    id: 'batch_01',
    batchId: 'ECO-261029-A',
    requestId: 'req_01',
    providerId: 'user_provider_01',
    providerName: 'Metro Wholesale Vegetable Market',
    wasteType: 'Vegetables',
    quantity: 115,
    collectionDate: '2026-10-29T11:30:00.000Z',
    status: 'classified',
    notes: 'Manual inspection completed. Cabbage leaves approved for feed.'
  },
  {
    id: 'batch_02',
    batchId: 'ECO-261029-B',
    requestId: 'req_02',
    providerId: 'user_provider_02',
    providerName: 'FreshJuice & Fruit Express',
    wasteType: 'Fruits',
    quantity: 85,
    collectionDate: '2026-10-29T12:45:00.000Z',
    status: 'received', // Ready for Manual Segregation in Admin tab!
    notes: 'Batch arrived at facility. Awaiting manual admin segregation.'
  }
];

export const INITIAL_CLASSIFICATIONS = [
  {
    id: 'class_01',
    batchId: 'batch_01',
    totalQuantity: 115,
    animalFeed: 45,
    biogas: 35,
    compost: 30,
    rejected: 5,
    classifiedAt: '2026-10-29T14:00:00.000Z',
    classifiedBy: 'user_admin_01'
  }
];

export const INITIAL_DISTRIBUTIONS = [
  {
    id: 'dist_feed_01',
    batchId: 'batch_01',
    classificationId: 'class_01',
    category: 'animalFeed',
    quantity: 45,
    availableQuantity: 20,
    allocatedQuantity: 25,
    status: 'approved',
    stakeholderId: 'user_gaushala_01',
    stakeholderName: 'Shri Vrindavan Gaushala Trust',
    createdAt: '2026-10-29T14:15:00.000Z',
    updatedAt: '2026-10-29T15:30:00.000Z'
  },
  {
    id: 'dist_feed_02',
    batchId: 'batch_01',
    classificationId: 'class_01',
    category: 'animalFeed',
    quantity: 20,
    availableQuantity: 20,
    allocatedQuantity: 0,
    status: 'available',
    createdAt: '2026-10-29T14:15:00.000Z'
  },
  {
    id: 'dist_biogas_01',
    batchId: 'batch_01',
    classificationId: 'class_01',
    category: 'biogas',
    quantity: 35,
    availableQuantity: 35,
    allocatedQuantity: 0,
    status: 'available',
    createdAt: '2026-10-29T14:15:00.000Z'
  },
  {
    id: 'dist_compost_01',
    batchId: 'batch_01',
    classificationId: 'class_01',
    category: 'compost',
    quantity: 30,
    availableQuantity: 30,
    allocatedQuantity: 0,
    status: 'available',
    createdAt: '2026-10-29T14:15:00.000Z'
  }
];

export const INITIAL_REQUIREMENTS = [
  {
    id: 'req_stk_01',
    stakeholderId: 'user_gaushala_01',
    stakeholderName: 'Shri Vrindavan Gaushala Trust',
    stakeholderRole: 'gaushala',
    category: 'animalFeed',
    requiredQuantity: 60,
    urgency: 'high',
    notes: 'Green vegetable trimmings, safe cabbage leaves and cucumber ends.',
    status: 'approved',
    createdAt: '2026-10-29T10:00:00.000Z'
  },
  {
    id: 'req_stk_02',
    stakeholderId: 'user_animal_01',
    stakeholderName: 'Ramesh Patel (Dairy Owner)',
    stakeholderRole: 'animalOwner',
    category: 'animalFeed',
    requiredQuantity: 25,
    urgency: 'medium',
    notes: 'Leafy greens for milking cows.',
    status: 'pending',
    createdAt: '2026-10-30T08:00:00.000Z'
  },
  {
    id: 'req_stk_03',
    stakeholderId: 'user_biogas_01',
    stakeholderName: 'GreenEnergy Bio-Methane Facility',
    stakeholderRole: 'biogasOperator',
    category: 'biogas',
    requiredQuantity: 200,
    urgency: 'medium',
    notes: 'High sugar fruit pulp & peels for rapid methane digester feed.',
    status: 'pending',
    createdAt: '2026-10-30T09:00:00.000Z'
  },
  {
    id: 'req_stk_04',
    stakeholderId: 'user_fertilizer_01',
    stakeholderName: 'BioTerra Organic Compost Co.',
    stakeholderRole: 'fertilizerProducer',
    category: 'compost',
    requiredQuantity: 300,
    urgency: 'high',
    notes: 'Fibrous vegetable and fruit waste for microbial composting beds.',
    status: 'pending',
    createdAt: '2026-10-30T09:30:00.000Z'
  }
];

export const INITIAL_FERTILIZER_PRODUCTS = [
  {
    id: 'prod_01',
    title: 'BioTerra Premium Vermicompost',
    producerId: 'user_fertilizer_01',
    producerName: 'BioTerra Organics Ltd.',
    pricePerKg: 16,
    stockKg: 1800,
    minOrderKg: 20,
    npk: '1.8 : 0.9 : 1.2',
    description: 'Enriched vermicompost produced from 100% segregated organic vegetable market waste. Rich in soil humus and beneficial mycorrhizae.',
    rating: 4.9,
    reviewsCount: 38,
    phone: '+91 98777 88990',
    location: 'Agro Industrial Park, Plot 42',
    badge: 'Certified Organic',
    createdAt: '2026-10-25T10:00:00.000Z'
  },
  {
    id: 'prod_02',
    title: 'EarthBloom Microbial Compost',
    producerId: 'user_fertilizer_01',
    producerName: 'BioTerra Organics Ltd.',
    pricePerKg: 11,
    stockKg: 4200,
    minOrderKg: 50,
    npk: '1.5 : 0.6 : 1.0',
    description: 'Thermophilically composted fruit and vegetable organic matter. 45-day mature curing process ensuring zero weed seeds.',
    rating: 4.8,
    reviewsCount: 24,
    phone: '+91 98777 88990',
    location: 'Agro Industrial Park, Plot 42',
    badge: 'Lab Tested',
    createdAt: '2026-10-26T12:00:00.000Z'
  },
  {
    id: 'prod_03',
    title: 'EcoNutrient Neem-Infused Bio-Compost',
    producerId: 'producer_ext_02',
    producerName: 'Kaveri Green Organics',
    pricePerKg: 22,
    stockKg: 950,
    minOrderKg: 25,
    npk: '2.1 : 1.1 : 1.6',
    description: 'Premium organic compost blended with organic cold-pressed neem cake. Natural repellent for soil termites and root grubs.',
    rating: 4.9,
    reviewsCount: 52,
    phone: '+91 98999 11223',
    location: 'Sector 4, Green Belt Outskirts',
    badge: 'Pest Deterrent',
    createdAt: '2026-10-27T15:00:00.000Z'
  }
];

export const INITIAL_ORDERS = [
  {
    id: 'ord_01',
    orderNumber: 'ORD-ECO-881',
    buyerId: 'user_farmer_01',
    buyerName: 'Anand Green Farms & Nursery',
    buyerRole: 'farmerNursery',
    productId: 'prod_01',
    productTitle: 'BioTerra Premium Vermicompost',
    producerId: 'user_fertilizer_01',
    producerName: 'BioTerra Organics Ltd.',
    quantityKg: 150,
    pricePerKg: 16,
    totalAmount: 2400,
    deliveryAddress: 'Village Khirki, Sector 84 Agri Belt',
    phone: '+91 98888 99001',
    status: 'shipped',
    orderDate: '2026-10-29T16:00:00.000Z',
    notes: 'Deliver before 11 AM at nursery gate.'
  }
];
