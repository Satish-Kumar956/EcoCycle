export function getStorage(app) {
  return { _isMockStorage: true };
}

export function ref(storage, path) {
  return { path };
}

export async function uploadBytes(storageRef, file) {
  // Convert to Base64 data URL for local storage demo resilience
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      resolve({
        ref: storageRef,
        metadata: { fullPath: storageRef.path, contentType: file.type },
        _dataUrl: reader.result
      });
    };
    reader.readAsDataURL(file);
  });
}

export async function getDownloadURL(uploadResult) {
  if (uploadResult?._dataUrl) {
    return uploadResult._dataUrl;
  }
  return 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80';
}
