import React from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../components/shared/Navbar';
import {
  Leaf, Truck, Package, ClipboardList, Share2,
  Flame, Sprout, Heart, Users, ArrowRight,
  Building2, User, Factory, TreePine, ChevronRight
} from 'lucide-react';

const PRIMARY = '#16834A';
const LIGHT = '#E8F5E9';

export default function LandingPage() {
  return (
    <div className="min-h-screen" style={{ backgroundColor: '#F8FAF8', color: '#202820' }}>
      <Navbar />

      {/* ── Hero Section ─────────────────────────────── */}
      <section
        className="relative overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #f0fdf4 0%, #dcfce7 50%, #bbf7d0 100%)' }}
      >
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 right-20 w-72 h-72 bg-green-400 rounded-full blur-3xl" />
          <div className="absolute bottom-10 left-10 w-48 h-48 bg-emerald-300 rounded-full blur-2xl" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28">
          <div className="text-center max-w-4xl mx-auto">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-white px-4 py-1.5 rounded-full text-sm font-medium text-green-700 border border-green-200 shadow-sm mb-6">
              <Leaf size={14} />
              Smart Organic Waste Management
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-gray-900 mb-6 leading-tight">
              Turning Organic Waste into{' '}
              <span style={{ color: PRIMARY }}>Valuable Resources</span>
            </h1>

            <p className="text-lg sm:text-xl text-gray-600 mb-8 max-w-2xl mx-auto leading-relaxed">
              EcoCycle connects organic waste providers with stakeholders who transform
              waste into animal feed, biogas, and organic fertilizer — reducing pollution
              and creating value.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Link
                to="/register"
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl text-white font-semibold text-base shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5"
                style={{ backgroundColor: PRIMARY }}
              >
                Get Started <ArrowRight size={18} />
              </Link>
              <Link
                to="/#stakeholders"
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl font-semibold text-base border-2 transition-all hover:-translate-y-0.5"
                style={{ borderColor: PRIMARY, color: PRIMARY, backgroundColor: 'white' }}
              >
                Explore Stakeholders
              </Link>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-3xl mx-auto">
              {[
                { label: 'Waste Providers', value: '500+' },
                { label: 'Gaushalas', value: '50+' },
                { label: 'Farmers', value: '100+' },
                { label: 'KG Waste Recycled', value: '10K+' },
              ].map(s => (
                <div key={s.label} className="bg-white/70 backdrop-blur rounded-xl px-4 py-3 border border-green-100">
                  <p className="text-2xl font-bold" style={{ color: PRIMARY }}>{s.value}</p>
                  <p className="text-xs text-gray-600 mt-0.5">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── 3 Utilization Categories ─────────────────── */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-gray-800 mb-3">
            Three Ways Waste Becomes Valuable
          </h2>
          <p className="text-gray-500 max-w-2xl mx-auto">
            Every kilogram of organic waste has potential. EcoCycle ensures it reaches the right destination.
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              icon: Heart,
              emoji: '🐄',
              title: 'Animal Feed',
              subtitle: 'For Gaushalas & Animal Owners',
              desc: 'Suitable organic waste is cleaned and distributed to Gaushalas, individual cattle owners, and other animal shelters.',
              color: '#16834A',
              bg: '#E8F5E9'
            },
            {
              icon: Flame,
              emoji: '🔥',
              title: 'Biogas Production',
              subtitle: 'For Biogas Plant Operators',
              desc: 'High-energy organic waste is channeled to biogas plants to generate clean renewable energy for communities.',
              color: '#d97706',
              bg: '#FEF3C7'
            },
            {
              icon: Sprout,
              emoji: '🌱',
              title: 'Organic Fertilizer',
              subtitle: 'For Farmers & Nurseries',
              desc: 'Compostable waste is supplied to fertilizer producers who process it into rich organic compost for agriculture.',
              color: '#2563eb',
              bg: '#EFF6FF'
            }
          ].map(c => (
            <div
              key={c.title}
              className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
            >
              <div
                className="w-14 h-14 rounded-xl flex items-center justify-center text-2xl mb-5"
                style={{ backgroundColor: c.bg }}
              >
                {c.emoji}
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-1">{c.title}</h3>
              <p className="text-sm font-medium mb-3" style={{ color: c.color }}>{c.subtitle}</p>
              <p className="text-gray-500 text-sm leading-relaxed">{c.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── How It Works ─────────────────────────────── */}
      <section id="how-it-works" className="py-16" style={{ backgroundColor: LIGHT }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-3">How EcoCycle Works</h2>
            <p className="text-gray-500 max-w-xl mx-auto">
              A simple, transparent process from waste collection to resource distribution.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                step: '01',
                icon: Truck,
                title: 'Submit Collection Request',
                desc: 'Waste providers (markets, households, restaurants) submit waste pickup requests with quantity and location.'
              },
              {
                step: '02',
                icon: Package,
                title: 'Collectors Pick Up Waste',
                desc: 'Assigned waste collectors visit the location, collect the waste, and deliver it to the central facility.'
              },
              {
                step: '03',
                icon: ClipboardList,
                title: 'Admin Classifies Waste',
                desc: 'Admin manually segregates waste into Animal Feed, Biogas, Compost, or Rejected categories.'
              },
              {
                step: '04',
                icon: Share2,
                title: 'Distributed to Stakeholders',
                desc: 'Classified waste is allocated and dispatched to registered Gaushalas, biogas plants, and farmers.'
              }
            ].map((s, i) => (
              <div key={s.step} className="relative">
                <div className="bg-white rounded-2xl p-6 shadow-sm border border-green-100 h-full">
                  <div className="flex items-center gap-3 mb-4">
                    <span className="text-3xl font-black" style={{ color: '#bbf7d0' }}>{s.step}</span>
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: LIGHT }}
                    >
                      <s.icon size={20} style={{ color: PRIMARY }} />
                    </div>
                  </div>
                  <h3 className="font-bold text-gray-800 mb-2">{s.title}</h3>
                  <p className="text-sm text-gray-500 leading-relaxed">{s.desc}</p>
                </div>
                {i < 3 && (
                  <div className="hidden lg:flex absolute top-1/2 -right-4 transform -translate-y-1/2 z-10">
                    <ChevronRight size={24} className="text-green-400" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Stakeholders ─────────────────────────────── */}
      <section id="stakeholders" className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-gray-800 mb-3">Our Stakeholders</h2>
          <p className="text-gray-500 max-w-xl mx-auto">
            EcoCycle serves a diverse ecosystem of waste providers and resource consumers.
          </p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {[
            { icon: Building2, title: 'Gaushalas', desc: 'Cow shelters that receive animal-grade organic feed for cattle care.', color: '#16834A', bg: '#E8F5E9' },
            { icon: User, title: 'Animal Owners', desc: 'Individual livestock owners who can request suitable animal feed.', color: '#7c3aed', bg: '#f3e8ff' },
            { icon: Flame, title: 'Biogas Plants', desc: 'Operators who convert organic waste into renewable biogas energy.', color: '#d97706', bg: '#fef3c7' },
            { icon: Factory, title: 'Fertilizer Producers', desc: 'Businesses that compost organic waste into rich organic fertilizer.', color: '#2563eb', bg: '#eff6ff' },
            { icon: TreePine, title: 'Farmers', desc: 'Agricultural farmers who purchase organic fertilizer for crops.', color: '#059669', bg: '#ecfdf5' },
            { icon: Sprout, title: 'Nursery Owners', desc: 'Nurseries that use organic compost to grow healthy plants and saplings.', color: '#dc2626', bg: '#fef2f2' },
          ].map(s => (
            <div
              key={s.title}
              className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm hover:shadow-md transition-shadow flex items-start gap-4"
            >
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ backgroundColor: s.bg }}
              >
                <s.icon size={22} style={{ color: s.color }} />
              </div>
              <div>
                <h3 className="font-bold text-gray-800 mb-1">{s.title}</h3>
                <p className="text-sm text-gray-500">{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Benefits ─────────────────────────────────── */}
      <section id="about" className="py-16" style={{ backgroundColor: '#202820', color: 'white' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold mb-3">Why EcoCycle?</h2>
            <p className="text-green-300 max-w-xl mx-auto">
              Creating environmental and economic value from organic waste
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Leaf, title: 'Zero Waste Philosophy', desc: 'Every kg of organic waste is redirected away from landfills to useful purposes.' },
              { icon: Users, title: 'Community Impact', desc: 'Connects local waste generators with community stakeholders who need resources.' },
              { icon: Sprout, title: 'Sustainable Agriculture', desc: 'Organic compost reduces the need for chemical fertilizers in farming.' },
              { icon: Flame, title: 'Clean Energy', desc: 'Biogas generation from organic waste provides renewable energy alternatives.' },
            ].map(b => (
              <div key={b.title} className="text-center p-6 rounded-2xl border border-green-900 bg-green-950/50">
                <div className="w-12 h-12 rounded-xl bg-green-800/50 flex items-center justify-center mx-auto mb-4">
                  <b.icon size={22} className="text-green-400" />
                </div>
                <h3 className="font-bold text-lg mb-2">{b.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────── */}
      <section className="py-16" style={{ background: `linear-gradient(135deg, ${PRIMARY}, #0f5e38)` }}>
        <div className="max-w-3xl mx-auto px-4 text-center text-white">
          <Leaf size={48} className="mx-auto mb-4 opacity-80" />
          <h2 className="text-3xl font-bold mb-3">Join the EcoCycle Network</h2>
          <p className="text-green-200 mb-8 text-lg">
            Whether you generate waste or need organic resources, EcoCycle is your platform.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/register"
              className="bg-white font-semibold px-8 py-3.5 rounded-xl hover:bg-green-50 transition-colors"
              style={{ color: PRIMARY }}
            >
              Register Now
            </Link>
            <Link
              to="/marketplace"
              className="border-2 border-white text-white font-semibold px-8 py-3.5 rounded-xl hover:bg-white/10 transition-colors"
            >
              Browse Marketplace
            </Link>
          </div>
        </div>
      </section>

      {/* ── Footer ───────────────────────────────────── */}
      <footer className="bg-gray-900 text-gray-400 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-3 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="bg-green-800 p-1.5 rounded-lg">
                  <Leaf size={18} className="text-green-300" />
                </div>
                <span className="text-lg font-bold text-white">EcoCycle</span>
              </div>
              <p className="text-sm leading-relaxed">
                Smart Organic Waste Management System connecting waste providers with
                Gaushalas, biogas plants, and farmers.
              </p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-3">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                {['Home', 'How It Works', 'Marketplace', 'Login', 'Register'].map(l => (
                  <li key={l}>
                    <Link
                      to={l === 'Home' ? '/' : `/${l.toLowerCase().replace(' ', '-')}`}
                      className="hover:text-green-400 transition-colors"
                    >
                      {l}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-3">Stakeholders</h4>
              <ul className="space-y-2 text-sm">
                {['Gaushalas', 'Animal Owners', 'Biogas Plants', 'Fertilizer Producers', 'Farmers & Nurseries'].map(s => (
                  <li key={s} className="hover:text-green-400 transition-colors cursor-default">{s}</li>
                ))}
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-6 text-center text-sm">
            <p>© {new Date().getFullYear()} EcoCycle – Smart Organic Waste Management System. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
