import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Leaf, Eye, EyeOff, AlertCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { ROLE_ROUTES } from '../utils/helpers';

const ROLES = [
  { value: 'provider', label: 'Waste Provider (Market / Household / Restaurant)' },
  { value: 'collector', label: 'Waste Collector' },
  { value: 'gaushala', label: 'Gaushala' },
  { value: 'animalOwner', label: 'Individual Animal Owner' },
  { value: 'biogasOperator', label: 'Biogas Plant Operator' },
  { value: 'fertilizerProducer', label: 'Fertilizer Producer' },
  { value: 'farmerNursery', label: 'Farmer / Nursery Owner' },
];

const PROVIDER_TYPES = ['Vegetable Market', 'Household', 'Fruit Shop', 'Grocery Store', 'Restaurant'];
const VEHICLE_TYPES = ['Tempo', 'Pickup Truck', 'Auto Rickshaw', 'Bicycle Cart', 'Van'];
const ANIMAL_TYPES = ['Cattle', 'Goat', 'Sheep', 'Buffalo', 'Other'];
const FARM_TYPES = ['Farm', 'Nursery'];

export default function RegisterPage() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '', email: '', password: '', confirmPassword: '', role: '',
    // Common
    phone: '', location: '',
    // Role specific
    businessType: '', vehicleType: '', gaushalaName: '', animalCount: '',
    animalType: '', plantName: '', capacity: '', businessName: '',
    farmName: '', farmType: 'Farm',
  });
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const update = (field, value) => setFormData(prev => ({ ...prev, [field]: value }));

  const getRoleSpecificFields = () => {
    const r = formData.role;
    if (r === 'provider') return (
      <>
        <FormField label="Business Type">
          <select value={formData.businessType} onChange={e => update('businessType', e.target.value)} className={selectClass}>
            <option value="">Select type</option>
            {PROVIDER_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </FormField>
      </>
    );
    if (r === 'collector') return (
      <FormField label="Vehicle Type">
        <select value={formData.vehicleType} onChange={e => update('vehicleType', e.target.value)} className={selectClass}>
          <option value="">Select vehicle</option>
          {VEHICLE_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
        </select>
      </FormField>
    );
    if (r === 'gaushala') return (
      <>
        <FormField label="Gaushala Name">
          <input value={formData.gaushalaName} onChange={e => update('gaushalaName', e.target.value)} placeholder="e.g. Shri Ram Gaushala" className={inputClass} />
        </FormField>
        <FormField label="Number of Animals">
          <input type="number" value={formData.animalCount} onChange={e => update('animalCount', e.target.value)} placeholder="e.g. 50" className={inputClass} />
        </FormField>
      </>
    );
    if (r === 'animalOwner') return (
      <>
        <FormField label="Animal Type">
          <select value={formData.animalType} onChange={e => update('animalType', e.target.value)} className={selectClass}>
            <option value="">Select animal</option>
            {ANIMAL_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </FormField>
        <FormField label="Number of Animals">
          <input type="number" value={formData.animalCount} onChange={e => update('animalCount', e.target.value)} placeholder="e.g. 5" className={inputClass} />
        </FormField>
      </>
    );
    if (r === 'biogasOperator') return (
      <>
        <FormField label="Plant Name">
          <input value={formData.plantName} onChange={e => update('plantName', e.target.value)} placeholder="e.g. Green Energy Biogas Plant" className={inputClass} />
        </FormField>
        <FormField label="Daily Capacity (KG)">
          <input type="number" value={formData.capacity} onChange={e => update('capacity', e.target.value)} placeholder="e.g. 500" className={inputClass} />
        </FormField>
      </>
    );
    if (r === 'fertilizerProducer') return (
      <>
        <FormField label="Business Name">
          <input value={formData.businessName} onChange={e => update('businessName', e.target.value)} placeholder="e.g. Green Compost Co." className={inputClass} />
        </FormField>
        <FormField label="Monthly Capacity (KG)">
          <input type="number" value={formData.capacity} onChange={e => update('capacity', e.target.value)} placeholder="e.g. 2000" className={inputClass} />
        </FormField>
      </>
    );
    if (r === 'farmerNursery') return (
      <>
        <FormField label="Farm / Nursery Name">
          <input value={formData.farmName} onChange={e => update('farmName', e.target.value)} placeholder="e.g. Sunrise Farm" className={inputClass} />
        </FormField>
        <FormField label="Type">
          <select value={formData.farmType} onChange={e => update('farmType', e.target.value)} className={selectClass}>
            {FARM_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </FormField>
      </>
    );
    return null;
  };

  const buildAdditionalData = () => {
    const r = formData.role;
    const base = { phone: formData.phone, location: formData.location };
    if (r === 'provider') return { ...base, businessType: formData.businessType };
    if (r === 'collector') return { ...base, vehicleType: formData.vehicleType };
    if (r === 'gaushala') return { ...base, gaushalaName: formData.gaushalaName, animalCount: Number(formData.animalCount) };
    if (r === 'animalOwner') return { ...base, animalType: formData.animalType, animalCount: Number(formData.animalCount) };
    if (r === 'biogasOperator') return { ...base, plantName: formData.plantName, capacity: Number(formData.capacity) };
    if (r === 'fertilizerProducer') return { ...base, businessName: formData.businessName, capacity: Number(formData.capacity) };
    if (r === 'farmerNursery') return { ...base, farmName: formData.farmName, farmType: formData.farmType };
    return base;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.password || !formData.role) {
      setError('Please fill in all required fields.'); return;
    }
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match.'); return;
    }
    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters.'); return;
    }
    try {
      setError('');
      setLoading(true);
      await register(formData.email, formData.password, formData.name, formData.role, buildAdditionalData());
      navigate(ROLE_ROUTES[formData.role] || '/');
    } catch (err) {
      if (err.code === 'auth/email-already-in-use') {
        setError('An account with this email already exists.');
      } else {
        setError(err.message || 'Registration failed.');
      }
    } finally {
      setLoading(false);
    }
  };

  const inputClass = "w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent text-sm";
  const selectClass = "w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent text-sm bg-white";

  return (
    <div
      className="min-h-screen flex items-center justify-center px-4 py-8"
      style={{ background: 'linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%)' }}
    >
      <div className="w-full max-w-lg">
        {/* Logo */}
        <div className="text-center mb-6">
          <Link to="/" className="inline-flex items-center gap-2 mb-3">
            <div className="bg-green-700 p-2 rounded-xl">
              <Leaf size={22} className="text-white" />
            </div>
            <span className="text-2xl font-bold text-green-800">EcoCycle</span>
          </Link>
          <h1 className="text-2xl font-bold text-gray-800">Create your account</h1>
          <p className="text-gray-500 text-sm mt-1">Join the organic waste management network</p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8 border border-green-100">
          {error && (
            <div className="flex items-center gap-2 bg-red-50 text-red-700 px-4 py-3 rounded-xl mb-5 text-sm border border-red-100">
              <AlertCircle size={16} className="flex-shrink-0" />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Basic Info */}
            <FormField label="Full Name *">
              <input
                value={formData.name}
                onChange={e => update('name', e.target.value)}
                placeholder="Your full name"
                className={inputClass}
                required
              />
            </FormField>

            <FormField label="Email Address *">
              <input
                type="email"
                value={formData.email}
                onChange={e => update('email', e.target.value)}
                placeholder="you@example.com"
                className={inputClass}
                required
              />
            </FormField>

            <FormField label="Register As *">
              <select
                value={formData.role}
                onChange={e => update('role', e.target.value)}
                className={selectClass}
                required
              >
                <option value="">Select your role</option>
                {ROLES.map(r => (
                  <option key={r.value} value={r.value}>{r.label}</option>
                ))}
              </select>
            </FormField>

            <FormField label="Phone Number">
              <input
                type="tel"
                value={formData.phone}
                onChange={e => update('phone', e.target.value)}
                placeholder="+91 98765 43210"
                className={inputClass}
              />
            </FormField>

            <FormField label="Location / Address">
              <input
                value={formData.location}
                onChange={e => update('location', e.target.value)}
                placeholder="City, State"
                className={inputClass}
              />
            </FormField>

            {/* Role-specific fields */}
            {formData.role && getRoleSpecificFields()}

            <FormField label="Password *">
              <div className="relative">
                <input
                  type={showPass ? 'text' : 'password'}
                  value={formData.password}
                  onChange={e => update('password', e.target.value)}
                  placeholder="Min. 6 characters"
                  className={inputClass + ' pr-12'}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
                >
                  {showPass ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </FormField>

            <FormField label="Confirm Password *">
              <input
                type="password"
                value={formData.confirmPassword}
                onChange={e => update('confirmPassword', e.target.value)}
                placeholder="Re-enter password"
                className={inputClass}
                required
              />
            </FormField>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 px-4 rounded-xl text-white font-semibold text-sm transition-all hover:opacity-90 disabled:opacity-60 mt-2"
              style={{ backgroundColor: '#16834A' }}
            >
              {loading ? 'Creating Account...' : 'Create Account'}
            </button>
          </form>

          <p className="text-center text-sm text-gray-500 mt-5">
            Already have an account?{' '}
            <Link to="/login" className="text-green-700 font-medium hover:underline">
              Sign in
            </Link>
          </p>
        </div>

        <p className="text-center text-xs text-gray-400 mt-4">
          Admin accounts are created by system administrators only.
        </p>
      </div>
    </div>
  );
}

function FormField({ label, children }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1.5">{label}</label>
      {children}
    </div>
  );
}
