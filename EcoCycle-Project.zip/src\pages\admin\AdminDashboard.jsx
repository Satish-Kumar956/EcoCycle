import React, { useState, useEffect } from 'react';
import { db } from '../../firebase/config';
import { collection, query, getDocs, orderBy, where, limit } from 'firebase/firestore';
import {
  LayoutDashboard, ClipboardList, Truck, Layers,
  Users, Package, BarChart3, Settings
} from 'lucide-react';
import DashboardLayout from '../../components/shared/DashboardLayout';
import { Routes, Route, Navigate } from 'react-router-dom';
import Overview from '../../components/admin/Overview';
import WasteRequests from '../../components/admin/WasteRequests';
import WasteCollections from '../../components/admin/WasteCollections';
import ManualSegregation from '../../components/admin/ManualSegregation';
import StakeholderDirectory from '../../components/admin/StakeholderDirectory';
import DistributionManager from '../../components/admin/DistributionManager';
import Reports from '../../components/admin/Reports';
import AdminSettings from '../../components/admin/AdminSettings';

const sidebarItems = [
  { icon: LayoutDashboard, label: 'Overview', path: '/dashboard/admin' },
  { icon: ClipboardList, label: 'Waste Requests', path: '/dashboard/admin/requests' },
  { icon: Truck, label: 'Waste Collections', path: '/dashboard/admin/collections' },
  { icon: Layers, label: 'Manual Segregation', path: '/dashboard/admin/segregation' },
  { icon: Users, label: 'Stakeholders', path: '/dashboard/admin/stakeholders' },
  { icon: Package, label: 'Distribution', path: '/dashboard/admin/distribution' },
  { icon: BarChart3, label: 'Reports', path: '/dashboard/admin/reports' },
  { icon: Settings, label: 'Settings', path: '/dashboard/admin/settings' },
];

export default function AdminDashboard() {
  return (
    <DashboardLayout sidebarItems={sidebarItems}>
      <Routes>
        <Route index element={<Overview />} />
        <Route path="requests" element={<WasteRequests />} />
        <Route path="collections" element={<WasteCollections />} />
        <Route path="segregation" element={<ManualSegregation />} />
        <Route path="stakeholders" element={<StakeholderDirectory />} />
        <Route path="distribution" element={<DistributionManager />} />
        <Route path="reports" element={<Reports />} />
        <Route path="settings" element={<AdminSettings />} />
        <Route path="*" element={<Navigate to="/dashboard/admin" replace />} />
      </Routes>
    </DashboardLayout>
  );
}
