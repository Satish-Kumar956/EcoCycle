import React, { useState, useEffect } from 'react';
import { db } from '../../firebase/config';
import { collection, getDocs, doc, updateDoc, query, where, orderBy, serverTimestamp } from 'firebase/firestore';
import { useAuth } from '../../contexts/AuthContext';
import DashboardLayout from '../../components/shared/DashboardLayout';
import { Routes, Route, Navigate } from 'react-router-dom';
import { LayoutDashboard, Truck, CheckCircle, Phone } from 'lucide-react';
import StatCard from '../../components/shared/StatCard';
import StatusBadge from '../../components/shared/StatusBadge';
import { formatDate, formatQuantity } from '../../utils/helpers';
import toast from 'react-hot-toast';

const sidebarItems = [
  { icon: LayoutDashboard, label: 'Overview', path: '/dashboard/collector' },
  { icon: Truck, label: 'Assigned Pickups', path: '/dashboard/collector/pickups' },
];

const STATUS_FLOW = {
  assigned: { next: 'in_progress', label: 'Start Collection' },
  in_progress: { next: 'collected', label: 'Mark as Collected', needsQty: true },
  collected: { next: null, label: 'Awaiting Facility Confirmation' }
};

function CollectorOverview({ pickups }) {
  const assigned = pickups.filter(p => p.status === 'assigned').length;
  const inProgress = pickups.filter(p => p.status === 'in_progress').length;
  const collected = pickups.filter(p => p.status === 'collected').length;
  const delivered = pickups.filter(p => p.status === 'delivered').length;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-800">Collector Dashboard</h2>
        <p className="text-sm text-gray-500">Track your assigned waste pickups</p>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Assigned" value={assigned} icon={Truck} color="#d97706" bg="#FEF3C7" />
        <StatCard title="In Progress" value={inProgress} icon={Truck} color="#7c3aed" bg="#f3e8ff" />
        <StatCard title="Collected" value={collected} icon={Truck} color="#2563eb" bg="#EFF6FF" />
        <StatCard title="Delivered" value={delivered} icon={CheckCircle} color="#16834A" bg="#E8F5E9" />
      </div>
    </div>
  );
}

function AssignedPickups({ pickups, loading, onRefresh }) {
  const [actionModal, setActionModal] = useState(null);
  const [actualQty, setActualQty] = useState('');
  const [saving, setSaving] = useState(false);

  const handleAction = async () => {
    const flow = STATUS_FLOW[actionModal.status];
    if (!flow?.next) return;
    if (flow.needsQty && (!actualQty || Number(actualQty) <= 0)) {
      toast.error('Enter actual collected quantity');
      return;
    }
    setSaving(true);
    try {
      const updateData = { status: flow.next, updatedAt: serverTimestamp() };
      if (flow.needsQty) updateData.actualQuantity = Number(actualQty);
      await updateDoc(doc(db, 'wasteRequests', actionModal.id), updateData);
      toast.success('Status updated!');
      setActionModal(null);
      setActualQty('');
      onRefresh();
    } catch (err) {
      toast.error('Update failed.');
    } finally {
      setSaving(false);
    }
  };

  const active = pickups.filter(p => ['assigned', 'in_progress', 'collected'].includes(p.status));
  const done = pickups.filter(p => p.status === 'delivered');

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-2xl font-bold text-gray-800">Assigned Pickups</h2>
        <p className="text-sm text-gray-500">Your current and past waste collection assignments</p>
      </div>

      {/* Active */}
      <div>
        <h3 className="font-semibold text-gray-700 mb-3">Active Assignments ({active.length})</h3>
        {loading ? (
          <p className="text-gray-400 text-sm">Loading...</p>
        ) : active.length === 0 ? (
          <div className="bg-white rounded-xl border border-dashed border-gray-200 p-8 text-center text-gray-400">
            No active pickups assigned to you.
          </div>
        ) : active.map(p => {
          const flow = STATUS_FLOW[p.status];
          return (
            <div key={p.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 mb-3">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="font-bold text-gray-800">{p.providerName}</p>
                  <p className="text-sm text-gray-500">{p.wasteType} · Est. {p.estimatedQuantity} KG</p>
                </div>
                <StatusBadge status={p.status} />
              </div>
              <div className="grid grid-cols-2 gap-3 mb-3 text-sm">
                <div>
                  <p className="text-xs text-gray-400">Pickup Address</p>
                  <p className="text-gray-700">{p.pickupAddress}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Scheduled Date</p>
                  <p className="text-gray-700">{p.pickupDate}</p>
                </div>
              </div>
              {flow?.next && (
                <button
                  onClick={() => { setActionModal(p); setActualQty(String(p.estimatedQuantity || '')); }}
                  className="w-full py-2.5 bg-green-700 text-white rounded-xl text-sm font-medium hover:bg-green-800 transition-colors"
                >
                  {flow.label}
                </button>
              )}
              {!flow?.next && (
                <p className="text-center text-sm text-gray-400 bg-gray-50 py-2.5 rounded-xl">
                  Waiting for facility to confirm receipt
                </p>
              )}
            </div>
          );
        })}
      </div>

      {/* Completed */}
      {done.length > 0 && (
        <div>
          <h3 className="font-semibold text-gray-700 mb-3">Completed ({done.length})</h3>
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-100">
                    <th className="px-4 py-3 text-left font-medium text-gray-600">Provider</th>
                    <th className="px-4 py-3 text-left font-medium text-gray-600">Waste Type</th>
                    <th className="px-4 py-3 text-left font-medium text-gray-600">Collected</th>
                    <th className="px-4 py-3 text-left font-medium text-gray-600">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {done.map(p => (
                    <tr key={p.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3 font-medium text-gray-800">{p.providerName}</td>
                      <td className="px-4 py-3 text-gray-600">{p.wasteType}</td>
                      <td className="px-4 py-3 text-gray-600">{p.actualQuantity || p.estimatedQuantity} KG</td>
                      <td className="px-4 py-3 text-gray-400">{formatDate(p.updatedAt || p.createdAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Action Modal */}
      {actionModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl">
            <h3 className="font-bold text-lg text-gray-800 mb-2">
              {STATUS_FLOW[actionModal.status]?.label}
            </h3>
            <p className="text-sm text-gray-500 mb-4">{actionModal.providerName} — {actionModal.wasteType}</p>
            {STATUS_FLOW[actionModal.status]?.needsQty && (
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Actual Quantity Collected (KG)</label>
                <input
                  type="number"
                  value={actualQty}
                  onChange={e => setActualQty(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
            )}
            <div className="flex gap-3">
              <button onClick={() => setActionModal(null)} className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-medium">Cancel</button>
              <button onClick={handleAction} disabled={saving} className="flex-1 py-2.5 bg-green-700 text-white rounded-xl text-sm font-medium hover:bg-green-800 disabled:opacity-60">
                {saving ? 'Updating...' : 'Confirm'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function CollectorDashboard() {
  const { currentUser } = useAuth();
  const [pickups, setPickups] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchPickups = async () => {
    if (!currentUser) return;
    try {
      const snap = await getDocs(query(
        collection(db, 'wasteRequests'),
        where('collectorId', '==', currentUser.uid),
        orderBy('createdAt', 'desc')
      ));
      setPickups(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchPickups(); }, [currentUser]);

  return (
    <DashboardLayout sidebarItems={sidebarItems}>
      <Routes>
        <Route index element={<CollectorOverview pickups={pickups} />} />
        <Route path="pickups" element={<AssignedPickups pickups={pickups} loading={loading} onRefresh={fetchPickups} />} />
        <Route path="*" element={<Navigate to="/dashboard/collector" replace />} />
      </Routes>
    </DashboardLayout>
  );
}
