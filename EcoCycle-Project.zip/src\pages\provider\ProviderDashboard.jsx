import React, { useState, useEffect } from 'react';
import { db } from '../../firebase/config';
import { collection, addDoc, getDocs, query, where, orderBy, serverTimestamp } from 'firebase/firestore';
import { useAuth } from '../../contexts/AuthContext';
import DashboardLayout from '../../components/shared/DashboardLayout';
import { Routes, Route, Navigate, Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, PlusCircle, ClipboardList, User } from 'lucide-react';
import StatCard from '../../components/shared/StatCard';
import StatusBadge from '../../components/shared/StatusBadge';
import { formatDate, WASTE_TYPES } from '../../utils/helpers';
import toast from 'react-hot-toast';

const sidebarItems = [
  { icon: LayoutDashboard, label: 'Overview', path: '/dashboard/provider' },
  { icon: PlusCircle, label: 'New Request', path: '/dashboard/provider/new' },
  { icon: ClipboardList, label: 'My Requests', path: '/dashboard/provider/requests' },
];

function ProviderOverview({ requests }) {
  const total = requests.length;
  const pending = requests.filter(r => r.status === 'pending').length;
  const completed = requests.filter(r => r.status === 'delivered').length;
  const totalKg = requests.reduce((a, r) => a + (r.estimatedQuantity || 0), 0);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-800">Provider Dashboard</h2>
        <p className="text-sm text-gray-500">Manage your organic waste collection requests</p>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Requests" value={total} icon={ClipboardList} color="#16834A" bg="#E8F5E9" />
        <StatCard title="Pending" value={pending} icon={ClipboardList} color="#d97706" bg="#FEF3C7" />
        <StatCard title="Completed" value={completed} icon={ClipboardList} color="#2563eb" bg="#EFF6FF" />
        <StatCard title="Total Waste (KG)" value={totalKg} icon={ClipboardList} color="#7c3aed" bg="#f3e8ff" />
      </div>
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="font-bold text-gray-800 mb-4">Recent Requests</h3>
        {requests.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-400 mb-3">No requests yet.</p>
            <Link to="/dashboard/provider/new" className="text-green-700 font-medium text-sm hover:underline">
              + Submit your first waste collection request
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {requests.slice(0, 5).map(r => (
              <div key={r.id} className="flex items-center justify-between p-3 rounded-xl border border-gray-100 hover:bg-gray-50">
                <div>
                  <p className="font-medium text-gray-800 text-sm">{r.wasteType}</p>
                  <p className="text-xs text-gray-400">{r.estimatedQuantity} KG · {r.pickupDate} · {r.pickupAddress?.slice(0, 40)}</p>
                </div>
                <StatusBadge status={r.status} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function NewRequest({ onSubmit }) {
  const { currentUser, userProfile } = useAuth();
  const [form, setForm] = useState({ wasteType: '', estimatedQuantity: '', pickupAddress: userProfile?.location || '', pickupDate: '', notes: '' });
  const [submitting, setSubmitting] = useState(false);
  const nav = useLocation();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.wasteType || !form.estimatedQuantity || !form.pickupAddress || !form.pickupDate) {
      toast.error('Please fill all required fields.'); return;
    }
    setSubmitting(true);
    try {
      await addDoc(collection(db, 'wasteRequests'), {
        providerId: currentUser.uid,
        providerName: userProfile?.name || currentUser.email,
        wasteType: form.wasteType,
        estimatedQuantity: Number(form.estimatedQuantity),
        pickupAddress: form.pickupAddress,
        pickupDate: form.pickupDate,
        notes: form.notes,
        status: 'pending',
        createdAt: serverTimestamp()
      });
      toast.success('Waste collection request submitted!');
      setForm({ wasteType: '', estimatedQuantity: '', pickupAddress: userProfile?.location || '', pickupDate: '', notes: '' });
      if (onSubmit) onSubmit();
    } catch (err) {
      toast.error('Failed to submit request.');
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const inputClass = "w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500";

  return (
    <div className="max-w-xl">
      <h2 className="text-2xl font-bold text-gray-800 mb-1">New Collection Request</h2>
      <p className="text-sm text-gray-500 mb-6">Submit a waste pickup request and a collector will be assigned.</p>
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Waste Type *</label>
            <select value={form.wasteType} onChange={e => setForm(p => ({ ...p, wasteType: e.target.value }))} className={inputClass} required>
              <option value="">Select waste type</option>
              {WASTE_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Estimated Quantity (KG) *</label>
            <input type="number" min="1" value={form.estimatedQuantity} onChange={e => setForm(p => ({ ...p, estimatedQuantity: e.target.value }))} placeholder="e.g. 50" className={inputClass} required />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Pickup Address *</label>
            <input value={form.pickupAddress} onChange={e => setForm(p => ({ ...p, pickupAddress: e.target.value }))} placeholder="Full pickup address" className={inputClass} required />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Pickup Date *</label>
            <input type="date" value={form.pickupDate} min={new Date().toISOString().split('T')[0]} onChange={e => setForm(p => ({ ...p, pickupDate: e.target.value }))} className={inputClass} required />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">Additional Notes</label>
            <textarea rows={3} value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} placeholder="Any special instructions..." className={inputClass + ' resize-none'} />
          </div>
          <button type="submit" disabled={submitting} className="w-full py-3 bg-green-700 text-white rounded-xl font-semibold text-sm hover:bg-green-800 disabled:opacity-60">
            {submitting ? 'Submitting...' : 'Submit Collection Request'}
          </button>
        </form>
      </div>
    </div>
  );
}

function MyRequests({ requests, loading }) {
  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-2xl font-bold text-gray-800">My Requests</h2>
        <p className="text-sm text-gray-500">All your waste collection requests</p>
      </div>
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100">
                <th className="px-4 py-3 text-left font-medium text-gray-600">Waste Type</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600">Quantity</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600">Pickup Address</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600">Pickup Date</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600">Submitted</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600">Status</th>
                <th className="px-4 py-3 text-left font-medium text-gray-600">Collector</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {loading ? (
                <tr><td colSpan={7} className="text-center py-8 text-gray-400">Loading...</td></tr>
              ) : requests.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-10 text-gray-400">
                    No requests yet.{' '}
                    <Link to="/dashboard/provider/new" className="text-green-700 hover:underline">Create one.</Link>
                  </td>
                </tr>
              ) : requests.map(r => (
                <tr key={r.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 font-medium text-gray-800">{r.wasteType}</td>
                  <td className="px-4 py-3 text-gray-600">{r.estimatedQuantity} KG</td>
                  <td className="px-4 py-3 text-gray-600 max-w-xs truncate">{r.pickupAddress}</td>
                  <td className="px-4 py-3 text-gray-600">{r.pickupDate}</td>
                  <td className="px-4 py-3 text-gray-400">{formatDate(r.createdAt)}</td>
                  <td className="px-4 py-3"><StatusBadge status={r.status} /></td>
                  <td className="px-4 py-3 text-gray-600">{r.collectorName || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default function ProviderDashboard() {
  const { currentUser } = useAuth();
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchRequests = async () => {
    if (!currentUser) return;
    try {
      const snap = await getDocs(query(
        collection(db, 'wasteRequests'),
        where('providerId', '==', currentUser.uid),
        orderBy('createdAt', 'desc')
      ));
      setRequests(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchRequests(); }, [currentUser]);

  return (
    <DashboardLayout sidebarItems={sidebarItems}>
      <Routes>
        <Route index element={<ProviderOverview requests={requests} />} />
        <Route path="new" element={<NewRequest onSubmit={fetchRequests} />} />
        <Route path="requests" element={<MyRequests requests={requests} loading={loading} />} />
        <Route path="*" element={<Navigate to="/dashboard/provider" replace />} />
      </Routes>
    </DashboardLayout>
  );
}
