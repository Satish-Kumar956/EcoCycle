export const ROLES = {
  ADMIN: 'admin',
  PROVIDER: 'provider',
  COLLECTOR: 'collector',
  GAUSHALA: 'gaushala',
  ANIMAL_OWNER: 'animalOwner',
  BIOGAS_OPERATOR: 'biogasOperator',
  FERTILIZER_PRODUCER: 'fertilizerProducer',
  FARMER_NURSERY: 'farmerNursery'
};

export const ROLE_LABELS = {
  admin: 'Admin',
  provider: 'Waste Provider',
  collector: 'Waste Collector',
  gaushala: 'Gaushala',
  animalOwner: 'Animal Owner',
  biogasOperator: 'Biogas Plant Operator',
  fertilizerProducer: 'Fertilizer Producer',
  farmerNursery: 'Farmer / Nursery Owner'
};

export const ROLE_ROUTES = {
  admin: '/dashboard/admin',
  provider: '/dashboard/provider',
  collector: '/dashboard/collector',
  gaushala: '/dashboard/gaushala',
  animalOwner: '/dashboard/animal-owner',
  biogasOperator: '/dashboard/biogas',
  fertilizerProducer: '/dashboard/fertilizer',
  farmerNursery: '/dashboard/farmer'
};

export const WASTE_TYPES = ['Vegetables', 'Fruits', 'Mixed Organic Waste'];

export const REQUEST_STATUSES = [
  'pending', 'assigned', 'in_progress', 'collected', 'delivered'
];

export const DISTRIBUTION_STATUSES = [
  'available', 'requested', 'approved', 'assigned', 'dispatched', 'delivered'
];

export const DISTRIBUTION_CATEGORIES = {
  animalFeed: 'Animal Feed',
  biogas: 'Biogas',
  compost: 'Compost'
};

export const formatDate = (timestamp) => {
  if (!timestamp) return 'N/A';
  const date = timestamp?.toDate ? timestamp.toDate() : new Date(timestamp);
  return date.toLocaleDateString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric'
  });
};

export const formatDateInput = (timestamp) => {
  if (!timestamp) return '';
  const date = timestamp?.toDate ? timestamp.toDate() : new Date(timestamp);
  return date.toISOString().split('T')[0];
};

export const formatQuantity = (kg) => `${kg || 0} KG`;

export const getStatusColor = (status) => {
  const map = {
    pending: 'bg-yellow-100 text-yellow-800',
    assigned: 'bg-blue-100 text-blue-800',
    in_progress: 'bg-purple-100 text-purple-800',
    collected: 'bg-teal-100 text-teal-800',
    delivered: 'bg-green-100 text-green-800',
    available: 'bg-green-100 text-green-700',
    requested: 'bg-orange-100 text-orange-800',
    approved: 'bg-blue-100 text-blue-800',
    dispatched: 'bg-indigo-100 text-indigo-800',
    completed: 'bg-green-100 text-green-800',
    rejected: 'bg-red-100 text-red-800',
    received: 'bg-teal-100 text-teal-800',
    classified: 'bg-green-100 text-green-800'
  };
  return map[status] || 'bg-gray-100 text-gray-700';
};

export const generateBatchId = () => {
  const now = new Date();
  const ts = now.getFullYear().toString().slice(-2) +
    String(now.getMonth() + 1).padStart(2, '0') +
    String(now.getDate()).padStart(2, '0') +
    String(now.getHours()).padStart(2, '0') +
    String(now.getMinutes()).padStart(2, '0');
  return `ECO-${ts}`;
};

export const truncate = (str, n = 30) =>
  str && str.length > n ? str.slice(0, n) + '...' : str;
