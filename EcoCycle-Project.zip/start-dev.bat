@echo off
title EcoCycle Dev Server
cd /d "%~dp0"
echo ====================================================
echo Starting EcoCycle - Smart Organic Waste System
echo ====================================================
set "PATH=C:\Users\ASUS\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin;%PATH%"
"C:\Users\ASUS\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" "node_modules\vite\bin\vite.js" --host
pause
