$env:PATH = "C:\Users\ASUS\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin;" + $env:PATH
Set-Location -Path $PSScriptRoot
Write-Host "====================================================" -ForegroundColor Green
Write-Host "Starting EcoCycle Dev Server..." -ForegroundColor Green
Write-Host "====================================================" -ForegroundColor Green
& "C:\Users\ASUS\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" "node_modules\vite\bin\vite.js" --host
