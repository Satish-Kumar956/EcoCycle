import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      'firebase/firestore': path.resolve(__dirname, 'src/firebase/firestore-adapter.js'),
      'firebase/auth': path.resolve(__dirname, 'src/firebase/auth-adapter.js'),
      'firebase/storage': path.resolve(__dirname, 'src/firebase/storage-adapter.js'),
    }
  }
})
